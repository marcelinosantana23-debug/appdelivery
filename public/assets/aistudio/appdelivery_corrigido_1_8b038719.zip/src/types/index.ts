export interface TenantCredential {
  tenantId: string;
  tenantName: string;
  tenantSlug: string;
  userId: string;
  email: string;
  password?: string;
  name: string;
  status: string;
}

export interface ProductOption {
  id: string;
  name: string;
  price: number;
  groupId?: string;
  groupName?: string;
}

export interface AddonItem {
  id: string;
  name: string;
  price: number;
  available?: boolean;
}

export interface AddonGroup {
  id: string;
  tenantId: string;
  name: string;
  description?: string;
  minSelection: number; // 0 para opcional, >= 1 para obrigatório
  maxSelection: number; // 0 para ilimitado, ou valor numérico
  required?: boolean;
  items: AddonItem[];
  position?: number;
  createdAt?: number;
  updatedAt?: number;
}

export interface Product {
  id: string;
  tenantId?: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  available: boolean;
  options: ProductOption[];
  addonGroupIds?: string[];
  addonGroups?: AddonGroup[];
  position?: number;
  ordem?: number;
  order?: number;
  createdAt?: number;
}

export type UserRole = "super_admin" | "tenant_admin";
export type TenantStatus = "active" | "inactive";
export type SubscriptionStatus = "demo" | "active" | "overdue" | "cancelled";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  tenantId: string | null;
  status: "active" | "inactive";
  createdAt: number;
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  email: string;
  phone?: string;
  whatsapp: string;
  motoboyPhone?: string;
  motoboy_phone?: string;
  motoboyName?: string;
  motoboy_name?: string;
  pixKey: string;
  pixKeyType: "cpf" | "cnpj" | "phone" | "email" | "random";
  deliveryFee: number;
  deliveryTime?: string;
  address: string;
  hours: string;
  tagline: string;
  announcement?: string;
  logo: string;
  bannerImage?: string;
  primaryColor: string;
  secondaryColor?: string;
  primaryDark: string;
  primaryLight: string;
  accentColor: string;
  themeMode?: "light" | "dark";
  menuLayout?: "list" | "grid";
  showFeaturedCarousel?: boolean;
  isFeatured?: boolean;
  priorityOrder?: number;
  businessType?: string;
  category?: string;
  categoryId?: string;
  category_id?: string;
  localidade?: string;
  location?: string;
  rating?: number;
  ratingCount?: number;
  status: TenantStatus;
  subscriptionStatus?: SubscriptionStatus;
  billingDay?: number;
  lastPaymentAt?: number;
  paidUntil?: number;
  nextDueDate?: number;
  monthlyFee?: number;
  isOpen: boolean;
  createdAt: number;
  updatedAt: number;
  productCount?: number;
  orderCount?: number;
  completedOrdersCount?: number;
  salesCount?: number;
  revenue?: number;
}

export interface PlatformSettings {
  logoUrl?: string;
  bannerUrl?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  primaryColor?: string;
  geminiApiKey?: string;
  adminPixKey?: string;
  adminPixType?: string;
  adminWhatsapp?: string;
  partnerWhatsapp?: string;
  defaultMonthlyFee?: number;
  updatedAt?: number;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  tenantId?: string;
  order?: number;
  order_index?: number;
  createdAt?: number;
}

export interface EstablishmentCategory {
  id: string;
  name: string;
  icon: string;
  order: number;
  order_index?: number;
  slug?: string;
  active?: boolean;
  createdAt?: number;
}

export interface CartItem {
  id: string;
  product: {
    id: string;
    tenantId?: string;
    name: string;
    description?: string;
    price: number;
    image?: string;
    category?: string;
    available?: boolean;
    options?: ProductOption[];
  };
  quantity: number;
  selectedOptions: ProductOption[];
  notes: string;
  totalPrice?: number;
}

export type OrderItem = CartItem;

export type OrderType = "delivery" | "pickup" | "dine_in";
export type PaymentMethod = "pix" | "card" | "cash";
export type CardType = "credit" | "debit";
export type StandardOrderStatus =
  | "PENDENTE"
  | "EM_PREPARO"
  | "PRONTO"
  | "SAIU_PARA_ENTREGA"
  | "ENTREGUE"
  | "CANCELADO";

export type OrderStatus =
  | "received"
  | "preparing"
  | "delivering"
  | "done"
  | "cancelled"
  | "ready"
  | StandardOrderStatus
  | (string & {});

export interface Order {
  id: string;
  tenantId?: string;
  items: CartItem[];
  orderType: OrderType;
  /** Tipo canônico salvo/derivado do banco: 'delivery' | 'retirada' | 'mesa' */
  tipo_pedido?: "delivery" | "retirada" | "mesa";
  tableNumber?: string;
  table_number?: string;
  mesa?: string;
  table?: string;
  paymentMethod: PaymentMethod;
  cardType?: CardType;
  paymentDetails?: string;
  pixReceiptUrl?: string;
  pix_receipt_url?: string;
  location_url?: string;
  locationUrl?: string;
  address?: {
    street: string;
    number: string;
    district: string;
    complement: string;
    reference: string;
  };
  changeFor?: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  customerName: string;
  customerPhone: string;
  createdAt: number;
  statusHistory: { status: OrderStatus; timestamp: number }[];
  idempotencyKey?: string;
  idempotency_key?: string;
  cart_id?: string;
  duplicated?: boolean;
}

export interface Customer {
  id: string;
  tenantId: string;
  name: string;
  phone: string;
  street?: string;
  number?: string;
  district?: string;
  complement?: string;
  reference?: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderAt: number;
  createdAt: number;
  updatedAt: number;
}

export interface StoredCustomerProfile {
  name: string;
  phone: string;
  street: string;
  number: string;
  district: string;
  complement?: string;
  reference?: string;
  lastUpdated?: number;
}

export interface FinancialMetrics {
  todayRevenue: number;
  monthRevenue: number;
  monthCompletedOrders: number;
  averageTicket: number;
  todayCompletedOrders: number;
  deliveredCount: number;
  pickupCount: number;
  deliveryFeeTotal: number;
}

export interface DailyRevenueItem {
  day: number;
  date: string;
  dayOfWeek: string;
  revenue: number;
  ordersCount: number;
}

export interface PaymentBreakdownItem {
  method: PaymentMethod | string;
  label: string;
  total: number;
  count: number;
  percent: number;
}

export interface FinancialReportData {
  period: {
    month: number;
    year: number;
    monthName: string;
    startDate: string;
    endDate: string;
  };
  metrics: FinancialMetrics;
  dailyRevenue: DailyRevenueItem[];
  paymentBreakdown: PaymentBreakdownItem[];
  orders: Order[];
}

export interface TopSellingProduct {
  id: string;
  productId: string;
  name: string;
  price: number;
  image?: string;
  description?: string;
  category?: string;
  available?: boolean;
  options?: ProductOption[];
  addonGroupIds?: string[];
  tenantId: string;
  tenantName: string;
  tenantSlug: string;
  tenantLogo?: string;
  tenantPrimaryColor?: string;
  tenantIsOpen?: boolean;
  tenantDeliveryFee?: number;
  tenantDeliveryTime?: string;
  location?: string;
  localidade?: string;
  totalSold: number;
  rank?: number;
}

export interface FeaturedStoreRanked extends Tenant {
  completedOrdersCount: number;
  salesCount: number;
  rank: number;
}

export interface StoreStory {
  id: string;
  tenantId: string;
  mediaUrl: string; // Base64 data URL ou URL de imagem (JPG, PNG, WEBP)
  mediaType: "image"; // APENAS FOTOS
  caption?: string;
  createdAt: number;
  expiresAt: number; // created_at + 24 * 60 * 60 * 1000
}

