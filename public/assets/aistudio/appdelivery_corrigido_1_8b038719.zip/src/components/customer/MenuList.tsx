import { Plus, MessageCircle, Clock, Bike, MapPin, Flame, Sparkles } from "lucide-react";
import type { Product } from "@/types";
import { formatPrice } from "@/utils/order";
import { useStore } from "@/context/StoreContext";
import { StoreLogo } from "@/components/common/StoreLogo";
import { getSafeDisplayName } from "@/utils/storeFormat";
import { normalizeProductImage, handleImageError } from "@/utils/imageUtils";

interface MenuListProps {
  products: Product[];
  onProductClick: (product: Product) => void;
}

const defaultCategoryNames: Record<string, string> = {
  lanches: "Lanches Tradicionais (Hambúrgueres)",
  hotdogs: "Hot Dogs (Cachorros-Quentes Completos)",
  pizzas: "Pizzas Artesanais",
  acai: "Açaí e Sorvetes",
  bebidas: "Bebidas Variadas",
  combos: "Combos Especiais",
  porcoes: "Porções & Aperitivos",
  sobremesas: "Sobremesas & Doces",
  pasteis: "Pastéis Recheados",
  doces: "Doces & Bolos",
  salgados: "Salgados Fritos & Assados",
  pratos: "Pratos Feitos & Refeições",
  adicionais: "Adicionais & Molhos",
};

const defaultCategoryIcons: Record<string, string> = {
  lanches: "🍔",
  hotdogs: "🌭",
  pizzas: "🍕",
  acai: "🍧",
  bebidas: "🥤",
  combos: "🍟",
  porcoes: "🍗",
  sobremesas: "🍰",
  pasteis: "🥟",
  doces: "🍩",
  salgados: "🥐",
  pratos: "🍽️",
  adicionais: "🧀",
};

export function MenuList({ products, onProductClick }: MenuListProps) {
  const { config, isLoadingStore } = useStore();

  if (!products || products.length === 0) {
    if (isLoadingStore) {
      return (
        <div className="mx-auto max-w-2xl px-4 py-8 space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="flex items-center justify-between gap-4 rounded-2xl border border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 shadow-xs animate-pulse"
            >
              <div className="flex-1 space-y-2.5">
                <div className="h-4 w-2/3 rounded-lg bg-gray-200 dark:bg-slate-800" />
                <div className="h-3 w-full rounded-lg bg-gray-100 dark:bg-slate-800/70" />
                <div className="h-4 w-20 rounded-lg bg-gray-200 dark:bg-slate-800 pt-1" />
              </div>
              <div className="h-20 w-20 shrink-0 rounded-xl bg-gray-200 dark:bg-slate-800" />
            </div>
          ))}
        </div>
      );
    }

    const cleanWhatsapp = config.whatsapp?.replace(/\D/g, "") || "";
    const whatsappUrl = `https://wa.me/${cleanWhatsapp}?text=${encodeURIComponent(
      `Olá! Acessei o link da ${config.name} e gostaria de informações sobre o cardápio.`
    )}`;

    return (
      <div className="mx-auto max-w-2xl px-4 py-12">
        <div className="rounded-3xl border border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center shadow-sm">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center overflow-hidden rounded-3xl bg-amber-50 dark:bg-slate-800 text-4xl shadow-inner">
            <StoreLogo logo={config.logo} name={config.name} className="h-full w-full object-cover" />
          </div>

          <h3 className="text-xl font-black text-gray-800 dark:text-white sm:text-2xl">
            {getSafeDisplayName(config.name, "Burger Town")}
          </h3>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            {config.tagline || "Cardápio Online Exclusivo"}
          </p>

          <div className="my-6 rounded-2xl bg-gray-50 dark:bg-slate-800/60 p-4 text-xs text-gray-600 dark:text-gray-300 space-y-2 border border-gray-100 dark:border-slate-800">
            <p className="font-semibold text-gray-700 dark:text-gray-200">
              Esta lanchonete está preparando novidades!
            </p>
            <p>
              Os itens do cardápio online estão sendo cadastrados pelo lojista. Você pode tirar dúvidas ou fazer seu pedido diretamente pelo WhatsApp:
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-gray-500 dark:text-gray-400">
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-primary" />
                {config.hours}
              </span>
              <span className="flex items-center gap-1">
                <Bike className="h-3.5 w-3.5 text-primary" />
                Taxa: {formatPrice(config.deliveryFee, config)}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-primary" />
                {config.address}
              </span>
            </div>
          </div>

          {cleanWhatsapp && (
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-md transition hover:bg-emerald-700 active:scale-95"
            >
              <MessageCircle className="h-4 w-4" />
              Chamar no WhatsApp ({config.whatsapp})
            </a>
          )}
        </div>
      </div>
    );
  }

  // Highlights & Most Popular items (combos, or first available products)
  const featuredProducts = products
    .filter((p) => p.available)
    .slice(0, 6);

  const grouped = products.reduce<Record<string, Product[]>>((acc, product) => {
    (acc[product.category] = acc[product.category] || []).push(product);
    return acc;
  }, {});

  const showCarousel = config.showFeaturedCarousel !== false && featuredProducts.length > 0;

  return (
    <div className="mx-auto max-w-2xl px-4 py-4 space-y-7">
      {/* 1. CARROSSEL DE MAIS PEDIDOS / DESTAQUES DA SEMANA */}
      {showCarousel && (
        <section className="pt-1">
          <div className="flex items-center justify-between mb-3 px-0.5">
            <div className="flex items-center gap-1.5">
              <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-red-500/10 text-red-600 dark:bg-red-500/20 dark:text-red-400">
                <Flame className="h-4 w-4 fill-current" />
              </div>
              <h2 className="text-base font-black text-gray-900 dark:text-white tracking-tight">
                Mais Pedidos da Semana
              </h2>
            </div>
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[11px] font-bold text-amber-600 dark:text-amber-400 border border-amber-500/20">
              <Sparkles className="h-3 w-3" />
              Destaques
            </span>
          </div>

          <div className="flex gap-3 overflow-x-auto overflow-y-hidden pb-2 scrollbar-none snap-x overscroll-x-contain -mx-4 px-4 sm:mx-0 sm:px-0">
            {featuredProducts.map((product, idx) => (
              <button
                key={`featured-${product.id}`}
                onClick={() => onProductClick(product)}
                className="group relative flex w-40 sm:w-44 shrink-0 flex-col overflow-hidden rounded-2xl border border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-800/90 text-left shadow-sm transition hover:shadow-md hover:border-primary active:scale-[0.98] snap-start"
              >
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-gray-100 dark:bg-slate-700">
                  <img
                    src={normalizeProductImage(product.image, product.category, product.name)}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    onError={(e) => handleImageError(e, product.category, product.name)}
                    className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  />
                  <div className="absolute top-2 left-2 rounded-full bg-red-600/90 px-2 py-0.5 text-[10px] font-bold text-white shadow-sm backdrop-blur-xs flex items-center gap-0.5">
                    <span>#{idx + 1}</span>
                  </div>
                </div>

                <div className="flex flex-1 flex-col justify-between p-2.5 sm:p-3">
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white line-clamp-1 leading-tight group-hover:text-primary transition-colors">
                      {product.name}
                    </h3>
                    <p className="mt-0.5 text-[11px] text-gray-400 dark:text-gray-400 line-clamp-1">
                      {product.description}
                    </p>
                  </div>

                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-extrabold text-primary-dark dark:text-primary-light">
                      {formatPrice(product.price, config)}
                    </span>
                    <span className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-full bg-primary text-white shadow-sm transition group-active:scale-90">
                      <Plus className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Divisor do Cardápio Completo */}
      <div className="flex items-center gap-2 border-t border-gray-100 dark:border-slate-800/80 pt-4 px-0.5">
        <span className="text-xs font-bold uppercase tracking-wider text-gray-400 dark:text-slate-500">
          Cardápio Completo
        </span>
        <div className="h-px flex-1 bg-gray-100 dark:bg-slate-800/80" />
      </div>

      {/* 2. TODAS AS CATEGORIAS DO CARDÁPIO EM CARROSSÉIS HORIZONTAIS COMPACTOS */}
      {Object.entries(grouped).map(([catId, items]) => {
        const displayName =
          defaultCategoryNames[catId] ||
          catId.charAt(0).toUpperCase() + catId.slice(1);
        const icon = defaultCategoryIcons[catId] || "🍽️";

        return (
          <section key={catId} id={`cat-${catId}`} className="scroll-mt-20 sm:scroll-mt-24">
            {/* Título da Categoria com contagem de itens */}
            <div className="flex items-center justify-between mb-2.5 px-0.5">
              <div className="flex items-center gap-2">
                <span className="text-base">{icon}</span>
                <h2 className="text-base sm:text-lg font-bold text-gray-900 dark:text-white tracking-tight">
                  {displayName}
                </h2>
                <span className="text-xs font-semibold text-gray-400 dark:text-gray-500">
                  ({items.length})
                </span>
              </div>
            </div>

            {/* Carrossel Horizontal: Exatamente o mesmo layout de cards do "Mais Pedidos da Semana" */}
            <div className="flex gap-3 overflow-x-auto overflow-y-hidden pb-2 scrollbar-none snap-x overscroll-x-contain -mx-4 px-4 sm:mx-0 sm:px-0">
              {items.map((product) => (
                <button
                  key={product.id}
                  onClick={() => product.available && onProductClick(product)}
                  disabled={!product.available}
                  className={`group relative flex w-40 sm:w-44 shrink-0 flex-col overflow-hidden rounded-2xl border border-gray-200 dark:border-slate-800 bg-white dark:bg-slate-800/90 text-left shadow-sm transition hover:shadow-md hover:border-primary active:scale-[0.98] snap-start ${
                    product.available
                      ? "cursor-pointer"
                      : "opacity-60 cursor-not-allowed"
                  }`}
                >
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-gray-100 dark:bg-slate-700">
                    <img
                      src={normalizeProductImage(product.image, product.category, product.name)}
                      alt={product.name}
                      referrerPolicy="no-referrer"
                      onError={(e) => handleImageError(e, product.category, product.name)}
                      className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                    />
                    {!product.available && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-xs">
                        <span className="rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-bold text-white shadow-sm">
                          Esgotado
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-1 flex-col justify-between p-2.5 sm:p-3">
                    <div>
                      <h3 className="text-xs sm:text-sm font-bold text-gray-900 dark:text-white line-clamp-1 leading-tight group-hover:text-primary transition-colors">
                        {product.name}
                      </h3>
                      <p className="mt-0.5 text-[11px] text-gray-500 dark:text-gray-400 line-clamp-1">
                        {product.description}
                      </p>
                    </div>

                    <div className="mt-2.5 flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-extrabold text-primary-dark dark:text-primary-light">
                        {formatPrice(product.price, config)}
                      </span>
                      {product.available && (
                        <span className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-full bg-primary text-white shadow-sm transition group-active:scale-90">
                          <Plus className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
