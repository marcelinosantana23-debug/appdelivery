import { Hono } from "hono";
import { cors } from "hono/cors";
import { streamSSE } from "hono/streaming";
import { sign, verify } from "hono/jwt";
import { Database } from "./db";
import { subscribeOrderEvents, ALL_TENANTS_ROOM } from "./events";
import { sendNewOrderPushNotification } from "./services/fcm";
import { SW_SCRIPT_CONTENT, MANIFEST_JSON_CONTENT, ASSET_LINKS_CONTENT } from "./pwaAssets";
import {
  analyzeMenuWithGemini,
  generateProductImageUrl,
  getProductImage,
  getGeminiClient,
  type MenuFileInput,
} from "./geminiMenu";
import type { Env, OrderStatus, TenantStatus, OrderItem, User } from "./types";
import { isAllowedOrigin, sanitizeErrorMessage } from "./security";

export const api = new Hono<{ Bindings: Env; Variables: { user?: User } }>();

// Helper para obter a chave JWT_SECRET configurada no Cloudflare Workers ou ambiente
export function getJwtSecret(c: any): string {
  return (
    c?.env?.JWT_SECRET ||
    (typeof process !== "undefined" && process.env?.JWT_SECRET) ||
    "topfood-jwt-secret-cloudflare-production-2026"
  );
}

// Helper para gerar token JWT assinado criptograficamente com expiração definida
export async function createJwtToken(payload: Record<string, any>, secret: string): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const claims = {
    iat: now,
    exp: now + 60 * 60 * 24 * 7, // 7 dias com expiração obrigatória
    ...payload,
  };
  return await sign(claims, secret, "HS256");
}

// Helper para validar tokens JWT de autenticação com validação estrita de expiração
export async function verifyTokenSafely(token: string, secret: string): Promise<any | null> {
  if (!token || typeof token !== "string") return null;
  const cleanToken = token.replace(/^Bearer\s+/i, "").trim();
  if (!cleanToken) return null;

  try {
    const decoded: any = await verify(cleanToken, secret, "HS256");
    if (!decoded) return null;

    // Validação de expiração da sessão
    const now = Math.floor(Date.now() / 1000);
    if (typeof decoded.exp === "number" && decoded.exp < now) {
      return null; // Sessão expirada
    }

    return decoded;
  } catch {
    return null;
  }
}

// 1. SEGURANÇA DE ROTAS E CORS: Permitir estritamente origens oficiais
api.use(
  "*",
  cors({
    origin: (origin, c) => {
      if (isAllowedOrigin(origin, c?.env)) {
        return origin || "*";
      }
      return "";
    },
    allowMethods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    allowHeaders: [
      "Content-Type",
      "Authorization",
      "X-Requested-With",
      "Accept",
      "Origin",
      "Cache-Control",
      "Pragma",
      "X-Admin-Role",
    ],
    exposeHeaders: ["Content-Length", "Content-Type"],
    credentials: true,
    maxAge: 86400,
  })
);

// Resposta expressa de pré-vôo OPTIONS para clientes móveis e redes externas
api.options("*", (c) => {
  return c.body(null, 204);
});

// 4. TRATAMENTO DE ERROS GLOBAL: Nunca expor stack traces ou internals do D1
api.onError((err, c) => {
  console.error("[Top Food API Error]:", err?.stack || err);
  const status = (err as any)?.status || (err as any)?.statusCode;
  if (status && status >= 400 && status < 500) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, status as any);
  }
  return c.json(
    {
      success: false,
      error: "Ocorreu um erro interno no servidor. Por favor, tente novamente mais tarde.",
    },
    500
  );
});

// Helper para autenticar o usuário da requisição via Bearer Token
export async function authenticateRequestUser(c: any): Promise<any | null> {
  const authHeader = c.req.header("Authorization") || c.req.header("authorization");
  const token = authHeader?.replace(/^Bearer\s+/i, "")?.trim();
  if (!token) return null;

  const secret = getJwtSecret(c);
  const decoded = await verifyTokenSafely(token, secret);
  if (!decoded) return null;

  const userId = decoded.userId || decoded.sub;
  if (!userId) return null;

  const db = getDb(c);
  const user = await db.getUserById(userId);
  if (!user || user.status !== "active") return null;

  // Invalidação imediata de tokens emitidos antes da alteração de credenciais
  if (user.updatedAt) {
    if (!decoded.userUpdatedAt || decoded.userUpdatedAt < user.updatedAt) {
      return null;
    }
  }

  return { ...user, tokenPayload: decoded };
}

// Middleware de verificação de token JWT para rotas Super Admin (/api/super-admin/* e /superadmin/*)
export async function requireSuperAdminMiddleware(c: any, next: any) {
  const user = await authenticateRequestUser(c);
  if (!user) {
    return c.json(
      { success: false, error: "Acesso não autorizado: token JWT ausente, expirado ou inválido." },
      401
    );
  }
  if (user.role !== "super_admin") {
    return c.json(
      { success: false, error: "Acesso negado: privilégios de Super Administrador requeridos." },
      403
    );
  }
  c.set("user", user);
  await next();
}

// Middleware de verificação de token JWT para rotas administrativas de lojistas (/api/merchant/*)
export async function requireMerchantMiddleware(c: any, next: any) {
  const user = await authenticateRequestUser(c);
  if (!user) {
    return c.json(
      { success: false, error: "Acesso não autorizado: token JWT ausente, expirado ou inválido." },
      401
    );
  }
  if (user.role !== "tenant_admin" && user.role !== "super_admin") {
    return c.json(
      { success: false, error: "Acesso negado: privilégios de lojista ou administrador requeridos." },
      403
    );
  }
  c.set("user", user);
  await next();
}

// Vinculação obrigatória de middleware JWT para todas as rotas administrativas
api.use("/api/super-admin/*", requireSuperAdminMiddleware);
api.use("/superadmin/*", requireSuperAdminMiddleware);
api.use("/api/merchant/*", requireMerchantMiddleware);

// Helper para instanciar a camada de banco de dados diretamente com o objeto env da requisição Cloudflare Workers
function getDb(c: any): Database {
  const db = new Database(c.env);
  try {
    // Permite que tarefas secundárias terminem após a resposta no Cloudflare Workers
    db.setExecutionContext(c.executionCtx);
  } catch {
    // Node/dev: não há executionCtx
  }
  return db;
}

// Mapeamento de status amigáveis para pedidos (Português <-> Inglês)
export const STATUS_MAP_PT_TO_EN: Record<string, OrderStatus> = {
  "Pendente": "received",
  "pendente": "received",
  "recebido": "received",
  "Recebido": "received",
  "PENDENTE": "received",
  "Em Preparo": "preparing",
  "em preparo": "preparing",
  "preparando": "preparing",
  "EM_PREPARO": "preparing",
  "Pronto": "ready",
  "pronto": "ready",
  "PRONTO": "ready",
  "Saiu para Entrega": "delivering",
  "saiu para entrega": "delivering",
  "em entrega": "delivering",
  "SAIU_PARA_ENTREGA": "delivering",
  "Concluído": "done",
  "concluido": "done",
  "finalizado": "done",
  "ENTREGUE": "done",
  "entregue": "done",
  "Cancelado": "cancelled",
  "cancelado": "cancelled",
  "CANCELADO": "cancelled",
};

export const STATUS_MAP_EN_TO_PT: Record<string, string> = {
  received: "Pendente",
  preparing: "Pedido Aceito",
  ready: "Pronto",
  delivering: "Saiu para Entrega",
  done: "Concluído",
  cancelled: "Cancelado",
  PENDENTE: "Pendente",
  EM_PREPARO: "Pedido Aceito",
  PRONTO: "Pronto",
  SAIU_PARA_ENTREGA: "Saiu para Entrega",
  ENTREGUE: "Entregue",
  CANCELADO: "Cancelado",
};

export function toStandardStatus(statusInput: string | undefined | null): string {
  if (!statusInput) return "PENDENTE";
  const s = String(statusInput).toUpperCase().trim().replace(/[\s-]+/g, "_");
  if (s === "PENDENTE" || s === "RECEIVED" || s === "PENDING" || s === "RECEBIDO" || s === "NOVO") return "PENDENTE";
  if (
    s === "EM_PREPARO" ||
    s === "PREPARING" ||
    s === "EM_PRODUCAO" ||
    s === "PRODUCAO" ||
    s === "PREPARANDO" ||
    s === "CONFIRMED" ||
    s === "ACEITO" ||
    s === "PEDIDO_ACEITO"
  ) {
    return "EM_PREPARO";
  }
  if (
    s === "PRONTO" ||
    s === "READY" ||
    s === "PRONTO_BALCAO" ||
    s === "PRONTO_NO_BALCAO" ||
    s === "PRONTO_COZINHA" ||
    s === "PRONTO_MESA" ||
    s === "PRONTO_PARA_RETIRADA" ||
    s === "PRONTO_PARA_SERVIR"
  ) {
    return "PRONTO";
  }
  if (
    s === "SAIU_PARA_ENTREGA" ||
    s === "DELIVERING" ||
    s === "A_CAMINHO" ||
    s === "DISPATCHED" ||
    s === "OUT_FOR_DELIVERY" ||
    s === "EM_ENTREGA"
  ) {
    return "SAIU_PARA_ENTREGA";
  }
  if (
    s === "ENTREGUE" ||
    s === "DONE" ||
    s === "COMPLETED" ||
    s === "DELIVERED" ||
    s === "CONCLUIDO" ||
    s === "CONCLUÍDO" ||
    s === "FINALIZADO" ||
    s === "SERVIDO"
  ) {
    return "ENTREGUE";
  }
  if (s === "CANCELADO" || s === "CANCELLED" || s === "CANCELED") return "CANCELADO";
  return s;
}

export function toLegacyStatus(statusInput: string | undefined | null): OrderStatus {
  const std = toStandardStatus(statusInput);
  switch (std) {
    case "PENDENTE": return "received";
    case "EM_PREPARO": return "preparing";
    case "PRONTO": return "ready";
    case "SAIU_PARA_ENTREGA": return "delivering";
    case "ENTREGUE": return "done";
    case "CANCELADO": return "cancelled";
    default: return "received";
  }
}

export function normalizeOrderStatus(statusInput: string): OrderStatus {
  return toLegacyStatus(statusInput);
}

// -----------------------------------------------------------------------------
// 1. HEALTH CHECK & STATUS DOS RECURSOS CLOUDFLARE (D1 & KV)
// -----------------------------------------------------------------------------

api.get("/health", (c) => {
  const hasD1 = Boolean(c.env?.DB);
  const hasKV = Boolean(c.env?.KV || c.env?.STORE_KV);

  return c.json({
    status: "ok",
    runtime: "Cloudflare Workers / Hono",
    platform: c.env?.PLATFORM_NAME || "Top Food Multi-tenant",
    cloudflare: {
      d1Database: hasD1 ? "Conectado (c.env.DB)" : "Modo desenvolvimento local em memória",
      kvStorage: hasKV ? "Conectado (c.env.KV / c.env.STORE_KV)" : "Modo desenvolvimento local em memória",
    },
    timestamp: Date.now(),
  }, 200);
});

api.get("/cloudflare/status", (c) => {
  const hasD1 = Boolean(c.env?.DB);
  const hasKV = Boolean(c.env?.KV || c.env?.STORE_KV);

  return c.json({
    success: true,
    environment: c.env?.ENVIRONMENT || "development",
    bindings: {
      d1: hasD1,
      kv: hasKV,
    },
    message: hasD1 && hasKV
      ? "Cloudflare D1 e KV operando em produção via bindings do Cloudflare Workers."
      : "Operando em modo de desenvolvimento local com persistência resiliente.",
  }, 200);
});

// -----------------------------------------------------------------------------
// PWA SERVICE WORKER & MANIFEST (PWABUILDER & ANDROID APK READY)
// -----------------------------------------------------------------------------

api.get("/sw.js", (_c) => {
  return new Response(SW_SCRIPT_CONTENT, {
    status: 200,
    headers: {
      "Content-Type": "application/javascript; charset=utf-8",
      "Service-Worker-Allowed": "/",
      "Cache-Control": "no-cache, no-store, must-revalidate",
    },
  });
});

api.get("/manifest.json", (_c) => {
  return new Response(MANIFEST_JSON_CONTENT, {
    status: 200,
    headers: {
      "Content-Type": "application/manifest+json; charset=utf-8",
      "Cache-Control": "public, max-age=3600",
    },
  });
});

api.get("/.well-known/assetlinks.json", (c) => {
  return c.json(ASSET_LINKS_CONTENT, 200, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "public, max-age=86400",
  });
});

// -----------------------------------------------------------------------------
// 2. GESTÃO DE LOJAS (Criação e Leitura no D1 / KV)
// -----------------------------------------------------------------------------

// POST /api/lojas - Cadastra uma nova loja no Cloudflare D1 / KV com dados completos
api.post("/lojas", async (c) => {
  try {
    const body = await c.req.json();
    const db = getDb(c);

    // Validação dos dados obrigatórios
    const nome = body.nome || body.name;
    const email = body.email;
    const senha = body.senha || body.password || "123456";

    if (!nome || typeof nome !== "string" || !nome.trim()) {
      return c.json({
        success: false,
        error: "O nome da loja (nome/name) é obrigatório.",
      }, 400);
    }

    if (!email || typeof email !== "string" || !email.includes("@")) {
      return c.json({
        success: false,
        error: "Um e-mail válido para a administração da loja é obrigatório.",
      }, 400);
    }

    const slug = body.slug ? String(body.slug).trim().toLowerCase() : undefined;
    const whatsapp = body.whatsapp ? String(body.whatsapp).replace(/\D/g, "") : "5511999999999";
    const horario = body.horario || body.hours || "18:00 - 23:30";
    const endereco = body.endereco || body.address || "Centro";
    const taxaEntrega = Number(body.taxaEntrega ?? body.deliveryFee ?? 5.0);
    const chavePix = body.chavePix || body.pixKey || email;
    const tipoChavePix = body.tipoChavePix || body.pixKeyType || "email";
    const corPrimaria = body.corPrimaria || body.primaryColor || "#E63946";
    const bannerImage = body.bannerImage || "";
    const logo = body.logo || "🍔";
    const slogan = body.slogan || body.tagline || `Lanches e porções artesanais - ${nome}`;
    const businessType = body.businessType || body.categoria || body.category || "Lanchonetes";

    // 1. Criar loja no D1 / KV
    const novaLoja = await db.createTenant({
      name: nome.trim(),
      slug,
      email: email.trim().toLowerCase(),
      whatsapp,
      pixKey: chavePix,
      pixKeyType: tipoChavePix,
      deliveryFee: isNaN(taxaEntrega) ? 5.0 : taxaEntrega,
      address: endereco,
      primaryColor: corPrimaria,
      bannerImage,
      businessType,
    });

    // Se houver campos adicionais de horário, logo ou slogan, atualiza
    if (horario || logo || slogan) {
      await db.updateTenant(novaLoja.id, {
        hours: horario,
        logo,
        tagline: slogan,
      });
      novaLoja.hours = horario;
      novaLoja.logo = logo;
      novaLoja.tagline = slogan;
    }

    // 2. Criar usuário administrador para o lojista
    const usuario = await db.createUser({
      email: email.trim().toLowerCase(),
      password: senha,
      name: `Admin ${nome}`,
      role: "tenant_admin",
      tenantId: novaLoja.id,
    });

    return c.json({
      success: true,
      message: "Loja cadastrada com sucesso no Cloudflare D1/KV!",
      loja: novaLoja,
      admin: usuario,
    }, 201);
  } catch (err: any) {
    return c.json({
      success: false,
      error: err.message || "Erro interno ao cadastrar loja.",
    }, 500);
  }
});

// -----------------------------------------------------------------------------
// REQUISITO 1: CADASTRO INTELIGENTE POR IA (CARDÁPIO + GERADOR/EXTRATOR DE LOGO)
// POST /api/admin/lojas/importar-cardapio
// -----------------------------------------------------------------------------
function slugifyText(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, "-")
    .replace(/[^\w-]+/g, "")
    .replace(/--+/g, "-");
}

function _getFoodPlaceholderImage(category: string, name: string): string {
  const c = (category + " " + name).toLowerCase();
  if (c.includes("hamburg") || c.includes("burg") || c.includes("artesanal") || c.includes("cheeseburg") || c.includes("sanduich")) {
    return "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("pizza") || c.includes("calzone")) {
    return "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("pastel") || c.includes("pasteis") || c.includes("salgado") || c.includes("coxinha") || c.includes("kibe") || c.includes("empada")) {
    return "https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("batata") || c.includes("frita") || c.includes("porcao") || c.includes("porção") || c.includes("petisco") || c.includes("mandioca") || c.includes("calabresa") || c.includes("frango a passarinho")) {
    return "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("refrigerante") || c.includes("coca") || c.includes("suco") || c.includes("cerveja") || c.includes("bebida") || c.includes("agua") || c.includes("água") || c.includes("drink")) {
    return "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("acai") || c.includes("açaí") || c.includes("sorvete") || c.includes("sobremesa") || c.includes("pudim") || c.includes("doce") || c.includes("brownie") || c.includes("torta")) {
    return "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("hot dog") || c.includes("cachorro quente") || c.includes("dog")) {
    return "https://images.unsplash.com/photo-1619740455993-9e612b1af08a?auto=format&fit=crop&w=800&q=80";
  }
  if (c.includes("massa") || c.includes("macarrao") || c.includes("macarrão") || c.includes("lasanha") || c.includes("espaguete")) {
    return "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=800&q=80";
  }
  return "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80";
}

const handleImportarCardapio = async (c: any) => {
  try {
    const db = getDb(c);
    const body = await c.req.json();
    const { apiKey: bodyApiKey, images, customLogoUrl, additionalPrompt, promptAdicional } = body;
    const extraPrompt = (
      typeof additionalPrompt === "string"
        ? additionalPrompt
        : typeof promptAdicional === "string"
        ? promptAdicional
        : ""
    ).trim();

    // Prioridade da chave: body.apiKey -> body.geminiApiKey -> header x-gemini-api-key -> platformSettings.geminiApiKey -> c.env.GEMINI_API_KEY -> process.env.GEMINI_API_KEY
    const platformSettings = await db.getPlatformSettings();
    const apiKey =
      (typeof bodyApiKey === "string" && bodyApiKey.trim()) ||
      (typeof body.geminiApiKey === "string" && body.geminiApiKey.trim()) ||
      c.req.header("x-gemini-api-key")?.trim() ||
      platformSettings?.geminiApiKey ||
      c.env?.GEMINI_API_KEY ||
      (typeof process !== "undefined" && process?.env?.GEMINI_API_KEY
        ? process.env.GEMINI_API_KEY
        : undefined);

    if (!apiKey) {
      return c.json(
        {
          success: false,
          error:
            "A chave da API do Gemini não foi encontrada. Cole sua chave no campo 'Cole sua Chave de API do Gemini aqui' no modal ou configure a variável GEMINI_API_KEY.",
        },
        400
      );
    }

    const rawImages: any[] = Array.isArray(images)
      ? images
      : Array.isArray(body.files)
      ? body.files
      : body.fileBase64
      ? [body.fileBase64]
      : [];

    const filesToProcess: MenuFileInput[] = [];

    for (const img of rawImages) {
      if (typeof img === "string") {
        let mimeType = "image/jpeg";
        let base64Data = img.trim();
        const match = base64Data.match(/^data:([^;]+);base64,(.*)$/s);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
        if (base64Data) {
          filesToProcess.push({
            data: base64Data,
            mimeType,
          });
        }
      } else if (img && typeof img === "object") {
        const rawData = (img.data || img.fileBase64 || "").trim();
        let mimeType = img.mimeType || "image/jpeg";
        let base64Data = rawData;
        const match = rawData.match(/^data:([^;]+);base64,(.*)$/s);
        if (match) {
          mimeType = match[1];
          base64Data = match[2];
        }
        if (base64Data) {
          filesToProcess.push({
            data: base64Data,
            mimeType,
            fileName: img.fileName,
          });
        }
      }
    }

    if (filesToProcess.length === 0) {
      return c.json(
        {
          success: false,
          error:
            "Nenhum arquivo ou foto do cardápio foi recebido. Selecione uma ou mais fotos (JPG/PNG) ou documento PDF do cardápio.",
        },
        400
      );
    }

    // 1. Extração estruturada multimodal de todas as imagens em lote via Gemini
    const extracted = await analyzeMenuWithGemini(
      filesToProcess,
      apiKey,
      extraPrompt
    );

    const nomeLoja = extracted.nome_loja?.trim() || "Nova Lanchonete";
    const primaryColor = extracted.primary_color || "#E63946";
    const logoUrl = customLogoUrl || extracted.logo_url || "🍔";
    const baseSlug = slugifyText(nomeLoja);

    const adminEmail = `admin@${baseSlug}.com`;
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let adminPassword = "";
    for (let i = 0; i < 6; i++) {
      adminPassword += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    // 2. Gravando no Cloudflare D1 / KV
    const novaLoja = await db.createTenant({
      name: nomeLoja,
      email: adminEmail,
      phone: extracted.telefone,
      whatsapp: extracted.telefone || "5511999999999",
      deliveryFee: 5.0,
      address: "Endereço da Loja",
      tagline: extracted.descricao,
      logo: logoUrl,
      primaryColor,
    });

    // 3. Cadastrar usuário administrador da loja no D1
    const adminUser = await db.createUser({
      email: adminEmail,
      password: adminPassword,
      name: `Admin ${novaLoja.name}`,
      role: "tenant_admin",
      tenantId: novaLoja.id,
    });

    // 4. Cadastrar categorias e produtos vinculados ao ID da nova loja
    const produtosCriados: any[] = [];
    if (Array.isArray(extracted.categorias)) {
      for (const cat of extracted.categorias) {
        const catName = cat.nome?.trim() || "Geral";
        const catSlug = catName.toLowerCase();
        if (Array.isArray(cat.produtos)) {
          for (const prod of cat.produtos) {
            const prodName = prod.nome?.trim() || "Item";
            const prodDesc = prod.descricao?.trim() || "";
            const prodImg = getProductImage(prodName, `${catName} ${catSlug} ${prodDesc}`);

            const novoProduto = await db.createProduct(novaLoja.id, {
              name: prodName,
              description: prodDesc,
              price: Number(prod.preco) || 0,
              category: catSlug,
              image: prodImg,
              available: true,
              options: Array.isArray(prod.opcionais)
                ? prod.opcionais.map((opt: any, idx: number) => ({
                    id: `opt-${idx + 1}`,
                    name: opt.nome,
                    price: Number(opt.preco) || 0,
                  }))
                : [],
            });
            produtosCriados.push(novoProduto);
          }
        }
      }
    }

    return c.json(
      {
        success: true,
        message: "Lanchonete, cardápio e logo criados com sucesso pela IA!",
        tenant: novaLoja,
        adminUser,
        credentials: {
          email: adminEmail,
          password: adminPassword,
        },
        categoriasCount: extracted.categorias?.length || 0,
        produtosCount: produtosCriados.length,
        produtos: produtosCriados,
        products: produtosCriados,
        hasLogo: extracted.has_logo,
        logoBoundingBox: extracted.logo_bounding_box,
        logoUrl,
        extractedData: {
          nome_loja: extracted.nome_loja,
          descricao: extracted.descricao,
          telefone: extracted.telefone,
          primaryColor,
        },
      },
      201
    );
  } catch (err: any) {
    console.error("Erro na rota importar-cardapio:", err);
    let errorMsg = err.message || "Falha ao importar e processar cardápio com a IA.";
    const lower = errorMsg.toLowerCase();
    const isOverloaded =
      err.status === 503 ||
      err.status === 429 ||
      lower.includes("503") ||
      lower.includes("429") ||
      lower.includes("high demand") ||
      lower.includes("alta demanda") ||
      lower.includes("unavailable") ||
      lower.includes("resource_exhausted") ||
      lower.includes("overloaded");

    if (isOverloaded) {
      errorMsg =
        "Os servidores do Gemini estão com alta demanda temporária. Por favor, aguarde alguns segundos e clique em Gerar novamente.";
    }

    return c.json(
      {
        success: false,
        error: errorMsg,
      },
      isOverloaded ? 503 : 500
    );
  }
};

api.post("/admin/lojas/importar-cardapio", handleImportarCardapio);
api.post("/lojas/importar-cardapio", handleImportarCardapio);

// -----------------------------------------------------------------------------
// ENDPOINT: CADASTRO AUTOMÁTICO DE CARDÁPIO VIA GEMINI 2.5 FLASH
// POST /api/loja/cadastrar-auto & POST /loja/cadastrar-auto
// Suporta Multipart Form (File + Prompt) e JSON (Base64) compatível com Cloudflare Workers & Node.js
// -----------------------------------------------------------------------------
const handleCadastrarAuto = async (c: any) => {
  try {
    let promptTexto = "";
    let base64Image = "";
    let mimeType = "image/jpeg";

    const contentType = c.req.header("content-type") || "";

    if (contentType.includes("multipart/form-data") || contentType.includes("application/x-www-form-urlencoded")) {
      const body = await c.req.parseBody();
      promptTexto = (body["prompt"] as string) || "";
      const imagemArquivo = body["file"] as any;

      // Converte a imagem enviada para Base64 nativo (compatível com Cloudflare Workers e Node.js)
      if (imagemArquivo && typeof imagemArquivo === "object") {
        if (typeof imagemArquivo.arrayBuffer === "function") {
          const arrayBuffer = await imagemArquivo.arrayBuffer();
          const uint8Array = new Uint8Array(arrayBuffer);
          let binaryString = "";
          for (let i = 0; i < uint8Array.byteLength; i++) {
            binaryString += String.fromCharCode(uint8Array[i]);
          }
          base64Image = btoa(binaryString);
          mimeType = imagemArquivo.type || "image/jpeg";
        }
      }
    } else {
      const jsonBody = await c.req.json().catch(() => ({}));
      promptTexto = jsonBody.prompt || "";
      if (jsonBody.file) {
        const raw = String(jsonBody.file);
        const match = raw.match(/^data:([a-zA-Z0-9/+-]+);base64,(.+)$/);
        if (match) {
          mimeType = match[1];
          base64Image = match[2];
        } else {
          base64Image = raw;
        }
      }
    }

    const contentsParts: any[] = [];

    if (base64Image) {
      contentsParts.push({
        inlineData: {
          mimeType: mimeType || "image/jpeg",
          data: base64Image,
        },
      });
    }

    // Anexa o texto/prompt se fornecido
    if (promptTexto) {
      contentsParts.push({ text: promptTexto });
    }

    if (contentsParts.length === 0) {
      return c.json(
        { error: "Envie uma foto do cardápio ou o texto com as instruções." },
        400
      );
    }

    // Obter a GEMINI_API_KEY do ambiente do Cloudflare Workers ou variáveis do sistema
    const apiKey =
      c.env?.GEMINI_API_KEY ||
      (typeof process !== "undefined" && process.env?.GEMINI_API_KEY) ||
      c.req.header("x-gemini-api-key");

    if (!apiKey) {
      return c.json(
        { error: "GEMINI_API_KEY não configurada no ambiente." },
        500
      );
    }

    // Chamada à API do Gemini 2.5 Flash
    const responseGemini = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: contentsParts }],
          systemInstruction: {
            parts: [
              {
                text: `Você é o assistente de cadastro automático do Top Food.
Sua missão é extrair e cadastrar TODOS os produtos, categorias, opções e complementos do cardápio.
REGRAS OBRIGATÓRIAS:
1. Se a informação vier por FOTO DO CARDÁPIO, leia todo o texto contido na imagem com OCR.
2. Se a informação vier por TEXTO DIGITADO, processe a lista inteira de ponta a ponta.
3. NUNCA resuma, corte ou limite a 2 produtos por categoria. Extraia 100% dos itens presentes na foto ou no texto.`,
              },
            ],
          },
          generationConfig: {
            responseMimeType: "application/json",
            maxOutputTokens: 8192,
          },
        }),
      }
    );

    if (!responseGemini.ok) {
      const errorText = await responseGemini.text();
      return c.json({ error: "Erro na API do Gemini", details: errorText }, 500);
    }

    const data: any = await responseGemini.json();
    const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!responseText) {
      return c.json({ error: "Nenhuma resposta gerada pela IA." }, 500);
    }

    const menuData = JSON.parse(responseText);

    return c.json({ success: true, menu: menuData });
  } catch (err: any) {
    return c.json(
      { error: "Falha ao processar requisição", message: err.message },
      500
    );
  }
};

api.post("/loja/cadastrar-auto", handleCadastrarAuto);
api.post("/api/loja/cadastrar-auto", handleCadastrarAuto);

// -----------------------------------------------------------------------------
// GERAÇÃO DE FOTO DE PRODUTO COM IA (GEMINI + POLLINATIONS AI / BRAND PHOTOS)
// POST /api/produtos/gerar-foto-ia & POST /api/admin/produtos/gerar-foto-ia
// -----------------------------------------------------------------------------
const handleGerarFotoIa = async (c: any) => {
  try {
    const body = await c.req.json().catch(() => ({}));
    const { name, category, description, apiKey: bodyApiKey, geminiApiKey } = body;
    const prodName = (name || "").trim();
    if (!prodName) {
      return c.json({ success: false, error: "Nome do produto não informado." }, 400);
    }
    const catName = (category || "").trim();
    const desc = (description || "").trim();

    // Prioridade da chave da API do Gemini:
    // 1. Chave enviada no corpo da requisição (body.apiKey ou body.geminiApiKey)
    // 2. Header HTTP 'x-gemini-api-key'
    // 3. Chave global da plataforma salva no banco (platformSettings.geminiApiKey)
    // 4. Variável de ambiente c.env.GEMINI_API_KEY (Cloudflare)
    // 5. process.env.GEMINI_API_KEY (Node/Dev)
    const platformSettings = await db.getPlatformSettings();
    const apiKey =
      (typeof bodyApiKey === "string" && bodyApiKey.trim()) ||
      (typeof geminiApiKey === "string" && geminiApiKey.trim()) ||
      c.req.header("x-gemini-api-key")?.trim() ||
      platformSettings?.geminiApiKey ||
      c.env?.GEMINI_API_KEY ||
      (typeof process !== "undefined" && process?.env?.GEMINI_API_KEY
        ? process.env.GEMINI_API_KEY
        : undefined);

    let generatedImageUrl = "";
    let promptUsed = "";

    // 1. Tentar gerar com Gemini se houver API key configurada
    if (apiKey) {
      const ai = getGeminiClient(apiKey);
      if (ai) {
        try {
          const prompt = `Você é um diretor de arte culinário e fotógrafo profissional de cardápios de delivery de comida.
Analise com atenção o produto alimentício a seguir:
- Nome: "${prodName}"
- Categoria: "${catName || "Geral"}"
- Descrição: "${desc || "Item de restaurante"}"

Retorne EXCLUSIVAMENTE um objeto JSON válido (sem texto fora do JSON) com a estrutura:
{
  "imageUrl": "URL direta da imagem profissional e realista",
  "isBebidaMarca": true ou false,
  "termoIngles": "termo descritivo em inglês para a foto"
}

Diretrizes estritas:
1. Bebidas Industriais de Marca Conhecida (ex: Coca-Cola, Coca Zero, Guaraná Antarctica, Fanta, Sprite, Schweppes, Heineken, Stella Artois, Cervejas, Água Mineral, Red Bull, etc.):
   - Defina "isBebidaMarca": true.
   - Retorne a foto oficial da embalagem/lata/garrafa em alta resolução (ex: https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=600&q=80 para Coca-Cola).
2. Pratos, Hambúrgueres, Lanches, Pastéis, Pizzas, Porções, Salgados, Carnes, Sucos, Açaí e Sobremesas:
   - Defina "isBebidaMarca": false.
   - Crie uma descrição detalhada e apetitosa em inglês em termos de fotografia gastronômica de restaurante (ex: 'gourmet artisan bacon cheeseburger with melted cheddar and crispy fries', 'crispy golden french fries in basket', 'hot pepperoni pizza with melted cheese', 'brazilian acai bowl topped with banana strawberries and granola').
   - Monte a URL dinâmica do Pollinations AI:
     https://image.pollinations.ai/prompt/\${encodeURIComponent("professional photo of " + termoIngles + " food")}?width=600&height=600&nologo=true
   - Ou utilize uma foto correspondente do Unsplash Food.`;

          const candidateModels = ["gemini-3.8-flash", "gemini-2.5-flash", "gemini-3.1-flash-lite"];
          for (const model of candidateModels) {
            try {
              const res = await ai.models.generateContent({
                model,
                contents: prompt,
                config: {
                  responseMimeType: "application/json",
                },
              });
              if (res?.text) {
                const parsed = JSON.parse(res.text);
                const rawUrl = parsed.imageUrl || parsed.photoUrl || parsed.image || "";
                if (rawUrl && typeof rawUrl === "string") {
                  let cleanedUrl = rawUrl.trim();
                  if (cleanedUrl.includes("pollinations.ai/p/")) {
                    cleanedUrl = cleanedUrl
                      .replace("https://pollinations.ai/p/", "https://image.pollinations.ai/prompt/")
                      .replace("http://pollinations.ai/p/", "https://image.pollinations.ai/prompt/")
                      .replace("&width=", "?width=");
                  } else if (cleanedUrl.includes("image.pollinations.ai/prompt/") && cleanedUrl.includes("&width=") && !cleanedUrl.includes("?width=")) {
                    cleanedUrl = cleanedUrl.replace("&width=", "?width=");
                  } else if (cleanedUrl.startsWith("/9j/") || cleanedUrl.startsWith("iVBOR")) {
                    const mime = cleanedUrl.startsWith("iVBOR") ? "image/png" : "image/jpeg";
                    cleanedUrl = `data:${mime};base64,${cleanedUrl}`;
                  }
                  if (cleanedUrl.startsWith("http") || cleanedUrl.startsWith("data:image/")) {
                    generatedImageUrl = cleanedUrl;
                    promptUsed = parsed.termoIngles || "";
                    break;
                  }
                }
              }
            } catch (mErr) {
              console.warn(`[Foto IA] Tentativa com modelo ${model} falhou:`, mErr);
            }
          }
        } catch (aiErr) {
          console.warn("[Foto IA] Erro ao consultar Gemini para foto:", aiErr);
        }
      }
    }

    // 2. Se a IA gerou a URL válida, utiliza ela. Senão, ativa o gerador local inteligente
    if (!generatedImageUrl) {
      generatedImageUrl = generateProductImageUrl(prodName, catName, desc);
    }

    return c.json({
      success: true,
      imageUrl: generatedImageUrl,
      photoUrl: generatedImageUrl,
      name: prodName,
      prompt: promptUsed,
      source: apiKey ? "gemini" : "smart-generator",
    });
  } catch (error: any) {
    console.error("[Foto IA] Erro ao processar requisição:", error);
    return c.json({
      success: false,
      error: error?.message || "Erro interno ao gerar foto do produto com IA.",
    }, 500);
  }
};

api.post("/produtos/gerar-foto-ia", handleGerarFotoIa);
api.post("/admin/produtos/gerar-foto-ia", handleGerarFotoIa);

// -----------------------------------------------------------------------------
// REQUISITO 2: PWA E MANIFEST DINÂMICO DA VITRINE
// GET /api/pwa/manifest.json?slug=SLUG_DA_LOJA ou GET /api/manifest/:slug.json
// -----------------------------------------------------------------------------
const handleDynamicManifest = async (c: any) => {
  try {
    const db = getDb(c);
    const querySlug = c.req.query("slug");
    const paramSlug = c.req.param("slug");
    const rawSlug = querySlug || paramSlug || "";
    const slug = rawSlug.replace(/\.json$/i, "").trim();

    if (!slug) {
      return c.json({ error: "Slug da loja não informado." }, 400);
    }

    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ error: "Loja não encontrada." }, 404);
    }

    const storeName = (loja.name || "Nova Lanchonete").trim();
    const shortName = storeName.length > 12 ? storeName.slice(0, 12).trim() : storeName;
    const logoUrl = loja.logo && loja.logo.trim() ? loja.logo.trim() : "/icon-512.png";
    const isSvg = logoUrl.includes("image/svg+xml") || logoUrl.endsWith(".svg");
    const iconType = isSvg ? "image/svg+xml" : "image/png";

    const manifest = {
      id: `/loja/${loja.slug}`,
      name: storeName,
      short_name: shortName,
      start_url: `/loja/${loja.slug}`,
      scope: `/loja/${loja.slug}`,
      display: "standalone",
      orientation: "portrait",
      background_color: "#ffffff",
      theme_color: loja.primaryColor || "#dc2626",
      description: `Peça os melhores lanches em ${storeName}. Delivery rápido e prático.`,
      icons: [
        {
          src: logoUrl,
          sizes: "192x192",
          type: iconType,
          purpose: "any",
        },
        {
          src: logoUrl,
          sizes: "512x512",
          type: iconType,
          purpose: "any",
        },
        {
          src: logoUrl,
          sizes: "512x512",
          type: iconType,
          purpose: "maskable",
        },
      ],
    };

    return c.json(manifest, 200, {
      "Content-Type": "application/manifest+json; charset=utf-8",
      "Cache-Control": "public, max-age=300",
    });
  } catch (err: any) {
    return c.json({ error: err.message || "Erro ao gerar manifest dinâmico." }, 500);
  }
};

api.get("/pwa/manifest.json", handleDynamicManifest);
api.get("/pwa/manifest", handleDynamicManifest);
api.get("/manifest/:slug", handleDynamicManifest);

// GET /api/lojas - Lista todas as lojas cadastradas
api.get("/lojas", async (c) => {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    c.header("Pragma", "no-cache");
    c.header("Expires", "0");
    const db = getDb(c);
    const lojas = await db.getTenants();

    const enriquecidas = await Promise.all(
      lojas.map(async (l) => {
        const [produtos, pedidos] = await Promise.all([
          db.getProductsByTenant(l.id),
          db.getOrdersByTenant(l.id),
        ]);
        return {
          ...l,
          totalProdutos: produtos.length,
          totalPedidos: pedidos.length,
          faturamento: pedidos.reduce((acc, p) => acc + (p.total || 0), 0),
        };
      })
    );

    return c.json({ success: true, lojas: enriquecidas }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao listar lojas." }, 500);
  }
});

// GET /api/lojas/:slug - Busca os dados de uma loja específica pelo slug (ex: 'marcelino')
api.get("/lojas/:slug", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");

    if (!slug) {
      return c.json({ success: false, error: "Slug da loja não informado." }, 400);
    }

    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({
        success: false,
        error: `Nenhuma loja encontrada com o slug '${slug}'.`,
      }, 404);
    }

    return c.json({
      success: true,
      loja,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao buscar loja." }, 500);
  }
});

// PUT /api/lojas/:slug - Atualiza dados e configurações da loja
api.put("/lojas/:slug", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const body = await c.req.json();

    const loja = await db.getTenantByIdOrSlug(slug);
    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    // Mapear campos em português para o modelo
    const partial: any = {};
    if (body.nome || body.name) partial.name = body.nome || body.name;
    if (body.horario || body.hours) partial.hours = body.horario || body.hours;
    if (body.endereco || body.address) partial.address = body.endereco || body.address;
    if (body.whatsapp) partial.whatsapp = String(body.whatsapp).replace(/\D/g, "");
    if (body.taxaEntrega !== undefined || body.deliveryFee !== undefined) {
      partial.deliveryFee = Number(body.taxaEntrega ?? body.deliveryFee);
    }
    if (body.chavePix || body.pixKey) partial.pixKey = body.chavePix || body.pixKey;
    if (body.tipoChavePix || body.pixKeyType) partial.pixKeyType = body.tipoChavePix || body.pixKeyType;
    if (body.corPrimaria || body.primaryColor) partial.primaryColor = body.corPrimaria || body.primaryColor;
    if (body.bannerImage !== undefined) partial.bannerImage = body.bannerImage;
    if (body.logo) partial.logo = body.logo;
    if (body.slogan || body.tagline) partial.tagline = body.slogan || body.tagline;
    if (body.isOpen !== undefined) partial.isOpen = Boolean(body.isOpen);

    const atualizada = await db.updateTenant(loja.id, partial);
    return c.json({
      success: true,
      message: "Configurações da loja atualizadas com sucesso no Cloudflare D1/KV.",
      loja: atualizada,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao atualizar loja." }, 500);
  }
});

// PATCH /api/lojas/:slug/status - Ativa ou desativa a loja
api.patch("/lojas/:slug/status", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const body = await c.req.json();
    const status: TenantStatus = body.status;

    if (!["active", "inactive"].includes(status)) {
      return c.json({
        success: false,
        error: "Status inválido. Use 'active' ou 'inactive'.",
      }, 400);
    }

    const loja = await db.getTenantByIdOrSlug(slug);
    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const atualizada = await db.setTenantStatus(loja.id, status);
    return c.json({
      success: true,
      message: `Loja ${status === "active" ? "ativada" : "desativada"} com sucesso.`,
      loja: atualizada,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao alterar status." }, 500);
  }
});

// -----------------------------------------------------------------------------
// 3. CARDÁPIO E PRODUTOS (D1 & KV)
// -----------------------------------------------------------------------------

// GET /api/lojas/:slug/produtos - Listar todos os produtos de uma loja
api.get("/lojas/:slug/produtos", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const produtos = await db.getProductsByTenant(loja.id);
    return c.json({
      success: true,
      loja: { id: loja.id, nome: loja.name, slug: loja.slug },
      produtos,
      products: produtos,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao listar produtos." }, 500);
  }
});

// GET /api/lojas/:slug/categorias - Agrupamento de categorias com produtos
api.get("/lojas/:slug/categorias", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const produtos = await db.getProductsByTenant(loja.id);
    const categoriasMap: Record<string, typeof produtos> = {};

    produtos.forEach((p) => {
      const cat = p.category || "Geral";
      if (!categoriasMap[cat]) {
        categoriasMap[cat] = [];
      }
      categoriasMap[cat].push(p);
    });

    const resultado = Object.entries(categoriasMap).map(([nome, itens]) => ({
      categoria: nome,
      totalItens: itens.length,
      produtos: itens,
    }));

    return c.json({ success: true, categorias: resultado }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao obter categorias." }, 500);
  }
});

// GET /api/lojas/:slug/lista-categorias - Listar categorias cadastradas para a loja
api.get("/lojas/:slug/lista-categorias", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const categories = await db.getCategoriesByTenant(loja.id);
    return c.json({ success: true, categories, categorias: categories }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao obter categorias." }, 500);
  }
});

// POST /api/lojas/:slug/categorias - Criar nova categoria diretamente
api.post("/lojas/:slug/categorias", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const body = await c.req.json();
    const nome = body.nome || body.name;

    if (!nome || typeof nome !== "string" || !nome.trim()) {
      return c.json({ success: false, error: "O nome da categoria é obrigatório." }, 400);
    }

    const novaCategoria = await db.createCategory(loja.id, {
      name: nome.trim(),
      icon: body.icone || body.icon || "🍽️",
    });

    return c.json({
      success: true,
      message: "Categoria cadastrada com sucesso!",
      category: novaCategoria,
      categoria: novaCategoria,
    }, 201);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao criar categoria." }, 500);
  }
});

// PUT /api/lojas/:slug/produtos/reordenar - Salvar reordenação de produtos em lote
api.put("/lojas/:slug/produtos/reordenar", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const body = await c.req.json();
    const orderedIds = body.orderedIds || body.ordem || body.ids || [];

    if (!Array.isArray(orderedIds)) {
      return c.json({ success: false, error: "orderedIds deve ser uma lista de IDs de produtos." }, 400);
    }

    await db.reorderProducts(loja.id, orderedIds);

    return c.json({
      success: true,
      message: "Ordem dos produtos atualizada com sucesso no Cloudflare D1/KV!",
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao reordenar produtos." }, 500);
  }
});

// POST /api/lojas/:slug/produtos - Cadastrar novo produto na loja
api.post("/lojas/:slug/produtos", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const body = await c.req.json();
    const nome = body.nome || body.name;
    const preco = Number(body.preco ?? body.price);

    if (!nome || typeof nome !== "string" || !nome.trim()) {
      return c.json({ success: false, error: "O nome do produto é obrigatório." }, 400);
    }

    if (isNaN(preco) || preco < 0) {
      return c.json({ success: false, error: "Preço do produto deve ser um número válido positivo." }, 400);
    }

    // Se uma nova categoria foi informada, salva primeiro no banco de dados e vincula
    let categoriaFinal = body.categoria || body.category || "lanches";
    const novaCategoriaNome = body.novaCategoria || body.newCategoryName || body.newCategory;
    if (novaCategoriaNome && typeof novaCategoriaNome === "string" && novaCategoriaNome.trim()) {
      const catCriada = await db.createCategory(loja.id, { name: novaCategoriaNome.trim() });
      categoriaFinal = catCriada.id;
    }

    const novoProduto = await db.createProduct(loja.id, {
      name: nome.trim(),
      description: body.descricao || body.description || "",
      price: preco,
      category: categoriaFinal,
      image: body.imagem || body.image || "",
      available: body.disponivel !== undefined ? Boolean(body.disponivel) : body.available !== undefined ? Boolean(body.available) : true,
      options: body.opcionais || body.options || [],
      position: body.position !== undefined ? Number(body.position) : (body.ordem !== undefined ? Number(body.ordem) : undefined),
      ordem: body.ordem !== undefined ? Number(body.ordem) : (body.position !== undefined ? Number(body.position) : undefined),
    });

    return c.json({
      success: true,
      message: "Produto cadastrado com sucesso no Cloudflare D1/KV!",
      produto: novoProduto,
    }, 201);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao criar produto." }, 500);
  }
});

// PUT /api/lojas/:slug/produtos/:id - Editar produto
api.put("/lojas/:slug/produtos/:id", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const produtoId = c.req.param("id");
    const body = await c.req.json();

    const loja = await db.getTenantByIdOrSlug(slug);

    const partial: any = {};
    if (body.nome || body.name) partial.name = body.nome || body.name;
    if (body.descricao !== undefined || body.description !== undefined) {
      partial.description = body.descricao !== undefined ? body.descricao : body.description;
    }
    if (body.preco !== undefined || body.price !== undefined) {
      partial.price = Number(body.preco ?? body.price);
    }
    if (body.categoria || body.category) partial.category = body.categoria || body.category;

    // Se uma nova categoria foi informada na edição
    const novaCategoriaNome = body.novaCategoria || body.newCategoryName || body.newCategory;
    if (novaCategoriaNome && typeof novaCategoriaNome === "string" && novaCategoriaNome.trim()) {
      const tenantId = loja ? loja.id : slug;
      const catCriada = await db.createCategory(tenantId, { name: novaCategoriaNome.trim() });
      partial.category = catCriada.id;
    }

    if (body.imagem !== undefined || body.image !== undefined) {
      partial.image = body.imagem !== undefined ? body.imagem : body.image;
    }
    if (body.disponivel !== undefined || body.available !== undefined) {
      partial.available = Boolean(body.disponivel ?? body.available);
    }
    if (body.opcionais || body.options) partial.options = body.opcionais || body.options;
    if (body.position !== undefined || body.ordem !== undefined) {
      const pos = Number(body.position ?? body.ordem);
      partial.position = pos;
      partial.ordem = pos;
    }

    const atualizado = await db.updateProduct(produtoId, partial);
    if (!atualizado) {
      return c.json({ success: false, error: "Produto não encontrado." }, 404);
    }

    return c.json({
      success: true,
      message: "Produto atualizado com sucesso no Cloudflare D1/KV.",
      produto: atualizado,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao atualizar produto." }, 500);
  }
});

// DELETE /api/lojas/:slug/produtos/:id - Remover produto
api.delete("/lojas/:slug/produtos/:id", async (c) => {
  try {
    const db = getDb(c);
    const produtoId = c.req.param("id");

    await db.deleteProduct(produtoId);
    return c.json({
      success: true,
      message: "Produto removido com sucesso do Cloudflare D1/KV.",
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao excluir produto." }, 500);
  }
});

// -----------------------------------------------------------------------------
// 4. FLUXO COMPLETO DE PEDIDOS (D1 & KV)
// -----------------------------------------------------------------------------

// POST /api/pedidos - Criar novo pedido no Cloudflare D1 / KV
api.post("/pedidos", async (c) => {
  try {
    const db = getDb(c);
    const body = await c.req.json();

    console.log("[POST /api/pedidos] [1] Recebido payload:", {
      cliente: body.cliente || body.customerName,
      telefone: body.telefone || body.customerPhone,
      loja: body.lojaSlug || body.slug || body.lojaId || body.tenantId || "marcelino",
      total: body.total,
      idempotency:
        c.req.header("x-idempotency-key") ||
        c.req.header("idempotency-key") ||
        body.idempotency_key ||
        body.idempotencyKey ||
        body.cart_id,
    });

    // 0. VERIFICAÇÃO DE IDEMPOTÊNCIA (Prevenção de pedidos duplicados após timeout ou retry do cliente)
    const rawIdempotency =
      c.req.header("x-idempotency-key") ||
      c.req.header("idempotency-key") ||
      body.idempotency_key ||
      body.idempotencyKey ||
      body.cart_id ||
      body.cartId ||
      undefined;

    if (rawIdempotency && typeof rawIdempotency === "string" && rawIdempotency.trim()) {
      const cleanKey = rawIdempotency.trim();
      console.log(`[POST /api/pedidos] [2] Verificando D1 para idempotência: ${cleanKey}`);
      try {
        const checkPromise = db.getOrderByIdempotencyKey(cleanKey, 5 * 60 * 1000);
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000));
        const existingOrder = await Promise.race([checkPromise, timeoutPromise]);
        if (existingOrder) {
          console.log(`[POST /api/pedidos] [2.1] Pedido existente encontrado (${existingOrder.id}) para chave: ${cleanKey}`);
          return c.json({
            success: true,
            orderId: existingOrder.id,
            id: existingOrder.id,
            duplicated: true,
            order: existingOrder,
            pedido: {
              ...existingOrder,
              statusPt: STATUS_MAP_EN_TO_PT[existingOrder.status] || existingOrder.status,
            },
            message: "Pedido já registrado anteriormente com sucesso (idempotência).",
          }, 200);
        }
      } catch (idempErr) {
        console.warn("[POST /api/pedidos] Verificação de idempotência demorou ou falhou, ignorando para prosseguir:", idempErr);
      }
    }

    // 1. Identificar a loja vinculada
    const lojaRef = body.lojaSlug || body.slug || body.lojaId || body.tenantId || "marcelino";
    const loja = await db.getTenantByIdOrSlug(lojaRef);

    if (!loja) {
      return c.json({
        success: false,
        error: `Loja '${lojaRef}' não encontrada para vinculação do pedido.`,
      }, 404);
    }

    if (loja.status === "inactive") {
      return c.json({
        success: false,
        error: "Esta loja está temporariamente fechada ou inativa no sistema.",
      }, 400);
    }

    // 2. Validação dos dados do cliente
    const cliente = body.cliente || body.customerName;
    const telefone = body.telefone || body.customerPhone;
    const itens = body.itens || body.items;

    if (!cliente || typeof cliente !== "string" || !cliente.trim()) {
      return c.json({ success: false, error: "Nome do cliente é obrigatório." }, 400);
    }

    if (!telefone || typeof telefone !== "string" || !telefone.trim()) {
      return c.json({ success: false, error: "Telefone do cliente é obrigatório." }, 400);
    }

    if (!Array.isArray(itens) || itens.length === 0) {
      return c.json({ success: false, error: "O pedido deve conter pelo menos 1 item." }, 400);
    }

    // 3. Normalização de valores e cálculos
    const tipoEntrega = body.tipoEntrega || body.orderType || "delivery";
    const rawMesa = body.tableNumber || body.table_number || body.numeroMesa || body.table || body.mesa || undefined;
    const cleanTableNumber = rawMesa && typeof rawMesa === "string" && rawMesa.trim() ? rawMesa.trim() : undefined;
    const formaPagamento = body.formaPagamento || body.paymentMethod || "pix";
    const endereco = body.endereco || body.address;
    const trocoPara = body.trocoPara || body.changeFor;
    const taxaEntrega = tipoEntrega === "delivery" ? Number(body.taxaEntrega ?? body.deliveryFee ?? loja.deliveryFee ?? 5.0) : 0;

    let subtotal = Number(body.subtotal);
    if (isNaN(subtotal) || subtotal <= 0) {
      subtotal = itens.reduce((sum: number, it: any) => {
        const precoItem = Number(it.product?.price ?? it.preco ?? it.price ?? 0);
        const qtd = Number(it.quantity ?? it.quantidade ?? 1);
        const opcionaisTotal = (it.selectedOptions || it.opcionais || []).reduce(
          (oSum: number, opt: any) => oSum + Number(opt.price || opt.preco || 0),
          0
        );
        return sum + (precoItem + opcionaisTotal) * qtd;
      }, 0);
    }

    const total = Number(body.total ?? (subtotal + taxaEntrega));
    const statusInicial: OrderStatus = normalizeOrderStatus(body.status || "Pendente");

    // 4. Salvar pedido no D1 e KV com chave de idempotência vinculada
    const cleanIdempotency = rawIdempotency && typeof rawIdempotency === "string" ? rawIdempotency.trim() : undefined;
    const comprovante = body.pix_receipt_url || body.pixReceiptUrl || body.comprovantePix || body.receipt || undefined;
    const tipoCartao = body.cardType || body.card_type || body.tipoCartao || undefined;
    const detalhesPgto = body.paymentDetails || body.payment_details || undefined;
    const locationUrl = body.location_url || body.locationUrl || undefined;

    console.log("[POST /api/pedidos] [2.5] Inserindo pedido no banco D1...");
    const novoPedido = await db.createOrder(loja.id, {
      customerName: cliente.trim(),
      customerPhone: telefone.trim(),
      orderType: tipoEntrega,
      tableNumber: cleanTableNumber,
      table_number: cleanTableNumber,
      mesa: cleanTableNumber,
      table: cleanTableNumber,
      idempotencyKey: cleanIdempotency,
      idempotency_key: cleanIdempotency,
      cart_id: cleanIdempotency,
      paymentMethod: formaPagamento,
      cardType: tipoCartao,
      paymentDetails: detalhesPgto,
      pixReceiptUrl: comprovante,
      pix_receipt_url: comprovante,
      location_url: locationUrl,
      locationUrl: locationUrl,
      address: endereco,
      changeFor: trocoPara,
      subtotal,
      deliveryFee: taxaEntrega,
      total,
      status: statusInicial,
      items: itens as OrderItem[],
      statusHistory: [{ status: statusInicial, timestamp: Date.now() }],
    });

    if (!novoPedido || !novoPedido.id) {
      return c.json({
        success: false,
        error: "Falha na confirmação de gravação do pedido no banco de dados. O pedido não foi criado.",
      }, 500);
    }

    console.log("[POST /api/pedidos] [3] Inserido com sucesso! Order ID:", novoPedido.id);

    // Dispara notificação push de alta prioridade para o lojista em segundo plano sem bloquear a resposta
    try {
      const pushPromise = sendNewOrderPushNotification(loja.id, novoPedido, c.env, () => db).catch((pushErr) => {
        console.warn("[Push] Erro assíncrono ao disparar notificação:", pushErr);
      });
      if ((c.executionCtx as any)?.waitUntil) {
        c.executionCtx.waitUntil(pushPromise);
      }
    } catch {
      // Background context error ignored
    }

    console.log("[POST /api/pedidos] [4] Resposta 200 enviada ao cliente com sucesso.");
    return c.json({
      success: true,
      message: "Pedido registrado com sucesso!",
      orderId: novoPedido.id,
      id: novoPedido.id,
      duplicated: false,
      order: novoPedido,
      pedido: {
        ...novoPedido,
        statusPt: STATUS_MAP_EN_TO_PT[novoPedido.status] || "Pendente",
        loja: { id: loja.id, nome: loja.name, slug: loja.slug },
      },
    }, 200);
  } catch (err: any) {
    console.error("[POST /api/pedidos] Erro fatal:", err);
    return c.json({ success: false, error: err.message || "Erro interno ao processar pedido." }, 500);
  }
});

// GET /api/pedidos - Listar pedidos (com suporte a filtro ?loja=marcelino)
api.get("/pedidos", async (c) => {
  try {
    const db = getDb(c);
    const lojaQuery = c.req.query("loja") || c.req.query("tenantId") || "marcelino";

    const loja = await db.getTenantByIdOrSlug(lojaQuery);
    if (!loja) {
      return c.json({ success: false, error: `Loja '${lojaQuery}' não encontrada.` }, 404);
    }

    const pedidos = await db.getOrdersByTenant(loja.id);
    const pedidosFormatados = pedidos.map((p) => ({
      ...p,
      statusPt: STATUS_MAP_EN_TO_PT[p.status] || p.status,
    }));

    return c.json({
      success: true,
      loja: { id: loja.id, nome: loja.name, slug: loja.slug },
      pedidos: pedidosFormatados,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao buscar pedidos." }, 500);
  }
});

// GET /api/lojas/:slug/pedidos - Listar pedidos de uma loja específica para o painel admin
api.get("/lojas/:slug/pedidos", async (c) => {
  try {
    const db = getDb(c);
    const slug = c.req.param("slug");
    const loja = await db.getTenantByIdOrSlug(slug);

    if (!loja) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }

    const pedidos = await db.getOrdersByTenant(loja.id);
    const formatados = pedidos.map((p) => ({
      ...p,
      statusPt: STATUS_MAP_EN_TO_PT[p.status] || p.status,
    }));

    return c.json({
      success: true,
      loja: { id: loja.id, nome: loja.name, slug: loja.slug },
      pedidos: formatados,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao obter pedidos da loja." }, 500);
  }
});

// ===================== ROTA DEDICADA DE LISTAGEM DE PEDIDOS DO LOJISTA: GET /api/pedidos/loja =====================
const handlePedidosLoja = async (c: any) => {
  try {
    const db = getDb(c);
    const storeParam =
      c.req.query("store_id") ||
      c.req.query("loja_id") ||
      c.req.query("lojaId") ||
      c.req.query("storeId") ||
      c.req.query("tenantId") ||
      c.req.query("tenant_id") ||
      c.req.query("loja") ||
      c.req.query("slug") ||
      c.req.param("lojaId") ||
      c.req.header("X-Tenant-Id") ||
      c.req.header("X-Store-Id") ||
      "";

    let targetTenantId = storeParam.trim();

    // Se nenhum tenant/loja informado via query/header, verificar autenticação (token do lojista)
    if (!targetTenantId) {
      const authHeader = c.req.header("Authorization") || c.req.header("authorization") || "";
      const token = authHeader.replace(/^Bearer\s+/i, "").trim();
      if (token) {
        try {
          const user = await db.getUserByToken(token);
          if (user?.tenantId) {
            targetTenantId = user.tenantId;
          }
        } catch {
          // ignore auth decode error
        }
      }
    }

    if (!targetTenantId) {
      // Retorna array JSON válido com status 200 (nunca status 500 ou null que quebre a tela)
      c.header("Cache-Control", "no-cache, no-store, must-revalidate");
      return c.json({ success: true, orders: [], pedidos: [], total: 0 }, 200);
    }

    // Resolve tenant para garantir ID e Slug corretos
    let tenantIdToSearch = targetTenantId;
    let tenantSlugToSearch = targetTenantId;
    try {
      const tenant = await db.getTenantByIdOrSlug(targetTenantId);
      if (tenant) {
        tenantIdToSearch = tenant.id;
        tenantSlugToSearch = tenant.slug || targetTenantId;
      }
    } catch {
      // fallback com targetTenantId direto
    }

    let orders: Order[] = [];

    // 1. Consulta SQL direta e veloz no Cloudflare D1 (sem re-executar ensureTables)
    if (c.env?.DB) {
      try {
        const d1Res = await c.env.DB.prepare(
          "SELECT * FROM orders WHERE tenant_id = ? OR tenant_id = ? ORDER BY created_at DESC, id DESC"
        )
          .bind(tenantIdToSearch, tenantSlugToSearch)
          .all<any>();

        if (d1Res?.results && Array.isArray(d1Res.results)) {
          orders = d1Res.results.map((r: any) => (db as any).mapOrderRow(r));
        }
      } catch (sqlErr) {
        console.warn("[/pedidos/loja] D1 query aviso:", sqlErr);
      }
    }

    // 2. Fallback direto para db.getOrdersByTenant
    if (!orders || orders.length === 0) {
      try {
        const fetched = await db.getOrdersByTenant(tenantIdToSearch);
        if (Array.isArray(fetched)) {
          orders = fetched;
        }
      } catch (dbErr) {
        console.warn("[/pedidos/loja] getOrdersByTenant fallback aviso:", dbErr);
      }
    }

    // Garante que é estritamente um array válido
    const safeOrders = Array.isArray(orders) ? orders : [];

    // Ordenação garantida do mais recente para o mais antigo (ORDER BY created_at DESC, id DESC)
    safeOrders.sort((a, b) => {
      const timeA = typeof a.createdAt === "number" ? a.createdAt : new Date(a.createdAt).getTime() || 0;
      const timeB = typeof b.createdAt === "number" ? b.createdAt : new Date(b.createdAt).getTime() || 0;
      return timeB - timeA;
    });

    c.header("Cache-Control", "no-cache, no-store, must-revalidate");
    c.header("Pragma", "no-cache");
    return c.json(
      {
        success: true,
        orders: safeOrders,
        pedidos: safeOrders,
        total: safeOrders.length,
      },
      200
    );
  } catch (err: any) {
    console.warn("[/pedidos/loja] Retornando array vazio seguro:", err);
    // REGRA DE OURO: Se houver qualquer erro de banco ou requisição, retorne obrigatoriamente um array JSON válido `[]` (nunca null, undefined ou 500)
    c.header("Cache-Control", "no-cache, no-store, must-revalidate");
    return c.json(
      {
        success: true,
        orders: [],
        pedidos: [],
        total: 0,
      },
      200
    );
  }
};

api.get("/pedidos/loja", handlePedidosLoja);
api.get("/pedidos/loja/:lojaId", handlePedidosLoja);

// GET /api/pedidos/:id - Detalhes de um pedido específico
api.get("/pedidos/:id", async (c) => {
  try {
    const pedidoId = c.req.param("id");
    if (pedidoId === "loja") {
      return handlePedidosLoja(c);
    }
    const db = getDb(c);
    const pedido = await db.getOrderById(pedidoId);

    if (!pedido) {
      return c.json({ success: false, error: "Pedido não encontrado." }, 404);
    }

    c.header("Cache-Control", "no-cache, no-store, must-revalidate");
    c.header("Pragma", "no-cache");
    c.header("Expires", "0");

    return c.json({
      success: true,
      orderId: pedido.id,
      status: pedido.status,
      statusPt: STATUS_MAP_EN_TO_PT[pedido.status] || pedido.status,
      order: pedido,
      pedido: {
        ...pedido,
        statusPt: STATUS_MAP_EN_TO_PT[pedido.status] || pedido.status,
      },
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao consultar pedido." }, 500);
  }
});

// PATCH, PUT & POST /api/pedidos/:id/status - Atualizar status do pedido de forma síncrona no D1
const handleStatusUpdate = async (c: any) => {
  try {
    const db = getDb(c);
    const pedidoId = c.req.param("id") || c.req.param("orderId");
    let body: any = {};
    try {
      body = await c.req.json();
    } catch {
      body = {};
    }
    const statusInput = body.status || body.novoStatus || body.novo_status;

    if (!statusInput) {
      return c.json({
        success: false,
        error: "O campo 'status' é obrigatório (ex: 'PENDENTE', 'EM_PREPARO', 'PRONTO', 'SAIU_PARA_ENTREGA', 'ENTREGUE', 'CANCELADO').",
      }, 400);
    }

    // Validação opcional de token JWT do lojista se enviado
    const authHeader = c.req.header("Authorization");
    if (authHeader) {
      const jwtSecret = getJwtSecret(c);
      const rawToken = authHeader.replace(/^Bearer\s+/i, "");
      await verifyTokenSafely(rawToken, jwtSecret);
    }

    const standardStatus = toStandardStatus(statusInput);
    const atualizado = await db.updateOrderStatus(pedidoId, standardStatus);

    if (!atualizado) {
      return c.json({ success: false, error: "Pedido não encontrado para atualização." }, 404);
    }

    // (KV já é atualizado em segundo plano dentro de db.updateOrderStatus)

    return c.json({
      success: true,
      status: standardStatus,
      message: `Status do pedido atualizado para '${standardStatus}' com sucesso no Cloudflare D1!`,
      pedido: {
        ...atualizado,
        status: standardStatus,
        statusPt: STATUS_MAP_EN_TO_PT[standardStatus] || STATUS_MAP_EN_TO_PT[toLegacyStatus(standardStatus)] || standardStatus,
      },
      order: {
        ...atualizado,
        status: standardStatus,
      },
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao atualizar status do pedido." }, 500);
  }
};

api.patch("/pedidos/:id/status", handleStatusUpdate);
api.put("/pedidos/:id/status", handleStatusUpdate);
api.post("/pedidos/:id/status", handleStatusUpdate);
api.patch("/pedidos/:id", handleStatusUpdate);
api.put("/pedidos/:id", handleStatusUpdate);
api.patch("/orders/:orderId/status", handleStatusUpdate);
api.put("/orders/:orderId/status", handleStatusUpdate);
api.post("/orders/:orderId/status", handleStatusUpdate);
api.patch("/tenants/:slugOrId/orders/:orderId/status", handleStatusUpdate);
api.put("/tenants/:slugOrId/orders/:orderId/status", handleStatusUpdate);
api.post("/tenants/:slugOrId/orders/:orderId/status", handleStatusUpdate);

// Consulta rápida de status do pedido para sincronização de clientes em 4G/5G
api.get("/orders/:orderId/status", async (c) => {
  try {
    const db = getDb(c);
    const orderId = c.req.param("orderId");
    const cleanId = orderId.replace(/^#/, "");

    const kv = (c.env?.KV || c.env?.STORE_KV);
    if (kv) {
      try {
        const cached = await kv.get(`order_status:${cleanId}`);
        if (cached) {
          const parsed = JSON.parse(cached);
          return c.json({
            success: true,
            orderId: parsed.orderId,
            status: parsed.status,
            statusPt: (STATUS_MAP_EN_TO_PT as Record<string, string>)[parsed.status] || parsed.status,
            updatedAt: parsed.updatedAt,
          }, 200);
        }
      } catch (kvErr) {
        console.warn("KV get order_status warning:", kvErr);
      }
    }

    const order = await db.getOrderById(orderId);
    if (!order) {
      return c.json({ success: false, error: "Pedido não encontrado" }, 404);
    }
    return c.json({
      success: true,
      orderId: order.id,
      status: order.status,
      statusPt: STATUS_MAP_EN_TO_PT[order.status] || order.status,
      order,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao consultar status" }, 500);
  }
});

// -----------------------------------------------------------------------------
// 5. ROTAS DE COMPATIBILIDADE COM A INTERFACE EXISTENTE (/tenants, /auth)
// -----------------------------------------------------------------------------

api.post("/auth/login", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, portal } = body;

    if (!email || !password) {
      return c.json({ success: false, error: "E-mail e senha são obrigatórios" }, 400);
    }

    const db = getDb(c);
    const user = await db.authenticateUser(email, password);

    if (!user) {
      return c.json({ success: false, error: "Credenciais inválidas ou conta inativa" }, 401);
    }

    // RBAC: Isolamento estrito de logins
    // 1. Tela da lanchonete (ou qualquer portal que não seja explicitamente 'superadmin') RECUSA e BARRA usuários com role SUPER_ADMIN
    if (user.role === "super_admin" && portal !== "superadmin") {
      return c.json(
        {
          success: false,
          error: "Acesso negado: Administradores da plataforma (SUPER_ADMIN) devem acessar exclusivamente pelo portal /super-admin.",
          code: "SUPER_ADMIN_BLOCKED_ON_STORE",
          isSuperAdmin: true,
        },
        403
      );
    }

    // 2. Portal Super Admin (portal === 'superadmin') recusa usuários sem privilégios globais
    if (portal === "superadmin" && user.role !== "super_admin") {
      return c.json(
        {
          success: false,
          error: "Acesso negado: Este portal é restrito exclusivamente a Super Administradores da plataforma. Utilize a tela de login da sua lanchonete em /admin.",
          code: "NOT_SUPER_ADMIN",
        },
        403
      );
    }

    let tenant = null;
    if (user.role === "tenant_admin" && user.tenantId) {
      tenant = await db.getTenantByIdOrSlug(user.tenantId);
      if (tenant && tenant.status === "inactive") {
        return c.json(
          {
            success: false,
            error: "Esta lanchonete está desativada pela plataforma. Contate o suporte.",
          },
          403
        );
      }
    }

    const jwtSecret = getJwtSecret(c);
    const token = await createJwtToken(
      {
        sub: user.id,
        userId: user.id,
        email: user.email,
        role: user.role,
        tenantId: user.tenantId,
        name: user.name,
        userUpdatedAt: user.updatedAt || 0,
        exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7, // 7 dias
        iat: Math.floor(Date.now() / 1000),
      },
      jwtSecret
    );

    return c.json({
      success: true,
      user,
      tenant,
      token,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro no login" }, 500);
  }
});

// Verificação de sessão administrativa segura (Super Admin e Lojista) com JWT_SECRET
api.post("/auth/verify", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    const body = await c.req.json().catch(() => ({}));
    const rawToken = body.token || (authHeader ? authHeader.replace(/^Bearer\s+/i, "") : null);
    const fallbackUserId = body.userId;

    if (!rawToken) {
      return c.json({ success: false, error: "Sessão não informada ou inválida." }, 401);
    }

    const jwtSecret = getJwtSecret(c);
    const decoded = await verifyTokenSafely(rawToken, jwtSecret);
    const userId = decoded?.userId || decoded?.sub || fallbackUserId;

    if (!userId) {
      return c.json({ success: false, error: "Token JWT inválido ou expirado." }, 401);
    }

    const db = getDb(c);
    const user = await db.getUserById(userId);
    if (!user) {
      return c.json({ success: false, error: "Usuário não encontrado ou sessão expirada." }, 401);
    }

    // Invalidação imediata de tokens emitidos antes da alteração de credenciais
    if (user.updatedAt) {
      if (!decoded.userUpdatedAt || decoded.userUpdatedAt < user.updatedAt) {
        return c.json(
          {
            success: false,
            error: "Sessão invalidada após alteração de credenciais. Faça login novamente.",
            sessionInvalidated: true,
          },
          401
        );
      }
    }

    let tenant = null;
    if (user.role === "tenant_admin" && user.tenantId) {
      tenant = await db.getTenantByIdOrSlug(user.tenantId);
      if (tenant && tenant.status === "inactive") {
        return c.json({ success: false, error: "Loja inativa." }, 403);
      }
    }

    return c.json({ success: true, user, tenant, token: rawToken }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao validar sessão." }, 500);
  }
});

export async function handleUpdateSuperAdminCredentials(c: any) {
  try {
    const body = await c.req.json();
    const { email, password, userId } = body;

    if (!email || !password) {
      return c.json(
        { success: false, error: "Novo e-mail e nova senha são obrigatórios." },
        400
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password).trim();

    if (cleanPassword.length < 4) {
      return c.json(
        { success: false, error: "A nova senha deve possuir no mínimo 4 caracteres." },
        400
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return c.json(
        { success: false, error: "Formato de e-mail inválido. Verifique o endereço digitado." },
        400
      );
    }

    // Identifica o Super Admin autenticado a partir do token ou payload
    const authUser = await authenticateRequestUser(c);
    const targetUserId = authUser?.id || userId;

    const db = getDb(c);
    const updatedUser = await db.updateSuperAdminCredentials(targetUserId, cleanEmail, cleanPassword);

    if (!updatedUser) {
      return c.json({ success: false, error: "Usuário Super Admin não encontrado." }, 404);
    }

    // Invalidação no Cloudflare KV se disponível
    try {
      const kv = c.env?.KV || c.env?.TOPFOOD_KV;
      if (kv) {
        await kv.put("auth:invalidated:super_admin", String(Date.now()));
      }
    } catch {
      // ignore
    }

    return c.json(
      {
        success: true,
        message:
          "Credenciais do Super Admin atualizadas com sucesso! Sua sessão foi invalidada por segurança. Faça login novamente com suas novas credenciais.",
        user: updatedUser,
        sessionInvalidated: true,
      },
      200
    );
  } catch (e: any) {
    return c.json(
      { success: false, error: sanitizeErrorMessage(e) },
      500
    );
  }
}

api.put("/superadmin/credentials", handleUpdateSuperAdminCredentials);
api.put("/super-admin/credentials", handleUpdateSuperAdminCredentials);
api.put("/api/superadmin/credentials", handleUpdateSuperAdminCredentials);
api.put("/api/super-admin/credentials", handleUpdateSuperAdminCredentials);
api.post("/superadmin/credentials", handleUpdateSuperAdminCredentials);
api.post("/super-admin/credentials", handleUpdateSuperAdminCredentials);
api.post("/api/superadmin/credentials", handleUpdateSuperAdminCredentials);
api.post("/api/super-admin/credentials", handleUpdateSuperAdminCredentials);

api.get("/platform/stats", async (c) => {
  const db = getDb(c);
  const stats = await db.getPlatformStats();
  return c.json({ success: true, stats }, 200);
});

api.get("/superadmin/tenants/credentials", async (c) => {
  try {
    const db = getDb(c);
    const credentials = await db.getAllTenantCredentials();
    return c.json({ success: true, credentials }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao buscar credenciais dos lojistas" }, 500);
  }
});

api.get("/superadmin/tenant-credentials", async (c) => {
  try {
    const db = getDb(c);
    const credentials = await db.getAllTenantCredentials();
    return c.json({ success: true, credentials }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao buscar credenciais dos lojistas" }, 500);
  }
});

const isAllLocationParam = (loc?: string | null) => {
  if (!loc) return true;
  const norm = loc.trim().toLowerCase();
  return (
    norm === "" ||
    norm === "todas" ||
    norm === "todas as localidades" ||
    norm === "todas as regiões" ||
    norm === "todas as regioes" ||
    norm === "todos" ||
    norm === "all"
  );
};

const handleGetTenantsList = async (c: any) => {
  c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  c.header("Pragma", "no-cache");
  c.header("Expires", "0");
  const db = getDb(c);
  const locationParam = c.req.query("location") || c.req.query("localidade") || "";
  let tenants = await db.getTenants();

  if (!isAllLocationParam(locationParam)) {
    const targetLoc = locationParam.trim().toLowerCase();
    tenants = tenants.filter(
      (t) => (t.localidade || "Gargaú").trim().toLowerCase() === targetLoc
    );
  }

  const enriched = await Promise.all(
    tenants.map(async (t) => {
      const [products, orders, creds] = await Promise.all([
        db.getProductsByTenant(t.id),
        db.getOrdersByTenant(t.id),
        db.getTenantCredentials(t.id),
      ]);
      const completedOrders = orders.filter(
        (o) =>
          o.status === "done" ||
          o.status === "Concluído" ||
          o.status === "concluido" ||
          o.status === "Entregue" ||
          o.status === "entregue" ||
          o.status === "finalizado"
      );
      const loc = (t.localidade || t.location || "Gargaú").trim() || "Gargaú";
      return {
        ...t,
        localidade: loc,
        location: loc,
        productCount: products.length,
        orderCount: orders.length,
        completedOrdersCount: completedOrders.length,
        salesCount: orders.filter((o) => o.status !== "cancelled").length,
        revenue: orders.reduce((sum, o) => sum + (o.total || 0), 0),
        adminEmail: creds?.email || t.email,
        adminUserId: creds?.userId,
        hasAdminAccount: Boolean(creds),
      };
    })
  );
  return c.json({ success: true, tenants: enriched, stores: enriched }, 200);
};

api.get("/tenants", handleGetTenantsList);
api.get("/stores", handleGetTenantsList);
api.get("/api/tenants", handleGetTenantsList);
api.get("/api/stores", handleGetTenantsList);

// Endpoint para o Carrossel 1: Lojas em Destaque ranqueadas por vendas (com filtro opcional por localidade)
const handleGetFeaturedStores = async (c: any) => {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    const db = getDb(c);
    const locationParam = c.req.query("location") || c.req.query("localidade") || undefined;
    const rawStores = await db.getFeaturedStoresRanked(locationParam);
    const stores = rawStores.map((s) => {
      const loc = (s.localidade || s.location || "Gargaú").trim() || "Gargaú";
      return { ...s, localidade: loc, location: loc };
    });
    return c.json({ success: true, stores }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao consultar lojas em destaque" }, 500);
  }
};

api.get("/featured-stores", handleGetFeaturedStores);
api.get("/api/featured-stores", handleGetFeaturedStores);

// Endpoint para o Carrossel 2: Mais Pedidos (com filtro opcional por localidade)
const handleGetPopularProducts = async (c: any) => {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    const db = getDb(c);
    const limit = Number(c.req.query("limit")) || 10;
    const days = Number(c.req.query("days")) || 30;
    const locationParam = c.req.query("location") || c.req.query("localidade") || undefined;
    const rawProducts = await db.getTopSellingProducts(limit, days, locationParam);
    const products = rawProducts.map((p) => {
      const loc = (p.location || p.localidade || "Gargaú").trim() || "Gargaú";
      return { ...p, location: loc, localidade: loc };
    });
    return c.json({ success: true, products }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao consultar produtos mais vendidos" }, 500);
  }
};

api.get("/top-selling-products", handleGetPopularProducts);
api.get("/api/top-selling-products", handleGetPopularProducts);
api.get("/mais-pedidos", handleGetPopularProducts);
api.get("/api/mais-pedidos", handleGetPopularProducts);
api.get("/products/popular", handleGetPopularProducts);
api.get("/api/products/popular", handleGetPopularProducts);

// Endpoint de Catálogo Global de Produtos com Vendas (para Busca Global de Lanches e Estabelecimentos)
const handleGetAllMarketplaceProducts = async (c: any) => {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    const db = getDb(c);
    const locationParam = c.req.query("location") || c.req.query("localidade") || undefined;
    const rawProducts = await db.getAllMarketplaceProductsWithSales(locationParam);
    const products = rawProducts.map((p) => {
      const loc = (p.location || p.localidade || "Gargaú").trim() || "Gargaú";
      return { ...p, location: loc, localidade: loc };
    });
    return c.json({ success: true, products }, 200);
  } catch (err: any) {
    return c.json(
      { success: false, products: [], error: err.message || "Erro ao consultar catálogo global de produtos" },
      500
    );
  }
};

api.get("/products/catalog", handleGetAllMarketplaceProducts);
api.get("/api/products/catalog", handleGetAllMarketplaceProducts);
api.get("/products/search", handleGetAllMarketplaceProducts);
api.get("/api/products/search", handleGetAllMarketplaceProducts);

api.get("/tenants/:slugOrId/credentials", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const credentials = await db.getTenantCredentials(slugOrId);
    if (!credentials) {
      return c.json({ success: false, error: "Lanchonete ou credenciais não encontradas" }, 404);
    }
    return c.json({ success: true, credentials }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao consultar credenciais" }, 500);
  }
});

api.put("/superadmin/tenants/:slugOrId/credentials", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json();
    const { email, password, name } = body;

    if (!email || !password) {
      return c.json(
        { success: false, error: "E-mail de login e senha são obrigatórios para a lanchonete." },
        400
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password).trim();

    if (cleanPassword.length < 4) {
      return c.json(
        { success: false, error: "A senha da lanchonete deve possuir no mínimo 4 caracteres." },
        400
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return c.json(
        { success: false, error: "Formato de e-mail inválido para o login da lanchonete." },
        400
      );
    }

    const res = await db.updateTenantCredentials(slugOrId, cleanEmail, cleanPassword, name);
    return c.json({
      success: true,
      message: "Credenciais do lojista salvas com sucesso no banco de dados!",
      credentials: res.credentials,
      tenant: res.tenant,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar credenciais do lojista." }, 500);
  }
});

api.put("/tenants/:slugOrId/credentials", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json();
    const { email, password, name } = body;

    if (!email || !password) {
      return c.json(
        { success: false, error: "E-mail de login e senha são obrigatórios para a lanchonete." },
        400
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password).trim();

    if (cleanPassword.length < 4) {
      return c.json(
        { success: false, error: "A senha da lanchonete deve possuir no mínimo 4 caracteres." },
        400
      );
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(cleanEmail)) {
      return c.json(
        { success: false, error: "Formato de e-mail inválido para o login da lanchonete." },
        400
      );
    }

    const res = await db.updateTenantCredentials(slugOrId, cleanEmail, cleanPassword, name);
    return c.json({
      success: true,
      message: "Credenciais do lojista salvas com sucesso no banco de dados!",
      credentials: res.credentials,
      tenant: res.tenant,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar credenciais do lojista." }, 500);
  }
});

// -----------------------------------------------------------------------------
// LOCALIDADES / REGIÕES (SELECT DISTINCT nas lojas ativas)
// GET /api/locations, GET /locations, GET /api/localities e GET /localities
// -----------------------------------------------------------------------------
const handleGetLocations = async (c: any) => {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    const db = getDb(c);
    const distinctLocalities = await db.getDistinctLocalities();
    const locationsWithAll = [
      "Todas as Localidades",
      ...distinctLocalities.filter((l) => l.toLowerCase() !== "todas as localidades"),
    ];
    return c.json(
      {
        success: true,
        localities: distinctLocalities,
        locations: locationsWithAll,
      },
      200
    );
  } catch (e: any) {
    return c.json(
      {
        success: false,
        error: e.message || "Erro ao consultar localidades",
        localities: [],
        locations: ["Todas as Localidades"],
      },
      500
    );
  }
};

api.get("/api/localities", handleGetLocations);
api.get("/localities", handleGetLocations);
api.get("/api/locations", handleGetLocations);
api.get("/locations", handleGetLocations);

api.post("/tenants", async (c) => {
  try {
    const body = await c.req.json();
    const { name, slug, email, password, whatsapp, pixKey, pixKeyType, deliveryFee, address, primaryColor, bannerImage, businessType, category, localidade } = body;

    if (!name || !email || !password) {
      return c.json(
        { success: false, error: "Nome da loja, e-mail e senha do cliente são obrigatórios" },
        400
      );
    }

    if (!localidade || !String(localidade).trim()) {
      return c.json(
        { success: false, error: "O campo Localidade / Região é obrigatório (ex: Gargaú, Barra do Itabapoana)" },
        400
      );
    }

    const db = getDb(c);
    const tenant = await db.createTenant({
      name,
      slug,
      email,
      whatsapp: whatsapp || "5511999999999",
      pixKey: pixKey || email,
      pixKeyType: pixKeyType || "email",
      deliveryFee: Number(deliveryFee) || 5.0,
      address: address || "Centro",
      primaryColor: primaryColor || "#E63946",
      bannerImage: bannerImage || "",
      businessType: businessType || category || "Lanchonetes",
      localidade: String(localidade).trim(),
    });

    const user = await db.createUser({
      email,
      password,
      name: `Admin ${name}`,
      role: "tenant_admin",
      tenantId: tenant.id,
    });

    return c.json({
      success: true,
      message: "Lanchonete e conta criadas com sucesso no Cloudflare D1/KV!",
      tenant,
      user,
    }, 201);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao criar lanchonete" }, 500);
  }
});

api.get("/tenants/:slugOrId", async (c) => {
  const db = getDb(c);
  const slugOrId = c.req.param("slugOrId");
  const tenant = await db.getTenantByIdOrSlug(slugOrId);

  if (!tenant) {
    return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
  }
  return c.json({ success: true, tenant }, 200);
});

const handleTenantUpdate = async (c: any) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json();

    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    if (body.localidade !== undefined && !String(body.localidade).trim()) {
      return c.json({ success: false, error: "O campo Localidade / Região não pode ficar vazio." }, 400);
    }

    if (body.adminPassword || body.adminEmail) {
      const credEmail = (body.adminEmail || body.email || tenant.email).trim().toLowerCase();
      const credPass = (body.adminPassword || "").trim();
      if (credPass.length >= 4) {
        await db.updateTenantCredentials(tenant.id, credEmail, credPass, body.name || tenant.name);
      }
    }

    const rawCategory =
      body.businessType !== undefined && String(body.businessType).trim() !== ""
        ? String(body.businessType).trim()
        : body.business_type !== undefined && String(body.business_type).trim() !== ""
        ? String(body.business_type).trim()
        : body.category !== undefined && String(body.category).trim() !== ""
        ? String(body.category).trim()
        : body.categoryId !== undefined && String(body.categoryId).trim() !== ""
        ? String(body.categoryId).trim()
        : body.category_id !== undefined && String(body.category_id).trim() !== ""
        ? String(body.category_id).trim()
        : undefined;

    const payload = {
      ...body,
      ...(rawCategory !== undefined
        ? {
            businessType: rawCategory,
            category: rawCategory,
            categoryId: rawCategory,
            category_id: rawCategory,
          }
        : {}),
      ...(body.localidade !== undefined ? { localidade: String(body.localidade).trim() } : {}),
      ...(body.motoboyPhone !== undefined ? { motoboyPhone: String(body.motoboyPhone).trim(), motoboy_phone: String(body.motoboyPhone).trim() } : {}),
      ...(body.motoboy_phone !== undefined ? { motoboyPhone: String(body.motoboy_phone).trim(), motoboy_phone: String(body.motoboy_phone).trim() } : {}),
      ...(body.motoboyName !== undefined ? { motoboyName: String(body.motoboyName).trim(), motoboy_name: String(body.motoboyName).trim() } : {}),
      ...(body.motoboy_name !== undefined ? { motoboyName: String(body.motoboy_name).trim(), motoboy_name: String(body.motoboy_name).trim() } : {}),
    };

    const updated = await db.updateTenant(tenant.id, payload);
    return c.json({
      success: true,
      tenant: updated,
      store: updated,
      message: "Categoria e configurações da loja salvas com sucesso no banco de dados!",
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar" }, 500);
  }
};

api.put("/tenants/:slugOrId", handleTenantUpdate);
api.patch("/tenants/:slugOrId", handleTenantUpdate);
api.put("/admin/stores/:slugOrId", handleTenantUpdate);
api.patch("/admin/stores/:slugOrId", handleTenantUpdate);
api.put("/admin/tenants/:slugOrId", handleTenantUpdate);
api.patch("/admin/tenants/:slugOrId", handleTenantUpdate);
api.put("/stores/:slugOrId", handleTenantUpdate);
api.patch("/stores/:slugOrId", handleTenantUpdate);

api.patch("/tenants/:slugOrId/status", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json();
    const status: TenantStatus = body.status;

    if (!["active", "inactive"].includes(status)) {
      return c.json({ success: false, error: "Status inválido (use 'active' ou 'inactive')" }, 400);
    }

    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const updated = await db.setTenantStatus(tenant.id, status);
    return c.json({
      success: true,
      message: `Lanchonete ${status === "active" ? "ativada" : "desativada"} com sucesso`,
      tenant: updated,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar status" }, 500);
  }
});

// -----------------------------------------------------------------------------
// ATUALIZAÇÃO DO VALOR DA MENSALIDADE INDIVIDUAL NO CLOUDFLARE D1
// PATCH /api/tenants/:slugOrId/monthly-fee
// -----------------------------------------------------------------------------
api.patch("/tenants/:slugOrId/monthly-fee", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json().catch(() => ({}));
    const monthlyFee = Number(body.monthlyFee);

    if (isNaN(monthlyFee) || monthlyFee < 0) {
      return c.json({ success: false, error: "Valor de mensalidade inválido (deve ser um número maior ou igual a zero)." }, 400);
    }

    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const updated = await db.updateTenant(tenant.id, { monthlyFee });
    return c.json(
      {
        success: true,
        message: `Valor da mensalidade alterado para R$ ${monthlyFee.toFixed(2)} e salvo no banco D1!`,
        tenant: updated,
        monthlyFee,
      },
      200
    );
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar mensalidade" }, 500);
  }
});

// -----------------------------------------------------------------------------
// ATIVAÇÃO DINÂMICA DE MENSALIDADE (Captura automática do dia no D1)
// POST /api/tenants/:slugOrId/activate-subscription
// -----------------------------------------------------------------------------
api.post("/tenants/:slugOrId/activate-subscription", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json().catch(() => ({}));
    const customBillingDay = body.billingDay !== undefined ? Number(body.billingDay) : undefined;

    const result = await db.activateSubscription(slugOrId, customBillingDay);
    return c.json({
      success: true,
      message: `Mensalidade ativada com sucesso! Vencimento definido para todo dia ${result.billingDay}.`,
      tenant: result.tenant,
      billingDay: result.billingDay,
      nextDueDate: result.nextDueDate,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao ativar mensalidade" }, 500);
  }
});

// -----------------------------------------------------------------------------
// RENOVAÇÃO / CONFIRMAÇÃO DE PAGAMENTO DO MÊS (Mantém o billing_day original)
// POST /api/tenants/:slugOrId/confirm-payment
// -----------------------------------------------------------------------------
api.post("/tenants/:slugOrId/confirm-payment", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");

    const result = await db.confirmMonthlyPayment(slugOrId);
    return c.json({
      success: true,
      message: `Pagamento confirmado com sucesso! Mensalidade renovada (+1 mês). Vencimento todo dia ${result.billingDay}.`,
      tenant: result.tenant,
      billingDay: result.billingDay,
      paymentAt: result.paymentAt,
      nextDueDate: result.nextDueDate,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao confirmar pagamento" }, 500);
  }
});

// -----------------------------------------------------------------------------
// CANCELAMENTO DE ASSINATURA (SUPER ADMIN)
// POST /api/tenants/:slugOrId/cancel-subscription
// -----------------------------------------------------------------------------
api.post("/tenants/:slugOrId/cancel-subscription", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");

    const result = await db.cancelSubscription(slugOrId);
    return c.json({
      success: true,
      message: `Assinatura da lanchonete "${result.tenant.name}" cancelada com sucesso. A loja retornou ao Modo Demonstração.`,
      tenant: result.tenant,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao cancelar assinatura" }, 500);
  }
});

api.patch("/tenants/:slugOrId/featured", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json().catch(() => ({}));
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const isFeatured = body.isFeatured !== undefined
      ? Boolean(body.isFeatured)
      : (body.is_featured !== undefined ? Boolean(body.is_featured) : !tenant.isFeatured);

    const priorityOrder = body.priorityOrder !== undefined
      ? Number(body.priorityOrder)
      : (body.priority_order !== undefined ? Number(body.priority_order) : (tenant.priorityOrder || 0));

    const updated = await db.updateTenant(tenant.id, {
      isFeatured,
      priorityOrder,
    });

    return c.json({
      success: true,
      message: `Status de destaque atualizado para ${tenant.name}`,
      tenant: updated,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar destaque" }, 500);
  }
});

api.delete("/tenants/:slugOrId", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    await db.deleteTenant(tenant.id);
    return c.json({ success: true, message: "Lanchonete removida com sucesso" }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao excluir" }, 500);
  }
});

// ===================== CATEGORIAS DE ESTABELECIMENTOS =====================

const handleGetEstablishmentCategories = async (c: any) => {
  try {
    const db = getDb(c);
    const activeOnly = c.req.query("activeOnly") === "true" || c.req.query("nonEmpty") === "true";
    const locationParam = c.req.query("location") || c.req.query("localidade") || "";
    const filterByLoc = !isAllLocationParam(locationParam);
    let categories = await db.getEstablishmentCategories();

    if (activeOnly || filterByLoc) {
      const tenants = await db.getTenants();
      const activeTenants = tenants.filter((t) => {
        if (t.status === "inactive") return false;
        if (filterByLoc) {
          return (t.localidade || "Gargaú").trim().toLowerCase() === locationParam.trim().toLowerCase();
        }
        return true;
      });
      const norm = (str?: string) =>
        (str || "")
          .toLowerCase()
          .trim()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "");

      categories = categories.filter((cat) => {
        if (cat.id === "todos" || norm(cat.name) === "todos") return true;
        const cId = norm(cat.id);
        const cName = norm(cat.name);
        return activeTenants.some((t) => {
          const bType = norm(t.businessType || t.category || t.categoryId);
          return bType === cId || bType === cName || (bType && (bType.includes(cName) || cName.includes(bType)));
        });
      });
    }

    return c.json({ success: true, categories }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao carregar categorias" }, 500);
  }
};

const handleCreateEstablishmentCategory = async (c: any) => {
  try {
    const db = getDb(c);
    const body = await c.req.json();
    const { name, icon, order } = body;

    if (!name || typeof name !== "string" || !name.trim()) {
      return c.json({ success: false, error: "Nome da categoria é obrigatório." }, 400);
    }

    const category = await db.createEstablishmentCategory({
      name: name.trim(),
      icon: icon?.trim() || "🍽️",
      order: order !== undefined ? Number(order) : undefined,
    });

    return c.json({
      success: true,
      message: "Categoria de estabelecimento criada com sucesso no D1!",
      category,
    }, 201);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao criar categoria" }, 500);
  }
};

const handleDeleteEstablishmentCategory = async (c: any) => {
  try {
    const db = getDb(c);
    const id = c.req.param("id");
    await db.deleteEstablishmentCategory(id);
    return c.json({ success: true, message: "Categoria removida com sucesso" }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao remover categoria" }, 500);
  }
};

api.get("/establishment-categories", handleGetEstablishmentCategories);
api.post("/establishment-categories", handleCreateEstablishmentCategory);
api.delete("/establishment-categories/:id", handleDeleteEstablishmentCategory);

api.get("/admin/establishment-categories", handleGetEstablishmentCategories);
api.post("/admin/establishment-categories", handleCreateEstablishmentCategory);
api.delete("/admin/establishment-categories/:id", handleDeleteEstablishmentCategory);

api.get("/categorias-estabelecimentos", handleGetEstablishmentCategories);
api.post("/categorias-estabelecimentos", handleCreateEstablishmentCategory);

api.get("/tenants/:slugOrId/categories", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const categories = await db.getCategoriesByTenant(tenant.id);
    return c.json({ success: true, categories, categorias: categories }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao listar categorias" }, 500);
  }
});

api.post("/tenants/:slugOrId/categories", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const body = await c.req.json();
    const name = body.name || body.nome;

    if (!name || typeof name !== "string" || !name.trim()) {
      return c.json({ success: false, error: "O nome da categoria é obrigatório." }, 400);
    }

    const category = await db.createCategory(tenant.id, {
      name: name.trim(),
      icon: body.icon || body.icone || "🍽️",
    });

    return c.json({ success: true, category, categoria: category }, 201);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao criar categoria" }, 500);
  }
});

// ===================== ADDON GROUPS (GRUPOS DE COMPLEMENTOS / ADICIONAIS) =====================

api.get("/tenants/:slugOrId/addons", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }
    const addonGroups = await db.getAddonGroupsByTenant(tenant.id);
    return c.json({ success: true, addonGroups, grupos: addonGroups }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao listar grupos de adicionais" }, 500);
  }
});

api.get("/tenants/:slugOrId/addon-groups", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }
    const addonGroups = await db.getAddonGroupsByTenant(tenant.id);
    return c.json({ success: true, addonGroups, grupos: addonGroups }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao listar grupos de adicionais" }, 500);
  }
});

api.post("/tenants/:slugOrId/addons", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }
    const body = await c.req.json();
    const name = body.name || body.nome;
    if (!name || typeof name !== "string" || !name.trim()) {
      return c.json({ success: false, error: "O nome do grupo de adicionais é obrigatório." }, 400);
    }
    const addonGroup = await db.createAddonGroup(tenant.id, {
      name: name.trim(),
      description: body.description || body.descricao || "",
      minSelection: Number(body.minSelection ?? body.min_selection ?? 0),
      maxSelection: Number(body.maxSelection ?? body.max_selection ?? 0),
      required: Boolean(body.required || body.obrigatorio),
      items: Array.isArray(body.items) ? body.items : (Array.isArray(body.itens) ? body.itens : []),
      position: body.position ? Number(body.position) : undefined,
    });
    return c.json({ success: true, addonGroup, grupo: addonGroup }, 201);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao criar grupo de adicionais" }, 500);
  }
});

api.put("/tenants/:slugOrId/addons/:groupId", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const groupId = c.req.param("groupId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }
    const body = await c.req.json();
    const updated = await db.updateAddonGroup(groupId, body);
    if (!updated) {
      return c.json({ success: false, error: "Grupo de adicionais não encontrado." }, 404);
    }
    return c.json({ success: true, addonGroup: updated, grupo: updated }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar grupo de adicionais" }, 500);
  }
});

api.delete("/tenants/:slugOrId/addons/:groupId", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const groupId = c.req.param("groupId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }
    await db.deleteAddonGroup(groupId);
    return c.json({ success: true, message: "Grupo de adicionais excluído com sucesso." }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao excluir grupo de adicionais" }, 500);
  }
});

api.get("/tenants/:slugOrId/products", async (c) => {
  const db = getDb(c);
  const slugOrId = c.req.param("slugOrId");
  const tenant = await db.getTenantByIdOrSlug(slugOrId);

  if (!tenant) {
    return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
  }

  const [products, addonGroups] = await Promise.all([
    db.getProductsByTenant(tenant.id),
    db.getAddonGroupsByTenant(tenant.id),
  ]);

  // Enriquecer produtos com seus respectivos grupos de adicionais
  const enrichedProducts = products.map((p) => {
    if (p.addonGroupIds && p.addonGroupIds.length > 0) {
      const groups = addonGroups.filter((g) => p.addonGroupIds!.includes(g.id));
      return { ...p, addonGroups: groups };
    }
    return p;
  });

  return c.json({
    success: true,
    products: enrichedProducts,
    produtos: enrichedProducts,
    addonGroups,
    loja: { id: tenant.id, nome: tenant.name, slug: tenant.slug },
  }, 200);
});

api.put("/tenants/:slugOrId/products/reorder", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const body = await c.req.json();
    const orderedIds = body.orderedIds || body.order || body.ids || [];

    if (!Array.isArray(orderedIds)) {
      return c.json({ success: false, error: "orderedIds deve ser uma lista de IDs de produtos." }, 400);
    }

    await db.reorderProducts(tenant.id, orderedIds);
    return c.json({ success: true, message: "Ordem dos produtos atualizada com sucesso!" }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao reordenar produtos" }, 500);
  }
});

api.post("/tenants/:slugOrId/products", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const body = await c.req.json();

    // Se uma nova categoria foi informada, salva primeiro na tabela de categorias e vincula
    const newCategoryName = body.newCategoryName || body.novaCategoria || body.newCategory;
    if (newCategoryName && typeof newCategoryName === "string" && newCategoryName.trim()) {
      const createdCategory = await db.createCategory(tenant.id, { name: newCategoryName.trim() });
      body.category = createdCategory.id;
    }

    const product = await db.createProduct(tenant.id, body);
    return c.json({ success: true, product }, 201);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao adicionar produto" }, 500);
  }
});

api.put("/tenants/:slugOrId/products/:productId", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const productId = c.req.param("productId");
    const body = await c.req.json();

    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    // Se uma nova categoria foi informada na edição
    const newCategoryName = body.newCategoryName || body.novaCategoria || body.newCategory;
    if (newCategoryName && typeof newCategoryName === "string" && newCategoryName.trim() && tenant) {
      const createdCategory = await db.createCategory(tenant.id, { name: newCategoryName.trim() });
      body.category = createdCategory.id;
    }

    const product = await db.updateProduct(productId, body);
    if (!product) {
      return c.json({ success: false, error: "Produto não encontrado" }, 404);
    }
    return c.json({ success: true, product }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao atualizar produto" }, 500);
  }
});

api.delete("/tenants/:slugOrId/products/:productId", async (c) => {
  try {
    const db = getDb(c);
    const productId = c.req.param("productId");
    await db.deleteProduct(productId);
    return c.json({ success: true, message: "Produto removido" }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao remover produto" }, 500);
  }
});

api.get("/tenants/:slugOrId/orders", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: true, orders: [], pedidos: [], total: 0 }, 200);
    }

    const orders = await db.getOrdersByTenant(tenant.id);
    const safeOrders = Array.isArray(orders) ? orders : [];
    return c.json({ success: true, orders: safeOrders, pedidos: safeOrders, total: safeOrders.length }, 200);
  } catch (err: any) {
    console.warn("[tenants/orders] Erro ao buscar pedidos, retornando array seguro:", err);
    return c.json({ success: true, orders: [], pedidos: [], total: 0 }, 200);
  }
});

// ===================== CLIENTES (CADASTRO E CONSULTA) =====================
api.get("/tenants/:slugOrId/customers", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const customers = await db.getCustomersByTenant(tenant.id);
    return c.json({ success: true, customers }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao listar clientes" }, 500);
  }
});

api.get("/tenants/:slugOrId/customers/lookup", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const phone = c.req.query("phone");

    if (!phone) {
      return c.json({ success: false, error: "Telefone não informado" }, 400);
    }

    const tenant = await db.getTenantByIdOrSlug(slugOrId);
    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const customer = await db.getCustomerByPhone(tenant.id, phone);
    return c.json({ success: true, customer }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao consultar cliente" }, 500);
  }
});

// SSE Stream para escuta de pedidos em tempo real no painel do restaurante
// SSE Stream para escuta de pedidos em tempo real no painel do restaurante (100% orientado a eventos, ZERO polling/loops)
api.get("/tenants/:slugOrId/orders/stream", async (c) => {
  const db = getDb(c);
  const slugOrId = c.req.param("slugOrId");
  const tenant = await db.getTenantByIdOrSlug(slugOrId);

  if (!tenant) {
    return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
  }

  return streamSSE(c, async (stream) => {
    await stream.writeSSE({
      event: "connected",
      data: JSON.stringify({
        message: "Canal de pedidos em tempo real conectado",
        tenantId: tenant.id,
        tenantName: tenant.name,
        timestamp: Date.now(),
      }),
    });

    // Envia estado inicial uma única vez na conexão
    try {
      const initialOrders = await db.getOrdersByTenant(tenant.id);
      await stream.writeSSE({
        event: "orders",
        data: JSON.stringify({ orders: initialOrders, timestamp: Date.now() }),
      });
    } catch (e) {
      console.warn("SSE initial orders error:", e);
    }

    // Escuta em tempo real orientada a eventos - ZERO polling no Cloudflare D1
    const unsubscribe = await subscribeOrderEvents(c.env, tenant.id, async (payload) => {
      const belongsToTenant =
        payload.order?.tenantId === tenant.id ||
        payload.order?.tenantId === tenant.slug ||
        payload.tenantId === tenant.id ||
        payload.tenantId === tenant.slug;

      if (belongsToTenant) {
        try {
          if (payload.isNew) {
            await stream.writeSSE({
              event: "new_order",
              data: JSON.stringify({
                order: payload.order,
                timestamp: payload.timestamp,
              }),
            });
          }
          await stream.writeSSE({
            event: "order_update",
            data: JSON.stringify({
              orderId: payload.orderId,
              status: payload.status,
              order: payload.order,
              isNew: payload.isNew,
              timestamp: payload.timestamp,
            }),
          });
        } catch (err) {
          console.warn("SSE push order error:", err);
        }
      }
    });

    stream.onAbort(() => {
      unsubscribe();
    });

    // Heartbeat keepalive leve a cada 25s apenas para manter a conexão sem tocar no banco
    while (!stream.aborted) {
      await stream.sleep(25000);
      try {
        await stream.writeSSE({
          event: "ping",
          data: "{}",
        });
      } catch {
        break;
      }
    }

    unsubscribe();
  });
});

api.get("/orders/stream", async (c) => {
  const db = getDb(c);
  const tenantParam = c.req.query("tenantId") || c.req.query("loja") || c.req.query("slug");
  let targetTenant: any = null;
  if (tenantParam) {
    targetTenant = await db.getTenantByIdOrSlug(tenantParam);
  }

  // Identificação e validação de permissão de super_admin
  let isSuperAdmin = false;
  const authHeader = c.req.header("Authorization") || c.req.query("token") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (token) {
    try {
      const user = await db.getUserByToken(token);
      if (user && ["super_admin", "superadmin", "SUPER_ADMIN"].includes(user.role)) {
        isSuperAdmin = true;
      } else if (user && user.tenantId && !targetTenant) {
        targetTenant = await db.getTenantByIdOrSlug(user.tenantId);
      }
    } catch {
      // ignore
    }
  }

  const effectiveTenantId = targetTenant?.id || (tenantParam ? tenantParam.trim() : null);

  return streamSSE(c, async (stream) => {
    await stream.writeSSE({
      event: "connected",
      data: JSON.stringify({ message: "Canal de pedidos em tempo real conectado", timestamp: Date.now() }),
    });

    try {
      let initialOrders: any[] = [];
      if (effectiveTenantId) {
        initialOrders = await db.getOrdersByTenant(effectiveTenantId);
      } else if (isSuperAdmin) {
        initialOrders = await db.getAllOrders();
      } else {
        // Blindagem total: sem tenant e sem super admin, lista vazia sem vazamento
        initialOrders = [];
      }

      await stream.writeSSE({
        event: "orders",
        data: JSON.stringify({ orders: initialOrders, timestamp: Date.now() }),
      });
    } catch (e) {
      console.warn("SSE initial orders error:", e);
    }

    const unsubscribe = await subscribeOrderEvents(c.env, effectiveTenantId || (isSuperAdmin ? ALL_TENANTS_ROOM : ""), async (payload) => {
      // Sem tenant e sem super admin, nunca propaga eventos
      if (!effectiveTenantId && !isSuperAdmin) {
        return;
      }

      const match =
        isSuperAdmin ||
        (effectiveTenantId && (
          payload.order?.tenantId === effectiveTenantId ||
          payload.order?.tenantId === targetTenant?.slug ||
          payload.tenantId === effectiveTenantId ||
          payload.tenantId === targetTenant?.slug
        ));

      if (match) {
        try {
          if (payload.isNew) {
            await stream.writeSSE({
              event: "new_order",
              data: JSON.stringify({ order: payload.order, timestamp: payload.timestamp }),
            });
          }
          await stream.writeSSE({
            event: "order_update",
            data: JSON.stringify({
              orderId: payload.orderId,
              status: payload.status,
              order: payload.order,
              isNew: payload.isNew,
              timestamp: payload.timestamp,
            }),
          });
        } catch (err) {
          console.warn("SSE push order error:", err);
        }
      }
    });

    stream.onAbort(() => {
      unsubscribe();
    });

    while (!stream.aborted) {
      await stream.sleep(25000);
      try {
        await stream.writeSSE({
          event: "ping",
          data: "{}",
        });
      } catch {
        break;
      }
    }

    unsubscribe();
  });
});

async function parseIncomingOrderPayload(c: any): Promise<any> {
  const contentType = c.req.header("content-type") || "";
  let body: any = {};
  let receiptUrl: string | undefined = undefined;

  if (contentType.includes("multipart/form-data")) {
    const formData = await c.req.formData();
    for (const [key, value] of formData.entries()) {
      if (value && typeof value === "object" && "name" in value && "arrayBuffer" in value) {
        const file = value as File;
        if (file.size > 0) {
          const buffer = await file.arrayBuffer();
          const base64 = btoa(
            new Uint8Array(buffer).reduce((data, byte) => data + String.fromCharCode(byte), "")
          );
          const mime = file.type || "image/jpeg";
          receiptUrl = `data:${mime};base64,${base64}`;
        }
      } else if (typeof value === "string") {
        try {
          if (key === "items" || key === "address" || key === "statusHistory") {
            body[key] = JSON.parse(value);
          } else {
            body[key] = value;
          }
        } catch {
          body[key] = value;
        }
      }
    }
  } else {
    body = await c.req.json();
    receiptUrl = body.pix_receipt_url || body.pixReceiptUrl || body.receipt;
  }

  if (receiptUrl) {
    body.pix_receipt_url = receiptUrl;
    body.pixReceiptUrl = receiptUrl;
  }

  return body;
}

api.post("/tenants/:slugOrId/orders", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    if (tenant.status === "inactive") {
      return c.json(
        { success: false, error: "Esta loja está desativada no momento e não aceita novos pedidos." },
        400
      );
    }

    const body = await parseIncomingOrderPayload(c);

    // Verificação de idempotência (Prevenção de duplicidade após timeout)
    const rawIdempotency =
      c.req.header("x-idempotency-key") ||
      c.req.header("idempotency-key") ||
      body.idempotency_key ||
      body.idempotencyKey ||
      body.cart_id ||
      body.cartId ||
      undefined;

    if (rawIdempotency && typeof rawIdempotency === "string" && rawIdempotency.trim()) {
      const cleanKey = rawIdempotency.trim();
      try {
        const checkPromise = db.getOrderByIdempotencyKey(cleanKey, 5 * 60 * 1000);
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000));
        const existing = await Promise.race([checkPromise, timeoutPromise]);
        if (existing) {
          return c.json({
            success: true,
            orderId: existing.id,
            id: existing.id,
            duplicated: true,
            order: existing,
            pedido: existing,
            message: "Pedido já registrado anteriormente com sucesso (idempotência).",
          }, 200);
        }
      } catch (idempErr) {
        console.warn("[tenants/orders] Idempotency check error/timeout, proceeding:", idempErr);
      }
      body.idempotencyKey = cleanKey;
      body.idempotency_key = cleanKey;
      body.cart_id = cleanKey;
    }

    const rawTable = body.tableNumber || body.table_number || body.numeroMesa || body.table || body.mesa || undefined;
    const cleanTable = rawTable && typeof rawTable === "string" && rawTable.trim() ? rawTable.trim() : undefined;
    body.tableNumber = cleanTable;
    body.table_number = cleanTable;
    body.mesa = cleanTable;
    body.table = cleanTable;

    const order = await db.createOrder(tenant.id, body);
    if (!order || !order.id) {
      return c.json({
        success: false,
        error: "Falha na confirmação de gravação do pedido no banco de dados. O pedido não foi criado.",
      }, 500);
    }

    // Dispara notificação push de alta prioridade para o lojista em segundo plano
    try {
      const pushPromise = sendNewOrderPushNotification(tenant.id, order, c.env, () => db).catch((pushErr) => {
        console.warn("[Push] Erro assíncrono ao disparar notificação:", pushErr);
      });
      if ((c.executionCtx as any)?.waitUntil) {
        c.executionCtx.waitUntil(pushPromise);
      }
    } catch {
      // Ignora erro de contexto
    }

    return c.json({ success: true, orderId: order.id, id: order.id, order }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao criar pedido" }, 500);
  }
});

// Alias adicional de compatibilidade para listagem de pedidos da loja
api.get("/pedidos-loja", handlePedidosLoja);

// Endpoint de listagem de pedidos: GET /api/orders?tenantId=...
api.get("/orders", async (c) => {
  try {
    const db = getDb(c);
    const tenantParam =
      c.req.query("tenantId") ||
      c.req.query("tenant_id") ||
      c.req.query("store_id") ||
      c.req.query("loja_id") ||
      c.req.query("loja") ||
      c.req.query("slug");

    if (tenantParam && tenantParam.trim()) {
      const cleanParam = tenantParam.trim();
      const tenant = await db.getTenantByIdOrSlug(cleanParam);
      const orders = await db.getOrdersByTenant(tenant ? tenant.id : cleanParam);
      const safeOrders = Array.isArray(orders) ? orders : [];
      return c.json({ success: true, orders: safeOrders, pedidos: safeOrders, total: safeOrders.length }, 200);
    }

    // Se nenhum tenant informado, verificar autenticação. Apenas super_admin pode consultar pedidos globais.
    // Lojista ou requisição pública sem tenant_id jamais recebe pedidos de outras lojas.
    const authHeader = c.req.header("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (token) {
      try {
        const user = await db.getUserByToken(token);
        if (user && ["super_admin", "superadmin", "SUPER_ADMIN"].includes(user.role)) {
          const orders = await db.getAllOrders();
          const safeOrders = Array.isArray(orders) ? orders : [];
          return c.json({ success: true, orders: safeOrders, pedidos: safeOrders, total: safeOrders.length }, 200);
        }
        if (user && user.tenantId) {
          const orders = await db.getOrdersByTenant(user.tenantId);
          const safeOrders = Array.isArray(orders) ? orders : [];
          return c.json({ success: true, orders: safeOrders, pedidos: safeOrders, total: safeOrders.length }, 200);
        }
      } catch {
        // ignore
      }
    }

    // Blindagem total: sem tenant_id e sem super_admin, retorna lista vazia segura
    return c.json({ success: true, orders: [], pedidos: [], total: 0 }, 200);
  } catch (e: any) {
    console.warn("[/orders] Erro capturado, retornando array seguro:", e);
    return c.json({ success: true, orders: [], pedidos: [], total: 0 }, 200);
  }
});

// Obter comprovante de um pedido: GET /api/orders/:orderId/receipt
api.get("/orders/:orderId/receipt", async (c) => {
  try {
    const db = getDb(c);
    const orderId = c.req.param("orderId");
    const order = await db.getOrderById(orderId);
    if (!order) {
      return c.json({ success: false, error: "Pedido não encontrado" }, 404);
    }
    const receipt = order.pixReceiptUrl || order.pix_receipt_url;
    if (!receipt) {
      return c.json({ success: false, error: "Comprovante não disponível para este pedido" }, 404);
    }
    return c.json({ success: true, orderId: order.id, receiptUrl: receipt });
  } catch (e: any) {
    return c.json({ success: false, error: e.message }, 500);
  }
});

// Rota direta de compatibilidade para clientes móveis e redes externas postando em /orders
api.post("/orders", async (c) => {
  try {
    const db = getDb(c);
    const body = await parseIncomingOrderPayload(c);

    // Identifica o tenant
    const tenantRef = body.tenantId || body.tenant_id || body.lojaId || body.lojaSlug || "marcelino";
    const tenant = await db.getTenantByIdOrSlug(tenantRef);
    const targetTenantId = tenant ? tenant.id : tenantRef;

    // Verificação de idempotência (Prevenção de duplicidade após timeout)
    const rawIdempotency =
      c.req.header("x-idempotency-key") ||
      c.req.header("idempotency-key") ||
      body.idempotency_key ||
      body.idempotencyKey ||
      body.cart_id ||
      body.cartId ||
      undefined;

    if (rawIdempotency && typeof rawIdempotency === "string" && rawIdempotency.trim()) {
      const cleanKey = rawIdempotency.trim();
      try {
        const checkPromise = db.getOrderByIdempotencyKey(cleanKey, 5 * 60 * 1000);
        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 2000));
        const existing = await Promise.race([checkPromise, timeoutPromise]);
        if (existing) {
          return c.json({
            success: true,
            orderId: existing.id,
            id: existing.id,
            duplicated: true,
            order: existing,
            pedido: existing,
            message: "Pedido já registrado anteriormente com sucesso (idempotência).",
          }, 200);
        }
      } catch (idempErr) {
        console.warn("[/orders] Idempotency check error/timeout, proceeding:", idempErr);
      }
      body.idempotencyKey = cleanKey;
      body.idempotency_key = cleanKey;
      body.cart_id = cleanKey;
    }

    const rawTable = body.tableNumber || body.table_number || body.numeroMesa || body.table || body.mesa || undefined;
    const cleanTable = rawTable && typeof rawTable === "string" && rawTable.trim() ? rawTable.trim() : undefined;
    body.tableNumber = cleanTable;
    body.table_number = cleanTable;
    body.mesa = cleanTable;
    body.table = cleanTable;

    const order = await db.createOrder(targetTenantId, body);
    if (!order || !order.id) {
      return c.json({
        success: false,
        error: "Falha na confirmação de gravação do pedido no banco de dados. O pedido não foi criado.",
      }, 500);
    }

    // Dispara notificação push de alta prioridade para o lojista em segundo plano
    try {
      const pushPromise = sendNewOrderPushNotification(targetTenantId, order, c.env, () => db).catch((pushErr) => {
        console.warn("[Push] Erro assíncrono ao disparar notificação:", pushErr);
      });
      if ((c.executionCtx as any)?.waitUntil) {
        c.executionCtx.waitUntil(pushPromise);
      }
    } catch {
      // Ignora erro de contexto
    }

    return c.json({ success: true, orderId: order.id, id: order.id, order }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao registrar pedido" }, 500);
  }
});

// Atualização de status direta em /orders/:orderId/status e /tenants/:slugOrId/orders/:orderId/status
api.patch("/orders/:orderId/status", handleStatusUpdate);
api.put("/orders/:orderId/status", handleStatusUpdate);
api.patch("/tenants/:slugOrId/orders/:orderId/status", handleStatusUpdate);
api.put("/tenants/:slugOrId/orders/:orderId/status", handleStatusUpdate);

// Endpoint público para consulta e rastreamento em tempo real do status de um pedido
api.get("/orders/:orderId", async (c) => {
  try {
    const db = getDb(c);
    const orderId = c.req.param("orderId");
    const order = await db.getOrderById(orderId);
    if (!order) {
      return c.json({ success: false, error: "Pedido não encontrado" }, 404);
    }

    c.header("Cache-Control", "no-cache, no-store, must-revalidate");
    c.header("Pragma", "no-cache");
    c.header("Expires", "0");

    return c.json({
      success: true,
      orderId: order.id,
      status: order.status,
      statusPt: STATUS_MAP_EN_TO_PT[order.status] || order.status,
      order,
      pedido: order,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao buscar pedido" }, 500);
  }
});

// Endpoint com escopo de tenant para rastreamento de pedido
api.get("/tenants/:slugOrId/orders/:orderId", async (c) => {
  try {
    const db = getDb(c);
    const orderId = c.req.param("orderId");
    const order = await db.getOrderById(orderId);
    if (!order) {
      return c.json({ success: false, error: "Pedido não encontrado" }, 404);
    }

    c.header("Cache-Control", "no-cache, no-store, must-revalidate");
    c.header("Pragma", "no-cache");
    c.header("Expires", "0");

    return c.json({
      success: true,
      orderId: order.id,
      status: order.status,
      statusPt: STATUS_MAP_EN_TO_PT[order.status] || order.status,
      order,
      pedido: order,
    }, 200);
  } catch (e: any) {
    return c.json({ success: false, error: e.message || "Erro ao buscar pedido" }, 500);
  }
});

// SSE Stream público para rastreamento em tempo real do status do pedido no celular do cliente
// 100% orientado a eventos (Zero polling / loops de banco de dados no Cloudflare D1)
api.get("/orders/:orderId/stream", async (c) => {
  const db = getDb(c);
  const rawId = c.req.param("orderId");
  const cleanId = rawId.replace(/^#/, "");

  return streamSSE(c, async (stream) => {
    // 1. Envia estado inicial imediato (e descobre a sala/loja do pedido para assinar o hub)
    let STREAM_ROOM = ALL_TENANTS_ROOM;
    try {
      const initialOrder = await db.getOrderById(rawId);
      if (initialOrder) {
        if (initialOrder.tenantId) STREAM_ROOM = initialOrder.tenantId;
        await stream.writeSSE({
          event: "status_update",
          data: JSON.stringify({
            orderId: cleanId,
            status: initialOrder.status,
            order: initialOrder,
            timestamp: Date.now(),
          }),
        });
      }
    } catch (e) {
      console.warn("SSE initial order fetch error:", e);
    }

    // 2. Inscreve no barramento de eventos (acionado quando o lojista altera o status no admin)
    const unsubscribe = await subscribeOrderEvents(c.env, STREAM_ROOM, async (payload) => {
      const pClean = payload.orderId.replace(/^#/, "");
      if (pClean === cleanId || payload.order.id === rawId || payload.order.id === `#${cleanId}`) {
        try {
          await stream.writeSSE({
            event: "status_update",
            data: JSON.stringify(payload),
          });
        } catch (err) {
          console.warn("Failed to write order SSE event:", err);
        }
      }
    });

    stream.onAbort(() => {
      unsubscribe();
    });

    // 3. Heartbeat keepalive leve (apenas sleep sem consultar o banco)
    while (!stream.aborted) {
      await stream.sleep(25000);
      try {
        await stream.writeSSE({
          event: "ping",
          data: "{}",
        });
      } catch {
        break;
      }
    }

    unsubscribe();
  });
});

api.get("/tenants/:slugOrId/orders/:orderId/stream", async (c) => {
  const db = getDb(c);
  const rawId = c.req.param("orderId");
  const cleanId = rawId.replace(/^#/, "");

  return streamSSE(c, async (stream) => {
    let STREAM_ROOM = ALL_TENANTS_ROOM;
    try {
      const initialOrder = await db.getOrderById(rawId);
      if (initialOrder) {
        if (initialOrder.tenantId) STREAM_ROOM = initialOrder.tenantId;
        await stream.writeSSE({
          event: "status_update",
          data: JSON.stringify({
            orderId: cleanId,
            status: initialOrder.status,
            order: initialOrder,
            timestamp: Date.now(),
          }),
        });
      }
    } catch (e) {
      console.warn("SSE tenant initial order fetch error:", e);
    }

    const unsubscribe = await subscribeOrderEvents(c.env, STREAM_ROOM, async (payload) => {
      const pClean = payload.orderId.replace(/^#/, "");
      if (pClean === cleanId || payload.order.id === rawId || payload.order.id === `#${cleanId}`) {
        try {
          await stream.writeSSE({
            event: "status_update",
            data: JSON.stringify(payload),
          });
        } catch (err) {
          console.warn("Failed to write order SSE event:", err);
        }
      }
    });

    stream.onAbort(() => {
      unsubscribe();
    });

    while (!stream.aborted) {
      await stream.sleep(25000);
      try {
        await stream.writeSSE({
          event: "ping",
          data: "{}",
        });
      } catch {
        break;
      }
    }

    unsubscribe();
  });
});

// ===================== RELATÓRIO FINANCEIRO E DESEMPENHO (CLOUDFLARE D1) =====================
api.get("/tenants/:slugOrId/financial-report", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const tenant = await db.getTenantByIdOrSlug(slugOrId);

    if (!tenant) {
      return c.json({ success: false, error: "Lanchonete não encontrada" }, 404);
    }

    const monthQuery = c.req.query("month");
    const yearQuery = c.req.query("year");
    const startDateQuery = c.req.query("startDate");
    const endDateQuery = c.req.query("endDate");

    const options = {
      month: monthQuery ? parseInt(monthQuery, 10) : undefined,
      year: yearQuery ? parseInt(yearQuery, 10) : undefined,
      startDate: startDateQuery || undefined,
      endDate: endDateQuery || undefined,
    };

    const report = await db.getFinancialReport(tenant.id, options);

    return c.json(
      {
        success: true,
        tenant: {
          id: tenant.id,
          name: tenant.name,
          slug: tenant.slug,
        },
        ...report,
      },
      200
    );
  } catch (e: any) {
    console.error("Erro na rota de relatório financeiro:", e);
    return c.json(
      { success: false, error: e.message || "Erro ao processar relatório financeiro" },
      500
    );
  }
});

// ===================== GERENCIAMENTO DE APARÊNCIA DA VITRINE (CLOUDFLARE D1 / KV) =====================

async function handleGetSettings(c: any) {
  try {
    c.header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
    const db = getDb(c);
    const settings = await db.getPlatformSettings();
    // 3. SEGURANÇA E PRIVACIDADE: Oculta chave privada do código cliente
    const { geminiApiKey, ...safeSettings } = (settings || {}) as any;
    return c.json(
      {
        success: true,
        settings: {
          ...safeSettings,
          hasServerGeminiKey: Boolean(
            geminiApiKey ||
            c?.env?.GEMINI_API_KEY ||
            (typeof process !== "undefined" && process?.env?.GEMINI_API_KEY)
          ),
        },
      },
      200
    );
  } catch (e: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(e) }, 500);
  }
}

async function handlePutAdminSettings(c: any) {
  try {
    const authHeader = c.req.header("Authorization");
    const rawToken = authHeader ? authHeader.replace(/^Bearer\s+/i, "") : null;
    const body = await c.req.json().catch(() => ({}));
    const jwtSecret = getJwtSecret(c);
    let isAuthorized = false;

    if (rawToken) {
      const decoded = await verifyTokenSafely(rawToken, jwtSecret);
      if (decoded?.role === "super_admin") {
        isAuthorized = true;
      } else if (decoded?.userId) {
        const db = getDb(c);
        const user = await db.getUserById(decoded.userId);
        if (user?.role === "super_admin") {
          isAuthorized = true;
        }
      }
    }

    if (!isAuthorized) {
      return c.json(
        {
          success: false,
          error: "Acesso restrito. Apenas Super Administradores da plataforma autenticados com JWT podem alterar as configurações.",
        },
        403
      );
    }

    const db = getDb(c);
    const {
      logoUrl,
      bannerUrl,
      heroTitle,
      heroSubtitle,
      primaryColor,
      geminiApiKey,
      partnerWhatsapp,
      adminWhatsapp,
      adminPixKey,
      adminPixType,
      defaultMonthlyFee,
    } = body;
    const updated = await db.updatePlatformSettings({
      logoUrl: logoUrl !== undefined ? String(logoUrl).trim() : undefined,
      bannerUrl: bannerUrl !== undefined ? String(bannerUrl).trim() : undefined,
      heroTitle: heroTitle !== undefined ? String(heroTitle).trim() : undefined,
      heroSubtitle: heroSubtitle !== undefined ? String(heroSubtitle).trim() : undefined,
      primaryColor: primaryColor !== undefined ? String(primaryColor).trim() : undefined,
      geminiApiKey: geminiApiKey !== undefined ? String(geminiApiKey).trim() : undefined,
      partnerWhatsapp: partnerWhatsapp !== undefined ? String(partnerWhatsapp).trim() : undefined,
      adminWhatsapp: adminWhatsapp !== undefined ? String(adminWhatsapp).trim() : undefined,
      adminPixKey: adminPixKey !== undefined ? String(adminPixKey).trim() : undefined,
      adminPixType: adminPixType !== undefined ? String(adminPixType).trim() : undefined,
      defaultMonthlyFee: defaultMonthlyFee !== undefined ? Number(defaultMonthlyFee) : undefined,
    });

    const { geminiApiKey: _, ...safeUpdated } = (updated || {}) as any;

    return c.json(
      {
        success: true,
        message: "Configurações de aparência da vitrine salvas com sucesso no banco de dados!",
        settings: {
          ...safeUpdated,
          hasServerGeminiKey: Boolean(
            updated.geminiApiKey ||
            c?.env?.GEMINI_API_KEY ||
            (typeof process !== "undefined" && process?.env?.GEMINI_API_KEY)
          ),
        },
      },
      200
    );
  } catch (e: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(e) }, 500);
  }
}

// Rota pública para carregar configurações na vitrine
api.get("/settings", handleGetSettings);
api.get("/api/settings", handleGetSettings);

// Rota protegida para salvar as alterações do Super Admin
api.put("/admin/settings", handlePutAdminSettings);
api.put("/api/admin/settings", handlePutAdminSettings);

// ==========================================
// ROTAS DE STORIES DA LOJA (APENAS FOTOS - EXPIRAÇÃO 24H - MÁX 3)
// ==========================================

async function handleGetStories(c: any) {
  try {
    const db = getDb(c);
    const tenantId = c.req.query("tenantId");
    const slug = c.req.query("slug");
    const onlyActive = c.req.query("active") !== "false";

    if (tenantId || slug) {
      const stories = await db.getStoreStories(tenantId || slug, onlyActive);
      return c.json({ success: true, stories });
    }

    const storiesByTenant = await db.getAllActiveStoriesGrouped();
    return c.json({ success: true, storiesByTenant });
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao listar stories" }, 500);
  }
}

async function handleGetAllActiveStories(c: any) {
  try {
    const db = getDb(c);
    const storiesByTenant = await db.getAllActiveStoriesGrouped();
    return c.json({ success: true, storiesByTenant });
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao listar stories ativos" }, 500);
  }
}

async function handleCreateStory(c: any) {
  try {
    const db = getDb(c);
    const body = await c.req.json();

    const identifier = body.tenantId || body.slug;
    let tenantId = body.tenantId;

    if (identifier) {
      const tenant = await db.getTenantByIdOrSlug(identifier);
      if (tenant) {
        tenantId = tenant.id;
      } else if (!tenantId && body.slug) {
        tenantId = body.slug;
      }
    }

    if (!tenantId) {
      return c.json({ success: false, error: "Identificador da loja (tenantId ou slug) não fornecido." }, 400);
    }

    // Validação estrita: APENAS FOTOS (bloquear vídeos)
    const mediaType = body.mediaType || "image";
    if (mediaType !== "image") {
      return c.json(
        {
          success: false,
          error: "Apenas fotos (JPG, PNG, WEBP) são permitidas nos stories. O envio de vídeos está bloqueado.",
        },
        400
      );
    }

    const mediaUrl = String(body.mediaUrl || "").trim();
    if (!mediaUrl) {
      return c.json({ success: false, error: "A imagem do story é obrigatória." }, 400);
    }

    if (mediaUrl.startsWith("data:video") || /\.(mp4|mov|avi|webm|mkv)(\?.*)?$/i.test(mediaUrl)) {
      return c.json(
        {
          success: false,
          error: "Vídeos não são permitidos. A funcionalidade aceita exclusivamente fotos (JPG, PNG, WEBP).",
        },
        400
      );
    }

    const story = await db.createStoreStory({
      tenantId,
      mediaUrl,
      mediaType: "image",
      caption: body.caption,
    });

    return c.json(
      {
        success: true,
        message: "Story publicado com sucesso! Válido por 24 horas.",
        story,
      },
      201
    );
  } catch (err: any) {
    return c.json(
      {
        success: false,
        error: err.message || "Erro ao publicar story",
      },
      400
    );
  }
}

async function handleDeleteStory(c: any) {
  try {
    const db = getDb(c);
    const id = c.req.param("id");
    const tenantId = c.req.query("tenantId");

    const deleted = await db.deleteStoreStory(id, tenantId);
    if (!deleted) {
      return c.json({ success: false, error: "Story não encontrado ou já expirado." }, 404);
    }

    return c.json({ success: true, message: "Story removido com sucesso." });
  } catch (err: any) {
    return c.json({ success: false, error: err.message || "Erro ao excluir story" }, 500);
  }
}

api.get("/stories", handleGetStories);
api.get("/api/stories", handleGetStories);
api.get("/stories/active", handleGetAllActiveStories);
api.get("/api/stories/active", handleGetAllActiveStories);
api.post("/stories", handleCreateStory);
api.post("/api/stories", handleCreateStory);
api.delete("/stories/:id", handleDeleteStory);
api.delete("/api/stories/:id", handleDeleteStory);

// ==========================================
// ROTAS ADMINISTRATIVAS BLINDADAS: SUPER ADMIN (/api/super-admin/*)
// Protegidas obrigatoriamente por requireSuperAdminMiddleware
// ==========================================

api.get("/api/super-admin/stats", async (c) => {
  try {
    const db = getDb(c);
    const stats = await db.getPlatformStats();
    return c.json({ success: true, stats }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/super-admin/tenants", async (c) => {
  try {
    const db = getDb(c);
    const tenants = await db.getTenants();
    const enriched = await Promise.all(
      tenants.map(async (t) => {
        const [products, orders, creds] = await Promise.all([
          db.getProductsByTenant(t.id),
          db.getOrdersByTenant(t.id),
          db.getTenantCredentials(t.id),
        ]);
        const completedOrders = orders.filter(
          (o) =>
            o.status === "done" ||
            o.status === "Concluído" ||
            o.status === "concluido" ||
            o.status === "Entregue" ||
            o.status === "entregue" ||
            o.status === "finalizado"
        );
        return {
          ...t,
          productCount: products.length,
          orderCount: orders.length,
          completedOrdersCount: completedOrders.length,
          salesCount: orders.filter((o) => o.status !== "cancelled").length,
          revenue: orders.reduce((sum, o) => sum + (o.total || 0), 0),
          adminEmail: creds?.email || t.email,
          adminPassword: creds?.password || "••••••••",
          adminUserId: creds?.userId,
        };
      })
    );
    return c.json({ success: true, tenants: enriched }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/super-admin/credentials/tenants", async (c) => {
  try {
    const db = getDb(c);
    const credentials = await db.getAllTenantCredentials();
    return c.json({ success: true, credentials }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.put("/api/super-admin/credentials", handleUpdateSuperAdminCredentials);

api.put("/api/super-admin/tenants/:slugOrId/credentials", async (c) => {
  try {
    const db = getDb(c);
    const slugOrId = c.req.param("slugOrId");
    const body = await c.req.json();
    const { email, password, name } = body;
    if (!email || !password) {
      return c.json({ success: false, error: "E-mail e senha são obrigatórios para a loja." }, 400);
    }
    const cleanEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password).trim();
    if (cleanPassword.length < 4) {
      return c.json({ success: false, error: "A senha deve ter no mínimo 4 caracteres." }, 400);
    }
    const result = await db.updateTenantCredentials(slugOrId, cleanEmail, cleanPassword, name);
    return c.json({
      success: true,
      message: `Credenciais da loja "${result.tenant.name}" atualizadas com sucesso!`,
      credentials: result.credentials,
      tenant: result.tenant,
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/super-admin/settings", handleGetSettings);
api.put("/api/super-admin/settings", handlePutAdminSettings);

// ==========================================
// ROTAS ADMINISTRATIVAS BLINDADAS: LOJISTAS (/api/merchant/*)
// Protegidas obrigatoriamente por requireMerchantMiddleware
// ==========================================

api.get("/api/merchant/me", async (c) => {
  try {
    const user = c.get("user");
    if (!user) {
      return c.json({ success: false, error: "Sessão não encontrada." }, 401);
    }
    const db = getDb(c);
    let tenant = null;
    if (user.tenantId) {
      tenant = await db.getTenantByIdOrSlug(user.tenantId);
    }
    return c.json({ success: true, user, tenant }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/merchant/store", async (c) => {
  try {
    const user = c.get("user");
    const db = getDb(c);
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada a este usuário." }, 400);
    }
    const tenant = await db.getTenantByIdOrSlug(tenantId);
    if (!tenant) {
      return c.json({ success: false, error: "Loja não encontrada." }, 404);
    }
    return c.json({ success: true, tenant }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.put("/api/merchant/store", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada a este usuário." }, 400);
    }
    const db = getDb(c);
    const body = await c.req.json();
    const updated = await db.updateTenant(tenantId, body);
    if (!updated) {
      return c.json({ success: false, error: "Loja não encontrada para atualização." }, 404);
    }
    return c.json({ success: true, tenant: updated, message: "Dados da loja atualizados com sucesso." }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/merchant/products", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const products = await db.getProductsByTenant(tenantId);
    return c.json({ success: true, products }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.post("/api/merchant/products", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const body = await c.req.json();
    const product = await db.createProduct({ ...body, tenantId });
    return c.json({ success: true, product, message: "Produto cadastrado com sucesso." }, 201);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.put("/api/merchant/products/:id", async (c) => {
  try {
    const productId = c.req.param("id");
    const db = getDb(c);
    const body = await c.req.json();
    const updated = await db.updateProduct(productId, body);
    if (!updated) {
      return c.json({ success: false, error: "Produto não encontrado." }, 404);
    }
    return c.json({ success: true, product: updated, message: "Produto atualizado com sucesso." }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.delete("/api/merchant/products/:id", async (c) => {
  try {
    const productId = c.req.param("id");
    const db = getDb(c);
    const deleted = await db.deleteProduct(productId);
    if (!deleted) {
      return c.json({ success: false, error: "Produto não encontrado para remoção." }, 404);
    }
    return c.json({ success: true, message: "Produto excluído com sucesso." }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.post("/api/merchant/products/reorder", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const body = await c.req.json();
    const { orderedIds } = body;
    if (!Array.isArray(orderedIds)) {
      return c.json({ success: false, error: "Lista orderedIds inválida." }, 400);
    }
    const db = getDb(c);
    await db.reorderProducts(tenantId, orderedIds);
    return c.json({ success: true, message: "Ordem dos produtos atualizada com sucesso." }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/merchant/orders", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const orders = await db.getOrdersByTenant(tenantId);
    return c.json({ success: true, orders }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.patch("/api/merchant/orders/:id/status", handleStatusUpdate);

api.get("/api/merchant/financial-report", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const report = await db.getTenantFinancialReport(tenantId);
    return c.json({ success: true, ...report }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/merchant/customers", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const customers = await db.getTenantCustomers(tenantId);
    return c.json({ success: true, customers }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.get("/api/merchant/stories", async (c) => {
  try {
    const user = c.get("user");
    const tenantId = user?.tenantId;
    if (!tenantId) {
      return c.json({ success: false, error: "Nenhuma loja vinculada." }, 400);
    }
    const db = getDb(c);
    const stories = await db.getStoreStories(tenantId);
    return c.json({ success: true, stories }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: sanitizeErrorMessage(err) }, 500);
  }
});

api.post("/api/merchant/stories", handleCreateStory);
api.delete("/api/merchant/stories/:id", handleDeleteStory);

// =========================================================================
// PUSH TOKENS DO LOJISTA (FCM / APNs)
// =========================================================================

// POST /api/admin/push-token - Registrar token da sessão do lojista logado
api.post("/admin/push-token", async (c) => {
  try {
    const db = getDb(c);
    const body = await c.req.json();
    const { tenantId, token, platform, userId } = body;

    if (!tenantId || !token) {
      return c.json({ success: false, error: "tenantId e token são obrigatórios" }, 400);
    }

    await db.saveMerchantPushToken(tenantId, {
      token,
      platform: platform || "web",
      userId,
    });

    return c.json({
      success: true,
      message: "Token de notificação push ativado com sucesso para esta sessão.",
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message }, 500);
  }
});

// DELETE /api/admin/push-token - Desativar token quando o lojista desloga
api.delete("/admin/push-token", async (c) => {
  try {
    const db = getDb(c);
    const body = await c.req.json().catch(() => ({}));
    const tenantId = body.tenantId || c.req.query("tenantId");
    const token = body.token || c.req.query("token");

    if (tenantId && token) {
      await db.removeMerchantPushToken(tenantId, token);
    }

    return c.json({
      success: true,
      message: "Token de notificação push revogado (sessão finalizada).",
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message }, 500);
  }
});

// GET /api/admin/push-status - Verificar se há sessão de lojista ativa para a loja
api.get("/admin/push-status", async (c) => {
  try {
    const db = getDb(c);
    const tenantId = c.req.query("tenantId") || c.req.query("slug");

    if (!tenantId) {
      return c.json({ success: false, error: "tenantId é obrigatório" }, 400);
    }

    const activeTokens = await db.getActiveMerchantPushTokens(tenantId);
    return c.json({
      success: true,
      isMerchantLoggedIn: activeTokens.length > 0,
      activeTokensCount: activeTokens.length,
      devices: activeTokens.map((t) => t.platform),
    }, 200);
  } catch (err: any) {
    return c.json({ success: false, error: err.message }, 500);
  }
});

export default api;

