export type UserRole = "super_admin" | "tenant_admin";

export type TenantStatus = "active" | "inactive";
export type SubscriptionStatus = "demo" | "active" | "overdue" | "cancelled";

export interface TenantCredential {
  tenantId: string;
  tenantName: string;
  tenantSlug: string;
  userId: string;
  email: string;
  password?: string;
  name: string;
  status: string;
}

export type PixKeyType = "cpf" | "cnpj" | "phone" | "email" | "random";

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  email: string;
  phone?: string;
  whatsapp: string;
  motoboyPhone?: string;
  motoboy_phone?: string;
  motoboyName?: string;
  motoboy_name?: string;
  pixKey: string;
  pixKeyType: PixKeyType;
  deliveryFee: number;
  deliveryTime?: string;
  address: string;
  hours: string;
  tagline: string;
  announcement?: string;
  logo: string;
  bannerImage?: string;
  primaryColor: string;
  secondaryColor?: string;
  primaryDark: string;
  primaryLight: string;
  accentColor: string;
  themeMode?: "light" | "dark";
  menuLayout?: "list" | "grid";
  showFeaturedCarousel?: boolean;
  isFeatured?: boolean;
  priorityOrder?: number;
  businessType?: string;
  category?: string;
  categoryId?: string;
  category_id?: string;
  localidade?: string;
  location?: string;
  rating?: number;
  ratingCount?: number;
  status: TenantStatus;
  subscriptionStatus?: SubscriptionStatus;
  billingDay?: number;
  lastPaymentAt?: number;
  monthlyFee?: number;
  isOpen: boolean;
  createdAt: number;
  updatedAt: number;
  productCount?: number;
  orderCount?: number;
  completedOrdersCount?: number;
  salesCount?: number;
  revenue?: number;
}

export interface PlatformSettings {
  logoUrl?: string;
  bannerUrl?: string;
  heroTitle?: string;
  heroSubtitle?: string;
  primaryColor?: string;
  geminiApiKey?: string;
  adminPixKey?: string;
  adminPixType?: string;
  adminWhatsapp?: string;
  partnerWhatsapp?: string;
  defaultMonthlyFee?: number;
  updatedAt?: number;
}

export interface User {
  id: string;
  email: string;
  password?: string;
  name: string;
  role: UserRole;
  tenantId?: string | null;
  status: "active" | "inactive";
  createdAt: number;
  updatedAt?: number;
}

export interface ProductOption {
  id: string;
  name: string;
  price: number;
  groupId?: string;
  groupName?: string;
}

export interface AddonItem {
  id: string;
  name: string;
  price: number;
  available?: boolean;
}

export interface AddonGroup {
  id: string;
  tenantId: string;
  name: string;
  description?: string;
  minSelection: number; // 0 para opcional, >= 1 para obrigatório
  maxSelection: number; // 0 para ilimitado, ou valor numérico
  required?: boolean;
  items: AddonItem[];
  position?: number;
  createdAt?: number;
  updatedAt?: number;
}

export interface Product {
  id: string;
  tenantId?: string;
  name: string;
  description?: string;
  price: number;
  image?: string;
  category?: string;
  available?: boolean;
  options?: ProductOption[];
  addonGroupIds?: string[];
  addonGroups?: AddonGroup[];
  position?: number;
  ordem?: number;
  order?: number;
  createdAt?: number;
}

export interface Category {
  id: string;
  name: string;
  icon?: string;
  tenantId?: string;
  order?: number;
  order_index?: number;
  createdAt?: number;
}

export interface EstablishmentCategory {
  id: string;
  name: string;
  icon: string;
  order: number;
  order_index?: number;
  active?: boolean;
  createdAt?: number;
}

export type OrderType = "delivery" | "pickup" | "dine_in";
export type PaymentMethod = "pix" | "card" | "cash";
export type CardType = "credit" | "debit";
export type OrderStatus = "received" | "preparing" | "delivering" | "done" | "cancelled";

export interface OrderItem {
  id: string;
  product: {
    id: string;
    name: string;
    price: number;
    image?: string;
    category?: string;
    description?: string;
    available?: boolean;
    options?: ProductOption[];
  };
  quantity: number;
  selectedOptions: ProductOption[];
  notes: string;
}

export interface Order {
  id: string;
  tenantId: string;
  customerName: string;
  customerPhone: string;
  orderType: OrderType;
  /** Tipo canônico salvo/derivado do banco: 'delivery' | 'retirada' | 'mesa' */
  tipo_pedido?: "delivery" | "retirada" | "mesa";
  tableNumber?: string;
  table_number?: string;
  mesa?: string;
  table?: string;
  paymentMethod: PaymentMethod;
  cardType?: CardType;
  paymentDetails?: string;
  pixReceiptUrl?: string;
  pix_receipt_url?: string;
  location_url?: string;
  locationUrl?: string;
  address?: {
    street: string;
    number: string;
    district: string;
    complement: string;
    reference: string;
  };
  changeFor?: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  items: OrderItem[];
  statusHistory: { status: OrderStatus; timestamp: number }[];
  createdAt: number;
  idempotencyKey?: string;
  idempotency_key?: string;
  cart_id?: string;
  duplicated?: boolean;
}

export interface Customer {
  id: string;
  tenantId: string;
  name: string;
  phone: string;
  street?: string;
  number?: string;
  district?: string;
  complement?: string;
  reference?: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderAt: number;
  createdAt: number;
  updatedAt: number;
}

// Cloudflare Workers Bindings via env object
export interface CloudflareD1Result<T = unknown> {
  results?: T[];
  success: boolean;
  meta?: Record<string, unknown>;
}

export interface CloudflareD1PreparedStatement {
  bind(...values: unknown[]): CloudflareD1PreparedStatement;
  all<T = unknown>(): Promise<CloudflareD1Result<T>>;
  run<T = unknown>(): Promise<CloudflareD1Result<T>>;
  first<T = unknown>(colName?: string): Promise<T | null>;
}

export interface CloudflareD1Database {
  prepare(query: string): CloudflareD1PreparedStatement;
  batch?(statements: CloudflareD1PreparedStatement[]): Promise<unknown[]>;
  exec(query: string): Promise<unknown>;
}

export interface CloudflareKVNamespace {
  get(key: string): Promise<string | null>;
  put(key: string, value: string, options?: { expirationTtl?: number }): Promise<void>;
  delete(key: string): Promise<void>;
}

// Durable Objects (tipagem mínima para não depender de @cloudflare/workers-types)
export interface DurableObjectIdLike {
  toString(): string;
}

export interface DurableObjectStubLike {
  fetch(input: Request | string, init?: RequestInit): Promise<Response>;
}

export interface DurableObjectNamespaceLike {
  idFromName(name: string): DurableObjectIdLike;
  get(id: DurableObjectIdLike): DurableObjectStubLike;
}

export interface Env {
  DB?: CloudflareD1Database;
  /** Hub de eventos em tempo real (Durable Object) - ponte SSE entre isolates do Workers */
  ORDER_HUB?: DurableObjectNamespaceLike;
  KV?: CloudflareKVNamespace;
  STORE_KV?: CloudflareKVNamespace;
  ASSETS?: { fetch: (req: Request | string) => Promise<Response> };
  __STATIC_CONTENT?: unknown;
  PLATFORM_NAME?: string;
  ENVIRONMENT?: string;
  JWT_SECRET?: string;
  GEMINI_API_KEY?: string;
}

export interface FinancialMetrics {
  todayRevenue: number;
  monthRevenue: number;
  monthCompletedOrders: number;
  averageTicket: number;
  todayCompletedOrders: number;
  deliveredCount: number;
  pickupCount: number;
  deliveryFeeTotal: number;
}

export interface DailyRevenueItem {
  day: number;
  date: string;
  dayOfWeek: string;
  revenue: number;
  ordersCount: number;
}

export interface PaymentBreakdownItem {
  method: PaymentMethod | string;
  label: string;
  total: number;
  count: number;
  percent: number;
}

export interface FinancialReportData {
  period: {
    month: number;
    year: number;
    monthName: string;
    startDate: string;
    endDate: string;
  };
  metrics: FinancialMetrics;
  dailyRevenue: DailyRevenueItem[];
  paymentBreakdown: PaymentBreakdownItem[];
  orders: Order[];
}

export interface TopSellingProduct {
  id: string;
  productId: string;
  name: string;
  price: number;
  image?: string;
  description?: string;
  category?: string;
  available?: boolean;
  options?: ProductOption[];
  addonGroupIds?: string[];
  tenantId: string;
  tenantName: string;
  tenantSlug: string;
  tenantLogo?: string;
  tenantPrimaryColor?: string;
  tenantIsOpen?: boolean;
  tenantDeliveryFee?: number;
  tenantDeliveryTime?: string;
  location?: string;
  localidade?: string;
  totalSold: number;
  rank?: number;
}

export interface FeaturedStoreRanked extends Tenant {
  completedOrdersCount: number;
  salesCount: number;
  rank: number;
}

export interface StoreStory {
  id: string;
  tenantId: string;
  mediaUrl: string; // Base64 data URL ou URL de imagem (JPG, PNG, WEBP)
  mediaType: "image"; // APENAS FOTOS
  caption?: string;
  createdAt: number;
  expiresAt: number; // created_at + 24 * 60 * 60 * 1000
}
