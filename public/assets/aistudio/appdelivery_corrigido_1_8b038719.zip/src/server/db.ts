import type {
  Env,
  Tenant,
  User,
  Product,
  Category,
  EstablishmentCategory,
  Order,
  OrderStatus,
  TenantStatus,
  Customer,
  FinancialReportData,
  DailyRevenueItem,
  PaymentBreakdownItem,
  PlatformSettings,
  TopSellingProduct,
  FeaturedStoreRanked,
  StoreStory,
  AddonGroup,
} from "./types";
import { publishOrderEvent } from "./events";
import { hashPassword, verifyPassword } from "./security";
import { extraTenants, extraUsers, extraProducts, extraStories, extraAddonGroups } from "./seedData";

// =========================================================================
// GESTÃO E EXCLUSÃO DEFINITIVA DE LOJAS (D1 / KV / DISCO / MEMÓRIA)
// =========================================================================
export function getPersistedDeletedTenants(): string[] {
  const result: string[] = [];
  try {
    if (typeof globalThis !== "undefined" && Array.isArray((globalThis as any).__TOPFOOD_DELETED_TENANTS__)) {
      for (const item of (globalThis as any).__TOPFOOD_DELETED_TENANTS__) {
        if (typeof item === "string" && !result.includes(item.toLowerCase())) {
          result.push(item.toLowerCase());
        }
      }
    }
  } catch (_e) {
    void _e;
  }

  try {
    const proc = (globalThis as any).process;
    const req = (globalThis as any).require;
    if (typeof proc !== "undefined" && typeof req === "function") {
      const fs = req("fs");
      const path = req("path");
      const filePath = path.resolve(proc.cwd(), ".topfood_deleted_tenants.json");
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, "utf-8");
        const list = JSON.parse(raw);
        if (Array.isArray(list)) {
          for (const item of list) {
            if (typeof item === "string" && !result.includes(item.toLowerCase())) {
              result.push(item.toLowerCase());
            }
          }
        }
      }
    }
  } catch (_e) {
    void _e;
  }

  return result;
}

export function persistDeletedTenant(idOrSlug: string): void {
  if (!idOrSlug) return;
  const lower = idOrSlug.toLowerCase().trim();
  if (!lower) return;

  try {
    if (typeof globalThis !== "undefined") {
      if (!Array.isArray((globalThis as any).__TOPFOOD_DELETED_TENANTS__)) {
        (globalThis as any).__TOPFOOD_DELETED_TENANTS__ = [];
      }
      if (!(globalThis as any).__TOPFOOD_DELETED_TENANTS__.includes(lower)) {
        (globalThis as any).__TOPFOOD_DELETED_TENANTS__.push(lower);
      }
    }
  } catch (_e) {
    void _e;
  }

  try {
    const proc = (globalThis as any).process;
    const req = (globalThis as any).require;
    if (typeof proc !== "undefined" && typeof req === "function") {
      const fs = req("fs");
      const path = req("path");
      const filePath = path.resolve(proc.cwd(), ".topfood_deleted_tenants.json");
      let list: string[] = [];
      if (fs.existsSync(filePath)) {
        try {
          list = JSON.parse(fs.readFileSync(filePath, "utf-8"));
        } catch (_parseErr) {
          void _parseErr;
        }
      }
      if (!Array.isArray(list)) list = [];
      if (!list.includes(lower)) {
        list.push(lower);
        fs.writeFileSync(filePath, JSON.stringify(list, null, 2), "utf-8");
      }
    }
  } catch (_e) {
    void _e;
  }
}

export function isTenantPermanentlyDeleted(idOrSlug: string): boolean {
  if (!idOrSlug) return false;
  const lower = idOrSlug.toLowerCase().trim();
  const deleted = getPersistedDeletedTenants();
  return deleted.includes(lower);
}

// =========================================================================
// PERSISTÊNCIA DE ALTERAÇÕES DE LOJAS EM DISCO / MEMÓRIA (NODE.JS / PREVIEW)
// =========================================================================
export function getPersistedTenantOverrides(): Record<string, Partial<Tenant>> {
  const result: Record<string, Partial<Tenant>> = {};
  try {
    if (
      typeof globalThis !== "undefined" &&
      (globalThis as any).__TOPFOOD_TENANT_OVERRIDES__ &&
      typeof (globalThis as any).__TOPFOOD_TENANT_OVERRIDES__ === "object"
    ) {
      Object.assign(result, (globalThis as any).__TOPFOOD_TENANT_OVERRIDES__);
    }
  } catch (_e) {
    void _e;
  }

  try {
    const proc = (globalThis as any).process;
    const req = (globalThis as any).require;
    if (typeof proc !== "undefined" && typeof req === "function") {
      const fs = req("fs");
      const path = req("path");
      const filePath = path.resolve(proc.cwd(), ".topfood_tenant_overrides.json");
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          Object.assign(result, parsed);
        }
      }
    }
  } catch (_e) {
    void _e;
  }

  return result;
}

export function persistTenantOverride(tenantId: string, partial: Partial<Tenant>): void {
  if (!tenantId) return;
  try {
    const current = getPersistedTenantOverrides();
    current[tenantId] = {
      ...(current[tenantId] || {}),
      ...partial,
      updatedAt: Date.now(),
    };
    if (typeof globalThis !== "undefined") {
      (globalThis as any).__TOPFOOD_TENANT_OVERRIDES__ = current;
      if (typeof (globalThis as any).__TOPFOOD_PERSIST_OVERRIDE__ === "function") {
        (globalThis as any).__TOPFOOD_PERSIST_OVERRIDE__(current);
      }
    }
    const proc = (globalThis as any).process;
    const req = (globalThis as any).require;
    if (typeof proc !== "undefined" && typeof req === "function") {
      const fs = req("fs");
      const path = req("path");
      const filePath = path.resolve(proc.cwd(), ".topfood_tenant_overrides.json");
      fs.writeFileSync(filePath, JSON.stringify(current, null, 2), "utf-8");
    }
  } catch (_e) {
    void _e;
  }
}

// Seed data para demonstração e inicialização
const initialTenants: Tenant[] = [
  // 1. Açaiteria
  {
    id: "tenant-acai-do-vale",
    name: "Açaí Puro & Bowls",
    slug: "acai-do-vale",
    email: "contato@acaipuro.com.br",
    phone: "11966666666",
    whatsapp: "5511966666666",
    motoboyPhone: "5511966666666",
    motoboyName: "Carlos Entregas",
    pixKey: "contato@acaipuro.com.br",
    pixKeyType: "email",
    deliveryFee: 4.0,
    deliveryTime: "25-40 min",
    address: "Av. Brasil, 890 - Centro",
    hours: "12:00 - 23:00",
    tagline: "O autêntico açaí do Pará 100% puro com acompanhamentos à vontade",
    announcement: "🍧 Monte seu copo ou tigela com camadas de frutas frescas, cremes e adicionais à vontade!",
    logo: "🍧",
    bannerImage: "https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#7E22CE",
    secondaryColor: "#1E1B4B",
    primaryDark: "#6B21A8",
    primaryLight: "#A855F7",
    accentColor: "#EAB308",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 10,
    businessType: "Açaíterias",
    localidade: "Gargaú",
    rating: 4.9,
    ratingCount: 245,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 10 * 86400000,
    updatedAt: Date.now(),
  },
  // 2. Hambúrgueres
  {
    id: "tenant-burger-town",
    name: "Burger Town Artesanal",
    slug: "burger-town",
    email: "admin@burgertown.com",
    phone: "11999999999",
    whatsapp: "5511999999999",
    motoboyPhone: "5511999999999",
    motoboyName: "Lucas Motoboy",
    pixKey: "contato@burgertown.com.br",
    pixKeyType: "email",
    deliveryFee: 5.0,
    deliveryTime: "30-45 min",
    address: "Rua das Chamas, 420 - Centro",
    hours: "18:00 - 23:45",
    tagline: "Smash e burgers artesanais grelhados no fogo com queijo derretido e bacon",
    announcement: "🔥 Pão brioche selado e blend angus especial. Entrega rápida e quentinha!",
    logo: "🍔",
    bannerImage: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#E63946",
    secondaryColor: "#1E293B",
    primaryDark: "#C1121F",
    primaryLight: "#F77F00",
    accentColor: "#FCBF49",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 9,
    businessType: "Hambúrgueres",
    localidade: "São Francisco (Centro)",
    rating: 4.9,
    ratingCount: 380,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 30 * 86400000,
    updatedAt: Date.now(),
  },
  // 3. Pizzaria
  {
    id: "tenant-pizza-bella",
    name: "Bella Pizza Forno a Lenha",
    slug: "pizza-bella",
    email: "admin@pizzabella.com",
    phone: "11988888888",
    whatsapp: "5511988888888",
    motoboyPhone: "5511988888888",
    motoboyName: "Rafael Pizza",
    pixKey: "pedidos@pizzabella.com.br",
    pixKeyType: "email",
    deliveryFee: 6.0,
    deliveryTime: "35-50 min",
    address: "Av. Paulista, 1500 - Bela Vista",
    hours: "18:30 - 00:00",
    tagline: "Massa de fermentação natural de 48h, molho artesanal e bordas recheadas",
    announcement: "🍕 Promoção: Borda recheada de Catupiry ou Cheddar grátis em pizzas grandes!",
    logo: "🍕",
    bannerImage: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#D97706",
    secondaryColor: "#0F172A",
    primaryDark: "#B45309",
    primaryLight: "#F59E0B",
    accentColor: "#EF4444",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 8,
    businessType: "Pizzarias",
    localidade: "Barra do Itabapoana",
    rating: 4.8,
    ratingCount: 310,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 15 * 86400000,
    updatedAt: Date.now(),
  },
  // 4. Sorveteria
  {
    id: "tenant-sorvetes-imperial",
    name: "Gelateria & Sorvetes Imperial",
    slug: "sorvetes-imperial",
    email: "contato@sorvetesimperial.com.br",
    phone: "11977777777",
    whatsapp: "5511977777777",
    motoboyPhone: "5511977777777",
    motoboyName: "Diego Gelato",
    pixKey: "contato@sorvetesimperial.com.br",
    pixKeyType: "email",
    deliveryFee: 4.5,
    deliveryTime: "20-35 min",
    address: "Rua das Palmeiras, 350 - Jardins",
    hours: "13:00 - 22:30",
    tagline: "Gelatos italianos autênticos, picolés artesanais e taças montadas",
    announcement: "🍨 Embalagens térmicas especiais com gelo seco: gelato cremoso e firme na sua casa!",
    logo: "🍨",
    bannerImage: "https://images.unsplash.com/photo-1501443762994-82bd5dace89a?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#0284C7",
    secondaryColor: "#0F172A",
    primaryDark: "#0369A1",
    primaryLight: "#38BDF8",
    accentColor: "#F59E0B",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 7,
    businessType: "Sorveterias",
    localidade: "São Francisco (Centro)",
    rating: 4.9,
    ratingCount: 192,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 12 * 86400000,
    updatedAt: Date.now(),
  },
  // 5. Japonesa
  {
    id: "tenant-sushi-ya",
    name: "Tokyo Sushi & Temakeria",
    slug: "tokyo-sushi",
    email: "contato@tokyosushi.com.br",
    phone: "11944444444",
    whatsapp: "5511944444444",
    motoboyPhone: "5511944444444",
    motoboyName: "Kenji Entregador",
    pixKey: "contato@tokyosushi.com.br",
    pixKeyType: "email",
    deliveryFee: 7.0,
    deliveryTime: "35-50 min",
    address: "Rua Liberdade, 320 - Bairro Oriental",
    hours: "18:00 - 23:30",
    tagline: "Sashimis frescos, combinados especiais, hot rolls crocantes e temakis generosos",
    announcement: "🍣 Peixes frescos selecionados diariamente, wasabi de verdade e molho tarê artesanal!",
    logo: "🍣",
    bannerImage: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#BE123C",
    secondaryColor: "#1C1917",
    primaryDark: "#9F1239",
    primaryLight: "#FB7185",
    accentColor: "#E11D48",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 6,
    businessType: "Japonesa",
    localidade: "São Francisco (Centro)",
    rating: 4.9,
    ratingCount: 410,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 18 * 86400000,
    updatedAt: Date.now(),
  },
  // 6. Salgados
  {
    id: "tenant-rei-dos-salgados",
    name: "Rei dos Salgados & Coxinhas",
    slug: "rei-dos-salgados",
    email: "contato@reidossalgados.com.br",
    phone: "11933333333",
    whatsapp: "5511933333333",
    motoboyPhone: "5511933333333",
    motoboyName: "Eduardo Salgados",
    pixKey: "contato@reidossalgados.com.br",
    pixKeyType: "email",
    deliveryFee: 5.0,
    deliveryTime: "20-35 min",
    address: "Av. Central, 550 - Bairro Novo",
    hours: "09:00 - 21:00",
    tagline: "Coxinhas com massa de batata crocante, empadas finas, kibes e centos para festa",
    announcement: "🥟 Fritos na hora da entrega! Monte seu cento ou caixinha mista quentinha.",
    logo: "🥟",
    bannerImage: "https://images.unsplash.com/photo-1628294895950-9805252327bc?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#EA580C",
    secondaryColor: "#292524",
    primaryDark: "#C2410C",
    primaryLight: "#FB923C",
    accentColor: "#F59E0B",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 5,
    businessType: "Salgados",
    localidade: "Gargaú",
    rating: 4.8,
    ratingCount: 275,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 14 * 86400000,
    updatedAt: Date.now(),
  },
  // 7. Marmitaria
  {
    id: "tenant-marmitaria-dona-maria",
    name: "Marmitaria Dona Maria",
    slug: "marmitaria-dona-maria",
    email: "contato@marmitariadonamaria.com.br",
    phone: "11922222222",
    whatsapp: "5511922222222",
    motoboyPhone: "5511922222222",
    motoboyName: "Jorge Marmitex",
    pixKey: "contato@marmitariadonamaria.com.br",
    pixKeyType: "email",
    deliveryFee: 3.5,
    deliveryTime: "25-40 min",
    address: "Rua dos Coqueiros, 140 - Vila Nova",
    hours: "10:30 - 15:00",
    tagline: "Comida caseira de verdade feita no capricho com tempero de mãe e entrega rápida",
    announcement: "🍱 Cardápio diário com feijoada, bife acebolado, parmegiana e opções fitness balanceadas!",
    logo: "🍱",
    bannerImage: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#15803D",
    secondaryColor: "#14532D",
    primaryDark: "#166534",
    primaryLight: "#4ADE80",
    accentColor: "#FACC15",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 4,
    businessType: "Marmitaria",
    localidade: "Barra do Itabapoana",
    rating: 4.9,
    ratingCount: 520,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 25 * 86400000,
    updatedAt: Date.now(),
  },
  // 8. Doces
  {
    id: "tenant-doce-encanto",
    name: "Doce Encanto Confeitaria & Bolos",
    slug: "doce-encanto",
    email: "contato@doceencanto.com.br",
    phone: "11911111111",
    whatsapp: "5511911111111",
    motoboyPhone: "5511911111111",
    motoboyName: "Felipe Doce",
    pixKey: "contato@doceencanto.com.br",
    pixKeyType: "email",
    deliveryFee: 4.5,
    deliveryTime: "25-40 min",
    address: "Alameda das Flores, 770 - Jardim Primavera",
    hours: "12:00 - 22:00",
    tagline: "Bolos vulcão, fatias gourmet, brigadeiros belgas e sobremesas refinadas no pote",
    announcement: "🍰 Sobremesas artesanais com chocolate nobre e morangos frescos. Adoce o seu dia!",
    logo: "🍰",
    bannerImage: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#DB2777",
    secondaryColor: "#831843",
    primaryDark: "#BE185D",
    primaryLight: "#F472B6",
    accentColor: "#FBBF24",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 3,
    businessType: "Doces",
    localidade: "Gargaú",
    rating: 5.0,
    ratingCount: 168,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 16 * 86400000,
    updatedAt: Date.now(),
  },
  // 9. Churrascaria
  {
    id: "tenant-sabor-e-brasa",
    name: "Boi Dourado Churrascaria & Brasa",
    slug: "sabor-e-brasa",
    email: "contato@saborebrasa.com.br",
    phone: "11955555555",
    whatsapp: "5511955555555",
    motoboyPhone: "5511955555555",
    motoboyName: "Marcos Brasa",
    pixKey: "contato@saborebrasa.com.br",
    pixKeyType: "email",
    deliveryFee: 6.5,
    deliveryTime: "30-50 min",
    address: "Rua do Comércio, 1200 - Centro",
    hours: "11:00 - 23:00",
    tagline: "Cortes nobres na brasa de carvão: picanha, costela assada no bafo e guarnições",
    announcement: "🥩 Cortes nobres fatiados com farofa crocante, vinagrete da casa e mandioca na manteiga de garrafa!",
    logo: "🥩",
    bannerImage: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#991B1B",
    secondaryColor: "#18181B",
    primaryDark: "#7F1D1D",
    primaryLight: "#EF4444",
    accentColor: "#F59E0B",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 2,
    businessType: "Churrascaria",
    localidade: "São Francisco (Centro)",
    rating: 4.8,
    ratingCount: 340,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 20 * 86400000,
    updatedAt: Date.now(),
  },
  // 10. Bebidas
  {
    id: "tenant-adega-zero-grau",
    name: "Adega & Distribuidora Zero Grau",
    slug: "adega-zero-grau",
    email: "contato@adegazerograu.com.br",
    phone: "11987654321",
    whatsapp: "5511987654321",
    motoboyPhone: "5511987654321",
    motoboyName: "Bruno Express",
    pixKey: "contato@adegazerograu.com.br",
    pixKeyType: "email",
    deliveryFee: 5.0,
    deliveryTime: "15-30 min",
    address: "Av. das Nações, 1020 - Centro",
    hours: "14:00 - 02:00",
    tagline: "Cervejas estupidamente geladas, destilados, vinhos, energéticos, gelo e carvão",
    announcement: "🍺 Entrega expressa em até 30 minutos: bebida na temperatura certa para o seu rolê!",
    logo: "🍺",
    bannerImage: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#0D9488",
    secondaryColor: "#134E4A",
    primaryDark: "#0F766E",
    primaryLight: "#2DD4BF",
    accentColor: "#F59E0B",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 1,
    businessType: "Bebidas",
    localidade: "Barra do Itabapoana",
    rating: 4.9,
    ratingCount: 295,
    status: "active",
    isOpen: true,
    createdAt: Date.now() - 22 * 86400000,
    updatedAt: Date.now(),
  },
  // 11. MS Preparações (Lanches e Burger Artesanal)
  {
    id: "tenant-ms-preparacoes",
    name: "MS Preparações",
    slug: "ms-preparacoes",
    email: "marcelinosantana23@gmail.com",
    phone: "11999999999",
    whatsapp: "5511999999999",
    motoboyPhone: "5511999999999",
    motoboyName: "Marcelino Motoboy",
    pixKey: "marcelinosantana23@gmail.com",
    pixKeyType: "email",
    deliveryFee: 5.0,
    deliveryTime: "25-40 min",
    address: "Rua das Preparações, 100 - Centro",
    hours: "18:00 - 23:30",
    tagline: "O melhor sabor e lanches artesanais preparados na hora",
    announcement: "🔥 Bem-vindo à MS Preparações! Peça pelo WhatsApp ou direto no cardápio.",
    logo: "🍔",
    bannerImage: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1200&q=80",
    primaryColor: "#E63946",
    secondaryColor: "#1E293B",
    primaryDark: "#C1121F",
    primaryLight: "#F77F00",
    accentColor: "#FCBF49",
    themeMode: "light",
    menuLayout: "list",
    showFeaturedCarousel: true,
    isFeatured: true,
    priorityOrder: 10,
    businessType: "Hambúrgueres",
    localidade: "Gargaú",
    rating: 4.9,
    ratingCount: 184,
    status: "active",
    isOpen: true,
    subscriptionStatus: "demo",
    monthlyFee: 49.9,
    createdAt: Date.now() - 5 * 86400000,
    updatedAt: Date.now(),
  },
  ...extraTenants,
];

const initialUsers: User[] = [
  {
    id: "user-superadmin",
    email: "superadmin@plataforma.com",
    password: "admin123",
    name: "Diretor da Plataforma",
    role: "super_admin",
    tenantId: null,
    status: "active",
    createdAt: Date.now() - 60 * 86400000,
  },
  {
    id: "user-acai",
    email: "contato@acaipuro.com.br",
    password: "admin",
    name: "Gerente Açaí Puro",
    role: "tenant_admin",
    tenantId: "tenant-acai-do-vale",
    status: "active",
    createdAt: Date.now() - 10 * 86400000,
  },
  {
    id: "user-burgertown",
    email: "admin@burgertown.com",
    password: "admin",
    name: "Carlos Burguer",
    role: "tenant_admin",
    tenantId: "tenant-burger-town",
    status: "active",
    createdAt: Date.now() - 30 * 86400000,
  },
  {
    id: "user-pizzabella",
    email: "admin@pizzabella.com",
    password: "admin",
    name: "Luigi Pizza",
    role: "tenant_admin",
    tenantId: "tenant-pizza-bella",
    status: "active",
    createdAt: Date.now() - 15 * 86400000,
  },
  {
    id: "user-sorvetes",
    email: "contato@sorvetesimperial.com.br",
    password: "admin",
    name: "Sofia Gelato",
    role: "tenant_admin",
    tenantId: "tenant-sorvetes-imperial",
    status: "active",
    createdAt: Date.now() - 12 * 86400000,
  },
  {
    id: "user-sushi",
    email: "contato@tokyosushi.com.br",
    password: "admin",
    name: "Kenji Sushi",
    role: "tenant_admin",
    tenantId: "tenant-sushi-ya",
    status: "active",
    createdAt: Date.now() - 18 * 86400000,
  },
  {
    id: "user-salgados",
    email: "contato@reidossalgados.com.br",
    password: "admin",
    name: "Ricardo Salgados",
    role: "tenant_admin",
    tenantId: "tenant-rei-dos-salgados",
    status: "active",
    createdAt: Date.now() - 14 * 86400000,
  },
  {
    id: "user-marmitaria",
    email: "contato@marmitariadonamaria.com.br",
    password: "admin",
    name: "Dona Maria",
    role: "tenant_admin",
    tenantId: "tenant-marmitaria-dona-maria",
    status: "active",
    createdAt: Date.now() - 25 * 86400000,
  },
  {
    id: "user-doces",
    email: "contato@doceencanto.com.br",
    password: "admin",
    name: "Beatriz Confeiteira",
    role: "tenant_admin",
    tenantId: "tenant-doce-encanto",
    status: "active",
    createdAt: Date.now() - 16 * 86400000,
  },
  {
    id: "user-churrasco",
    email: "contato@saborebrasa.com.br",
    password: "admin",
    name: "Marcos Gaúcho",
    role: "tenant_admin",
    tenantId: "tenant-sabor-e-brasa",
    status: "active",
    createdAt: Date.now() - 20 * 86400000,
  },
  {
    id: "user-adega",
    email: "contato@adegazerograu.com.br",
    password: "admin",
    name: "Fernando Bebidas",
    role: "tenant_admin",
    tenantId: "tenant-adega-zero-grau",
    status: "active",
    createdAt: Date.now() - 22 * 86400000,
  },
  {
    id: "user-marcelino",
    email: "marcelinosantana23@gmail.com",
    password: "admin",
    name: "Marcelino Santana (MS Preparações)",
    role: "tenant_admin",
    tenantId: "tenant-ms-preparacoes",
    status: "active",
    createdAt: Date.now() - 5 * 86400000,
  },
  ...extraUsers,
];

const initialProducts: Product[] = [
  // ==========================================
  // 1. AÇAITERIA (tenant-acai-do-vale) - Opções ricas de adicionais para demonstração
  // ==========================================
  {
    id: "acai-copo-500",
    tenantId: "tenant-acai-do-vale",
    name: "Copo de Açaí Turbinado 500ml",
    description: "Açaí puro batido na hora, cremoso e refrescante. Monte com camadas fartas de adicionais.",
    price: 22.0,
    image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=600&q=80",
    category: "acai",
    available: true,
    addonGroupIds: ["addon-acai-complementos", "addon-acai-frutas", "addon-acai-cremes"],
    options: [
      { id: "acai-ninho", name: "Leite em Pó Ninho", price: 3.5 },
      { id: "acai-granola", name: "Granola Tradicional Crocante", price: 2.5 },
      { id: "acai-morango", name: "Morango Fresco Picado", price: 4.5 },
      { id: "acai-nutella", name: "Nutella Pura Original", price: 5.0 },
      { id: "acai-leite-cond", name: "Leite Condensado Cremoso", price: 2.5 },
      { id: "acai-banana", name: "Banana Fatiada Fresca", price: 2.0 },
      { id: "acai-pacoca", name: "Paçoca de Amendoim Rolha", price: 2.0 },
      { id: "acai-gotas-choc", name: "Gotas de Chocolate Nobre", price: 3.0 },
    ],
  },
  {
    id: "acai-tigela-700",
    tenantId: "tenant-acai-do-vale",
    name: "Tigela Açaí Especial Supreme 700ml",
    description: "Tigela generosa de açaí artesanal premium. Acompanha camadas perfeitas para você customizar com frutas e cremes.",
    price: 28.9,
    image: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=600&q=80",
    category: "acai",
    available: true,
    addonGroupIds: ["addon-acai-complementos", "addon-acai-frutas", "addon-acai-cremes"],
    options: [
      { id: "acai-creme-ninho", name: "Creme de Ninho Artesanal Trufado", price: 4.5 },
      { id: "acai-creme-avela", name: "Creme de Avelã Nutella", price: 5.0 },
      { id: "acai-ninho-extra", name: "Leite em Pó Ninho Extra", price: 3.0 },
      { id: "acai-granola-castanhas", name: "Granola Especial com Castanhas", price: 3.5 },
      { id: "acai-mix-frutas", name: "Mix de Kiwi, Morango e Banana", price: 5.5 },
      { id: "acai-mel", name: "Mel Silvestre Orgânico", price: 3.0 },
    ],
  },
  {
    id: "acai-copo-300",
    tenantId: "tenant-acai-do-vale",
    name: "Copo de Açaí Cremoso 300ml",
    description: "Açaí tradicional batido com xarope de guaraná na consistência perfeita.",
    price: 16.0,
    image: "https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=600&q=80",
    category: "acai",
    available: true,
    options: [
      { id: "acai-300-ninho", name: "Leite em Pó Ninho", price: 3.0 },
      { id: "acai-300-granola", name: "Granola Crocante", price: 2.5 },
      { id: "acai-300-morango", name: "Morango Fresco", price: 4.0 },
      { id: "acai-300-nutella", name: "Nutella Original", price: 4.5 },
    ],
  },
  {
    id: "acai-vitamina",
    tenantId: "tenant-acai-do-vale",
    name: "Vitamina Energética de Açaí 400ml",
    description: "Açaí batido com banana, leite e guaraná em pó. Pura energia!",
    price: 15.0,
    image: "https://images.unsplash.com/photo-1553530666-ba11a7da3888?auto=format&fit=crop&w=600&q=80",
    category: "bebidas",
    available: true,
    options: [
      { id: "vit-whey", name: "Whey Protein Isolado Baunilha", price: 6.0 },
      { id: "vit-aveia", name: "Aveia em Flocos Finos", price: 2.0 },
      { id: "vit-guarana", name: "Dose Extra de Guaraná em Pó", price: 2.0 },
    ],
  },

  // ==========================================
  // 2. HAMBÚRGUERES (tenant-burger-town) - Opções ricas de adicionais para demonstração
  // ==========================================
  {
    id: "bt-smash-bacon",
    tenantId: "tenant-burger-town",
    name: "Smash Monster Duplo Bacon",
    description: "Dois smash burgers de 90g de puro Angus prensados na chapa bem quente, queijo cheddar derretido, fatias crocantes de bacon e maionese defumada no pão brioche amanteigado.",
    price: 29.9,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    addonGroupIds: ["addon-burger-extras", "addon-burger-molhos"],
    options: [
      { id: "smash-extra-bacon", name: "Bacon Crocante Extra em Tiras", price: 5.0 },
      { id: "smash-extra-cheddar", name: "Cheddar Cremoso Fundido", price: 4.0 },
      { id: "smash-extra-burger", name: "Hambúrguer Smash Extra 90g", price: 7.0 },
      { id: "smash-ovo", name: "Ovo Frito na Chapa Gema Mole", price: 3.0 },
      { id: "smash-cebola-caramel", name: "Cebola Caramelizada na Manteiga", price: 3.0 },
      { id: "smash-maionese-verde", name: "Maionese Verde Artesanal da Casa", price: 2.5 },
      { id: "smash-picles", name: "Picles Artesanal Agridoce", price: 2.0 },
    ],
  },
  {
    id: "bt-xtudo-artesanal",
    tenantId: "tenant-burger-town",
    name: "X-Tudo Artesanal Burger Town",
    description: "Pão brioche selado na manteiga, hambúrguer angus 180g grelhado no fogo, queijo cheddar e prato derretidos, bacon crocante, ovo frito, presunto, alface, tomate e maionese da casa.",
    price: 36.9,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    addonGroupIds: ["addon-burger-extras", "addon-burger-molhos"],
    options: [
      { id: "bt-xtudo-bacon", name: "Bacon Crocante Extra", price: 5.0 },
      { id: "bt-xtudo-cheddar", name: "Cheddar Cremoso Extra", price: 4.0 },
    ],
  },
  {
    id: "bt-cheddar-melt",
    tenantId: "tenant-burger-town",
    name: "Burger Cheddar Melt Supremo",
    description: "Hambúrguer alto de 180g selado no ponto ideal, piscina de queijo cheddar cremoso legítimo e cebola salteada no molho shoyu.",
    price: 34.9,
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    options: [
      { id: "melt-farofa-bacon", name: "Farofa Crocante de Bacon", price: 4.5 },
      { id: "melt-cheddar-duplo", name: "Dose Dupla de Queijo Cheddar", price: 4.5 },
      { id: "melt-aneis-cebola", name: "Anéis de Cebola Empanados Crocantes", price: 5.0 },
      { id: "melt-bbq", name: "Molho Barbecue Defumado", price: 2.5 },
      { id: "melt-sem-cebola", name: "Sem Cebola (Apenas Cheddar)", price: 0.0 },
    ],
  },
  {
    id: "bt-fritas-supreme",
    tenantId: "tenant-burger-town",
    name: "Batata Frita Supreme Cheddar & Bacon",
    description: "Porção generosa de batatas rústicas douradas e crocantes cobertas com queijo cheddar cremoso e cubinhos crocantes de bacon artesanal.",
    price: 24.9,
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80",
    category: "porcoes",
    available: true,
    options: [
      { id: "fritas-dobro-cheddar", name: "Cheddar Cremoso em Dobro", price: 5.0 },
      { id: "fritas-dobro-bacon", name: "Bacon Crocante em Dobro", price: 5.0 },
      { id: "fritas-molho-jalapeno", name: "Molho Jalapeño Suave Picante", price: 3.0 },
    ],
  },
  {
    id: "bt-combo-monster",
    tenantId: "tenant-burger-town",
    name: "Combo Monster Burger + Fritas + Refri",
    description: "Smash Monster Duplo Bacon acompanhado de Batata Frita crocante individual e Refrigerante Lata 350ml geladinho.",
    price: 44.9,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
    category: "combos",
    available: true,
    options: [
      { id: "combo-turbinar-fritas", name: "Turbinar Fritas com Cheddar e Bacon", price: 6.0 },
      { id: "combo-refri-coca", name: "Coca-Cola Original 350ml", price: 0.0 },
      { id: "combo-refri-zero", name: "Coca-Cola Sem Açúcar 350ml", price: 0.0 },
      { id: "combo-refri-guarana", name: "Guaraná Antarctica 350ml", price: 0.0 },
      { id: "combo-extra-bacon", name: "Bacon Extra no Burger", price: 4.5 },
    ],
  },

  // ==========================================
  // 3. PIZZARIA (tenant-pizza-bella)
  // ==========================================
  {
    id: "pb-margherita",
    tenantId: "tenant-pizza-bella",
    name: "Pizza Margherita Especial Forno a Lenha",
    description: "Molho de tomate pelado italiano San Marzano, mozzarella fatiada, rodelas de tomate fresco, manjericão e azeite extravirgem.",
    price: 49.9,
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80",
    category: "pizzas",
    available: true,
    options: [
      { id: "pb-borda-catupiry", name: "Borda Recheada de Catupiry Original", price: 8.0 },
      { id: "pb-borda-cheddar", name: "Borda Recheada de Cheddar Cremoso", price: 8.0 },
      { id: "pb-queijo-extra", name: "Queijo Mozzarella Extra", price: 6.0 },
    ],
  },
  {
    id: "pb-calabresa",
    tenantId: "tenant-pizza-bella",
    name: "Pizza Calabresa Artesanal Defumada",
    description: "Calabresa artesanal defumada fatiada, cebola roxa marinada no azeite e azeitonas pretas chilenas.",
    price: 46.9,
    image: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=600&q=80",
    category: "pizzas",
    available: true,
    options: [
      { id: "pb-cal-borda-catupiry", name: "Borda Recheada de Catupiry", price: 8.0 },
      { id: "pb-cal-cebola-roxa", name: "Cebola Roxa Extra", price: 2.0 },
      { id: "pb-cal-queijo", name: "Camada de Queijo Mozzarella", price: 6.0 },
    ],
  },

  // ==========================================
  // 4. SORVETERIA (tenant-sorvetes-imperial)
  // ==========================================
  {
    id: "si-taca-imperial",
    tenantId: "tenant-sorvetes-imperial",
    name: "Taça Supreme Gelato & Frutas Vermelhas",
    description: "Três bolas de gelato artesanal italiano, calda artesanal de amora e framboesa, chantilly fresco e castanhas caramelizadas.",
    price: 26.0,
    image: "https://images.unsplash.com/photo-1501443762994-82bd5dace89a?auto=format&fit=crop&w=600&q=80",
    category: "sobremesas",
    available: true,
    options: [
      { id: "si-calda-choc", name: "Calda Quente de Chocolate Belga", price: 4.0 },
      { id: "si-chantilly-extra", name: "Chantilly Fresco Extra", price: 3.0 },
      { id: "si-castanhas", name: "Castanhas de Caju Picadas", price: 3.0 },
    ],
  },
  {
    id: "si-pote-1l",
    tenantId: "tenant-sorvetes-imperial",
    name: "Pote Térmico 1 Litro Gelato Artesanal",
    description: "Pote selado e embalado em bolsa térmica com gelo seco. Escolha até 2 sabores artesanais.",
    price: 42.0,
    image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=600&q=80",
    category: "sobremesas",
    available: true,
    options: [
      { id: "si-sabor-pistache", name: "Pistache Puro da Sicília", price: 4.0 },
      { id: "si-sabor-ninho-nutella", name: "Ninho Trufado com Nutella", price: 0.0 },
      { id: "si-sabor-morango", name: "Morango Silvestre Cremoso", price: 0.0 },
    ],
  },

  // ==========================================
  // 5. JAPONESA (tenant-sushi-ya)
  // ==========================================
  {
    id: "sy-combo-prime",
    tenantId: "tenant-sushi-ya",
    name: "Combo Tokyo Prime 24 Peças",
    description: "8 sashimis de salmão fresco, 4 uramakis philadelphia, 4 jows salmão maçaricado com cream cheese, 4 niguiris e 4 hot rolls crocantes.",
    price: 68.9,
    image: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=600&q=80",
    category: "japonesa",
    available: true,
    options: [
      { id: "sy-molho-tare", name: "Molho Tarê Artesanal Extra", price: 3.0 },
      { id: "sy-gengibre-wasabi", name: "Porção Extra Gengibre & Wasabi", price: 3.0 },
      { id: "sy-cream-cheese", name: "Cream Cheese Philadelphia Extra", price: 4.0 },
    ],
  },
  {
    id: "sy-temaki-salmao",
    tenantId: "tenant-sushi-ya",
    name: "Temaki Especial Salmão Completo",
    description: "Alga nori crocante, arroz japonês temperado, cubos generosos de salmão fresco, cream cheese philadelphia e cebolinha picada.",
    price: 28.9,
    image: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=600&q=80",
    category: "japonesa",
    available: true,
    options: [
      { id: "sy-temaki-crocante", name: "Com Farofa de Empanado Panko Crocante", price: 2.5 },
      { id: "sy-temaki-macaricado", name: "Salmão Maçaricado com Azeite Trufado", price: 3.5 },
    ],
  },

  // ==========================================
  // 6. SALGADOS (tenant-rei-dos-salgados)
  // ==========================================
  {
    id: "rs-cento-festa",
    tenantId: "tenant-rei-dos-salgados",
    name: "Cento de Mini Salgados Fritos para Festa (100 un)",
    description: "Fritos na hora! 30 coxinhas de frango, 25 bolinhas de queijo, 25 kibes com carne e 20 risoles de presunto e queijo.",
    price: 75.0,
    image: "https://images.unsplash.com/photo-1628294895950-9805252327bc?auto=format&fit=crop&w=600&q=80",
    category: "salgados",
    available: true,
    options: [
      { id: "rs-maionese-alho", name: "Pote de Maionese de Alho da Casa 150ml", price: 5.0 },
      { id: "rs-molho-pimenta", name: "Molho de Pimenta Artesanal Defumada", price: 4.0 },
    ],
  },
  {
    id: "rs-coxinha-gigante",
    tenantId: "tenant-rei-dos-salgados",
    name: "Coxinha de Frango com Requeijão Cremoso (220g)",
    description: "Massa fininha e crocante de batata, recheada de ponta a ponta com frango desfiado temperado e requeijão cremoso.",
    price: 10.0,
    image: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=600&q=80",
    category: "salgados",
    available: true,
    options: [
      { id: "rs-queijo-requeijao", name: "Recheio Duplo de Requeijão", price: 3.0 },
    ],
  },

  // ==========================================
  // 7. MARMITARIA (tenant-marmitaria-dona-maria)
  // ==========================================
  {
    id: "md-marmita-executiva",
    tenantId: "tenant-marmitaria-dona-maria",
    name: "Marmitex Executiva Bife Acebolado com Fritas",
    description: "Arroz branco soltinho, feijão carioquinha caseiro temperado com alho e louro, bife bovino macio acebolado, batatas fritas crocantes e saladinha fresca.",
    price: 24.9,
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=600&q=80",
    category: "marmitaria",
    available: true,
    options: [
      { id: "md-ovo-frito", name: "Ovo Frito na Hora com Gema Mole", price: 3.0 },
      { id: "md-farofa-bacon", name: "Porção de Farofa Caseira de Bacon", price: 3.5 },
      { id: "md-feijao-extra", name: "Concha Extra de Feijão Temperado", price: 3.0 },
      { id: "md-vinagrete", name: "Vinagrete Especial com Cheiro Verde", price: 2.5 },
    ],
  },
  {
    id: "md-parmegiana",
    tenantId: "tenant-marmitaria-dona-maria",
    name: "Marmitex Filé de Frango à Parmegiana",
    description: "Filé de frango empanado crocante coberto com molho de tomate caseiro e queijo mozzarella gratinado. Acompanha arroz e purê de batatas cremoso.",
    price: 27.9,
    image: "https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80",
    category: "marmitaria",
    available: true,
    options: [
      { id: "md-pure-extra", name: "Purê de Batata Cremoso Extra", price: 4.0 },
      { id: "md-queijo-gratinado", name: "Queijo Mozzarella Gratinado Duplo", price: 4.5 },
    ],
  },

  // ==========================================
  // 8. DOCES (tenant-doce-encanto)
  // ==========================================
  {
    id: "de-bolo-vulcao",
    tenantId: "tenant-doce-encanto",
    name: "Fatia de Bolo Vulcão Ninho com Nutella",
    description: "Massa de chocolate fofinha e úmida, com cascata farta de brigadeiro de Leite Ninho e cobertura generosa de Nutella pura.",
    price: 18.9,
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=600&q=80",
    category: "docerias",
    available: true,
    options: [
      { id: "de-morangos-frescos", name: "Morangos Frescos Fatiados", price: 4.0 },
      { id: "de-brigadeiro-colher", name: "Potinho de Brigadeiro Belga de Colher", price: 5.0 },
      { id: "de-raspas-choc", name: "Raspas de Chocolate Nobre", price: 2.5 },
    ],
  },
  {
    id: "de-copo-felicidade",
    tenantId: "tenant-doce-encanto",
    name: "Copo da Felicidade Morango do Amor 350ml",
    description: "Camadas perfeitas de brownie úmido de chocolate belga, brigadeiro branco aveludado, morangos frescos e ganache de chocolate meio amargo.",
    price: 21.0,
    image: "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=600&q=80",
    category: "docerias",
    available: true,
    options: [
      { id: "de-nutella-copo", name: "Dose Extra de Nutella", price: 4.0 },
      { id: "de-ninho-polvilhado", name: "Leite Ninho Polvilhado", price: 2.0 },
    ],
  },

  // ==========================================
  // 9. CHURRASCARIA (tenant-sabor-e-brasa)
  // ==========================================
  {
    id: "sb-picanha",
    tenantId: "tenant-sabor-e-brasa",
    name: "Picanha Nobre Fatiada na Brasa (500g)",
    description: "Picanha nobre grelhada na churrasqueira a carvão no ponto perfeito. Acompanha arroz branco, farofa de ovos crocante, vinagrete e mandioca na manteiga de garrafa.",
    price: 64.9,
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80",
    category: "churrascaria",
    available: true,
    options: [
      { id: "sb-queijo-coalho", name: "Espeto de Queijo Coalho com Melado", price: 12.0 },
      { id: "sb-pao-alho", name: "Pão de Alho Recheado Crocante", price: 8.0 },
      { id: "sb-mandioca-frita", name: "Porção Extra de Mandioca na Manteiga", price: 9.0 },
    ],
  },
  {
    id: "sb-costela",
    tenantId: "tenant-sabor-e-brasa",
    name: "Costela Bovina Assada no Bafo 12h (600g)",
    description: "Costela bovina desmanchando no osso, defumada e marinada com especiarias. Acompanha farofa crocante e molho chimichurri da casa.",
    price: 58.0,
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80",
    category: "churrascaria",
    available: true,
    options: [
      { id: "sb-chimichurri", name: "Molho Chimichurri Artesanal Extra", price: 3.5 },
      { id: "sb-farofa-bacon", name: "Farofa de Bacon e Cebola", price: 4.0 },
    ],
  },

  // ==========================================
  // 10. BEBIDAS (tenant-adega-zero-grau)
  // ==========================================
  {
    id: "zg-pack-heineken",
    tenantId: "tenant-adega-zero-grau",
    name: "Pack Cerveja Heineken Lata 350ml (6 Unidades Geladas)",
    description: "Cerveja Heineken puro malte na temperatura ideal para consumo imediato, latas super geladas.",
    price: 38.9,
    image: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=600&q=80",
    category: "bebidas",
    available: true,
    options: [
      { id: "zg-gelo-5kg", name: "Saco de Gelo Filtrado em Cubos 5kg", price: 10.0 },
      { id: "zg-copos-descartaveis", name: "Pacote com 10 Copos Descartáveis 500ml", price: 5.0 },
      { id: "zg-limao", name: "Limões Taiti Frescos Fatiados", price: 3.0 },
    ],
  },
  {
    id: "zg-combo-gin",
    tenantId: "tenant-adega-zero-grau",
    name: "Combo Gin Tanqueray 750ml + 4 Tônicas Schweppes",
    description: "Garrafa de Gin importado Tanqueray London Dry 750ml com 4 latas de água tônica gelada.",
    price: 139.9,
    image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=600&q=80",
    category: "bebidas",
    available: true,
    options: [
      { id: "zg-especiarias", name: "Kit de Especiarias para Gin (Zimbro, Hibisco, Canela)", price: 12.0 },
      { id: "zg-taca-acrilico", name: "Taça de Gin Acrílico Preta Personalizada", price: 9.0 },
    ],
  },
  {
    id: "zg-energetico-redbull",
    tenantId: "tenant-adega-zero-grau",
    name: "Energético Red Bull Energy Drink 250ml Gelado",
    description: "Red Bull Energy Drink original super geladinho na lata.",
    price: 11.0,
    image: "https://images.unsplash.com/photo-1622543925917-763c34d1a86e?auto=format&fit=crop&w=600&q=80",
    category: "bebidas",
    available: true,
    options: [
      { id: "zg-redbull-sugarfree", name: "Trocar por Versão Sem Açúcar (Sugarfree)", price: 0.0 },
    ],
  },

  // ==========================================
  // 11. MS PREPARAÇÕES (tenant-ms-preparacoes)
  // ==========================================
  {
    id: "msp-1",
    tenantId: "tenant-ms-preparacoes",
    name: "X-Salada Especial MS",
    description: "Pão brioche selado na manteiga, hambúrguer artesanal 160g, queijo prato derretido, alface americana, tomate fresco e maionese verde da casa.",
    price: 26.9,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    options: [
      { id: "extra-bacon", name: "Bacon crocante extra em tiras", price: 4.5 },
      { id: "extra-queijo", name: "Queijo duplo derretido", price: 4.0 },
      { id: "extra-cheddar", name: "Cheddar cremoso fundido", price: 4.0 },
      { id: "molho-especial", name: "Molho especial extra da casa", price: 2.5 },
    ],
  },
  {
    id: "msp-2",
    tenantId: "tenant-ms-preparacoes",
    name: "Smash Burger Duplo Bacon MS",
    description: "Dois smash burgers de 90g ultra crocantes, muito queijo cheddar cremoso derretido, fatias de bacon e cebola caramelizada.",
    price: 31.9,
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    options: [
      { id: "extra-hamburguer", name: "Hambúrguer extra smash 90g", price: 7.0 },
      { id: "extra-cheddar", name: "Cheddar cremoso extra", price: 3.5 },
      { id: "extra-bacon-msp", name: "Bacon crocante extra", price: 4.5 },
    ],
  },
  {
    id: "msp-3",
    tenantId: "tenant-ms-preparacoes",
    name: "X-Tudo Campeão MS",
    description: "O mais completo: pão artesanal, hambúrguer 180g, presunto, queijo, ovo frito na chapa, bacon, alface, tomate, milho e batata palha.",
    price: 34.9,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
    category: "lanches",
    available: true,
    options: [
      { id: "xtudo-cheddar", name: "Adicionar Cheddar Cremoso", price: 4.0 },
      { id: "xtudo-bacon", name: "Dobro de Bacon Crocante", price: 5.0 },
    ],
  },
  {
    id: "msp-4",
    tenantId: "tenant-ms-preparacoes",
    name: "Batata Frita Crocante Rústica",
    description: "Porção de batatas selecionadas com tempero secreto da casa e alecrim, servidas com maionese artesanal.",
    price: 18.0,
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80",
    category: "porcoes",
    available: true,
    options: [
      { id: "cheddar-bacon", name: "Com Cheddar e Farofa de Bacon", price: 6.0 },
    ],
  },
  {
    id: "msp-5",
    tenantId: "tenant-ms-preparacoes",
    name: "Refrigerante Gelado Lata 350ml",
    description: "Coca-Cola, Guaraná Antarctica ou Sprite super gelados.",
    price: 6.0,
    image: "https://images.pexels.com/photos/50593/coca-cola-cold-drink-soft-drink-coke-50593.jpeg?auto=compress&cs=tinysrgb&w=600",
    category: "bebidas",
    available: true,
    options: [
      { id: "coca-original", name: "Coca-Cola Original", price: 0 },
      { id: "coca-zero", name: "Coca-Cola Zero", price: 0 },
      { id: "guarana", name: "Guaraná Antarctica", price: 0 },
    ],
  },
  ...extraProducts,
].map((p, idx) => ({
  ...p,
  position: p.position ?? p.ordem ?? idx,
  ordem: p.position ?? p.ordem ?? idx,
}));

const initialOrders: Order[] = [];

const initialCustomers: Customer[] = [
  {
    id: "cust-mariana-silva",
    tenantId: "tenant-burger-town",
    name: "Mariana Silva",
    phone: "(11) 98765-4321",
    street: "Rua Augusta",
    number: "1200",
    district: "Consolação",
    complement: "Apto 42",
    reference: "Próximo ao metrô",
    totalOrders: 1,
    totalSpent: 60.0,
    lastOrderAt: Date.now() - 15 * 60000,
    createdAt: Date.now() - 30 * 86400000,
    updatedAt: Date.now() - 15 * 60000,
  },
  {
    id: "cust-rodrigo-costa",
    tenantId: "tenant-burger-town",
    name: "Rodrigo Costa",
    phone: "(11) 97123-8899",
    totalOrders: 1,
    totalSpent: 32.0,
    lastOrderAt: Date.now() - 40 * 60000,
    createdAt: Date.now() - 20 * 86400000,
    updatedAt: Date.now() - 40 * 60000,
  },
  {
    id: "cust-fernanda-lima",
    tenantId: "tenant-pizza-bella",
    name: "Fernanda Lima",
    phone: "(11) 99112-2334",
    street: "Alameda Santos",
    number: "850",
    district: "Cerqueira César",
    complement: "Bloco B - 110",
    reference: "Portaria 24h",
    totalOrders: 1,
    totalSpent: 61.5,
    lastOrderAt: Date.now() - 8 * 60000,
    createdAt: Date.now() - 10 * 86400000,
    updatedAt: Date.now() - 8 * 60000,
  },
];

export const defaultCategories: Category[] = [
  { id: "lanches", name: "Lanches", icon: "🍔", order: 1, order_index: 1 },
  { id: "hotdogs", name: "Hot Dogs", icon: "🌭", order: 2, order_index: 2 },
  { id: "pizzas", name: "Pizzas", icon: "🍕", order: 3, order_index: 3 },
  { id: "acai", name: "Açaí e Sorvetes", icon: "🍧", order: 4, order_index: 4 },
  { id: "bebidas", name: "Bebidas", icon: "🥤", order: 5, order_index: 5 },
  { id: "combos", name: "Combos", icon: "🍟", order: 6, order_index: 6 },
  { id: "porcoes", name: "Porções", icon: "🍗", order: 7, order_index: 7 },
  { id: "sobremesas", name: "Sobremesas", icon: "🍰", order: 8, order_index: 8 },
  { id: "japonesa", name: "Japonesa", icon: "🍣", order: 9, order_index: 9 },
  { id: "salgados", name: "Salgados", icon: "🥟", order: 10, order_index: 10 },
  { id: "marmitaria", name: "Marmitaria", icon: "🍱", order: 11, order_index: 11 },
  { id: "docerias", name: "Doces", icon: "🍰", order: 12, order_index: 12 },
  { id: "churrascaria", name: "Churrascaria", icon: "🥩", order: 13, order_index: 13 },
];

export const defaultEstablishmentCategories: EstablishmentCategory[] = [
  { id: "todos", name: "Todos", icon: "🍽️", order: 0, order_index: 0, active: true },
  { id: "acaiterias", name: "Açaíterias", icon: "🍧", order: 1, order_index: 1, active: true },
  { id: "lanchonetes", name: "Hambúrgueres", icon: "🍔", order: 2, order_index: 2, active: true },
  { id: "pizzarias", name: "Pizzarias", icon: "🍕", order: 3, order_index: 3, active: true },
  { id: "massas", name: "Massas", icon: "🍝", order: 4, order_index: 4, active: true },
  { id: "japonesa", name: "Japonesa", icon: "🍣", order: 5, order_index: 5, active: true },
  { id: "hotdog", name: "Hot Dog", icon: "🌭", order: 6, order_index: 6, active: true },
  { id: "mexicana", name: "Mexicana", icon: "🌮", order: 7, order_index: 7, active: true },
  { id: "marmitaria", name: "Marmitaria", icon: "🍱", order: 8, order_index: 8, active: true },
  { id: "mineira", name: "Mineira", icon: "🍲", order: 9, order_index: 9, active: true },
  { id: "churrascaria", name: "Churrascaria", icon: "🥩", order: 10, order_index: 10, active: true },
  { id: "frango", name: "Frango Frito", icon: "🍗", order: 11, order_index: 11, active: true },
  { id: "salgados", name: "Salgados", icon: "🥟", order: 12, order_index: 12, active: true },
  { id: "pastelarias", name: "Pastelarias", icon: "🥟", order: 13, order_index: 13, active: true },
  { id: "crepes", name: "Crepes", icon: "🥞", order: 14, order_index: 14, active: true },
  { id: "padarias", name: "Padarias", icon: "🥖", order: 15, order_index: 15, active: true },
  { id: "poke", name: "Poke & Fit", icon: "🥗", order: 16, order_index: 16, active: true },
  { id: "sorveteiras", name: "Sorveterias", icon: "🍨", order: 17, order_index: 17, active: true },
  { id: "docerias", name: "Doces", icon: "🍰", order: 18, order_index: 18, active: true },
  { id: "distribuidoras", name: "Bebidas", icon: "🍺", order: 19, order_index: 19, active: true },
];

export const defaultPlatformSettings: PlatformSettings = {
  logoUrl: "",
  bannerUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1400&q=80",
  heroTitle: "Top Food - O Portal do Delivery",
  heroSubtitle: "O seu portal de delivery para as melhores lojas e restaurantes da sua cidade.",
  primaryColor: "#E63946",
  geminiApiKey: typeof process !== "undefined" && process?.env?.GEMINI_API_KEY ? process.env.GEMINI_API_KEY : "",
  adminPixKey: "topfood.financeiro@pix.com",
  adminPixType: "email",
  adminWhatsapp: "5511999999999",
  partnerWhatsapp: "5511999999999",
  defaultMonthlyFee: 49.9,
  updatedAt: Date.now(),
};

// Seed de stories ativos com imagens chamativas para todas as 10 lojas (+ MS Preparações)
export const initialStories: StoreStory[] = [
  // 1. Açaiteria
  {
    id: "story-acai-1",
    tenantId: "tenant-acai-do-vale",
    mediaUrl: "https://images.unsplash.com/photo-1590301157890-4810ed352733?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍧 Copo de 500ml montado com muito Ninho e Nutella! Peça pelo app.",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-acai-2",
    tenantId: "tenant-acai-do-vale",
    mediaUrl: "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🫐 Açaí puro batido cremoso com frutas frescas do dia!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 2. Hambúrgueres
  {
    id: "story-burger-1",
    tenantId: "tenant-burger-town",
    mediaUrl: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍔 Smash Burger duplo com cheddar derretido e tiras crocantes de bacon!",
    createdAt: Date.now() - 3 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-burger-2",
    tenantId: "tenant-burger-town",
    mediaUrl: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍟 Batata frita rústica crocante com cheddar cremoso e farofa de bacon.",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 3. Pizzaria
  {
    id: "story-pizza-1",
    tenantId: "tenant-pizza-bella",
    mediaUrl: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍕 Saindo do forno a lenha agorinha! Massa de fermentação natural de 48h.",
    createdAt: Date.now() - 4 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-pizza-2",
    tenantId: "tenant-pizza-bella",
    mediaUrl: "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🔥 Borda recheada de Catupiry original grátis hoje!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 4. Sorveteria
  {
    id: "story-sorvete-1",
    tenantId: "tenant-sorvetes-imperial",
    mediaUrl: "https://images.unsplash.com/photo-1501443762994-82bd5dace89a?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍨 Gelatos italianos artesanais super cremosos! Entrega com embalagem térmica.",
    createdAt: Date.now() - 5 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-sorvete-2",
    tenantId: "tenant-sorvetes-imperial",
    mediaUrl: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍨 Pote de 1 Litro com Pistache Siciliano e Ninho Trufado! Peça para a sobremesa.",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 5. Japonesa
  {
    id: "story-sushi-1",
    tenantId: "tenant-sushi-ya",
    mediaUrl: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍣 Combo Tokyo Prime: salmão maçaricado, hot roll e sashimi fresco!",
    createdAt: Date.now() - 3 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-sushi-2",
    tenantId: "tenant-sushi-ya",
    mediaUrl: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🥢 Temaki crocante com cubos generosos de salmão e cream cheese!",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 6. Salgados
  {
    id: "story-salgado-1",
    tenantId: "tenant-rei-dos-salgados",
    mediaUrl: "https://images.unsplash.com/photo-1628294895950-9805252327bc?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🥟 Coxinhas sequinhas e crocantes recheadas de frango com requeijão!",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-salgado-2",
    tenantId: "tenant-rei-dos-salgados",
    mediaUrl: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🥟 Cento de salgadinhos fritos na hora para a sua festa ou reunião em família!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 7. Marmitaria
  {
    id: "story-marmita-1",
    tenantId: "tenant-marmitaria-dona-maria",
    mediaUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍱 Marmitex executiva: arroz soltinho, feijão caseiro, bife acebolado e fritas!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-marmita-2",
    tenantId: "tenant-marmitaria-dona-maria",
    mediaUrl: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍲 Feijoada completa da Dona Maria com torresmo crocante e couve fresquinha!",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 8. Doces
  {
    id: "story-doce-1",
    tenantId: "tenant-doce-encanto",
    mediaUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍰 Bolo Vulcão Ninho com Nutella e fatias gourmet irresistíveis!",
    createdAt: Date.now() - 4 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-doce-2",
    tenantId: "tenant-doce-encanto",
    mediaUrl: "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍫 Caixa com brigadeiros gourmet belgas enrolados na hora para presente!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 9. Churrascaria
  {
    id: "story-churrasco-1",
    tenantId: "tenant-sabor-e-brasa",
    mediaUrl: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🥩 Picanha na brasa suculenta ao ponto com farofa especial crocante!",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-churrasco-2",
    tenantId: "tenant-sabor-e-brasa",
    mediaUrl: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🔥 Espetinhos artesanais na brasa de carvão: picanha, medalhão com bacon e queijo coalho!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // 10. Bebidas
  {
    id: "story-bebida-1",
    tenantId: "tenant-adega-zero-grau",
    mediaUrl: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍺 Cervejas estupidamente geladas prontas para entrega expressa em até 30 min!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-bebida-2",
    tenantId: "tenant-adega-zero-grau",
    mediaUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍷 Vinhos selecionados, gins premium e saco de gelo filtrado na sua porta!",
    createdAt: Date.now() - 3 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  // MS Preparações
  {
    id: "story-ms-1",
    tenantId: "tenant-ms-preparacoes",
    mediaUrl: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍔 Lanches artesanais preparados na hora com ingredientes frescos!",
    createdAt: Date.now() - 2 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  {
    id: "story-ms-2",
    tenantId: "tenant-ms-preparacoes",
    mediaUrl: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1080&q=80",
    mediaType: "image",
    caption: "🍟 Porções generosas de batata frita e iscas de frango empanadas crocantes!",
    createdAt: Date.now() - 1 * 3600000,
    expiresAt: Date.now() + 48 * 3600000,
  },
  ...extraStories,
];

export const initialAddonGroups: AddonGroup[] = [
  // 1. Açaiteria (tenant-acai-do-vale)
  {
    id: "addon-acai-complementos",
    tenantId: "tenant-acai-do-vale",
    name: "Complementos Tradicionais",
    description: "Escolha seus acompanhamentos secos favoritos",
    minSelection: 0,
    maxSelection: 0,
    required: false,
    items: [
      { id: "item-ninho", name: "Leite em Pó Ninho", price: 3.5, available: true },
      { id: "item-granola", name: "Granola Tradicional Crocante", price: 2.5, available: true },
      { id: "item-pacoca", name: "Paçoca de Amendoim Rolha", price: 2.0, available: true },
      { id: "item-gotas", name: "Gotas de Chocolate Nobre", price: 3.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 10 * 86400000,
  },
  {
    id: "addon-acai-frutas",
    tenantId: "tenant-acai-do-vale",
    name: "Frutas Frescas",
    description: "Frutas selecionadas do dia picadas na hora",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-morango", name: "Morango Fresco Picado", price: 4.5, available: true },
      { id: "item-banana", name: "Banana Fatiada Fresca", price: 2.0, available: true },
      { id: "item-kiwi", name: "Kiwi Fatiado", price: 4.0, available: true },
    ],
    position: 2,
    createdAt: Date.now() - 10 * 86400000,
  },
  {
    id: "addon-acai-cremes",
    tenantId: "tenant-acai-do-vale",
    name: "Cremes e Coberturas",
    description: "Cremes artesanais e caldas generosas",
    minSelection: 0,
    maxSelection: 2,
    required: false,
    items: [
      { id: "item-nutella", name: "Nutella Pura Original", price: 5.0, available: true },
      { id: "item-leite-cond", name: "Leite Condensado Cremoso", price: 2.5, available: true },
      { id: "item-creme-ninho", name: "Creme de Ninho Trufado", price: 4.5, available: true },
      { id: "item-mel", name: "Mel Silvestre Orgânico", price: 3.0, available: true },
    ],
    position: 3,
    createdAt: Date.now() - 10 * 86400000,
  },

  // 2. Burger Town (tenant-burger-town)
  {
    id: "addon-burger-extras",
    tenantId: "tenant-burger-town",
    name: "Adicionais de Lanches",
    description: "Turbine seu burger com ingredientes extras faturados",
    minSelection: 0,
    maxSelection: 5,
    required: false,
    items: [
      { id: "item-bacon", name: "Bacon Crocante em Fatias", price: 4.0, available: true },
      { id: "item-cheddar", name: "Queijo Cheddar Cremoso", price: 3.5, available: true },
      { id: "item-hamburguer", name: "Hambúrguer Extra Artesanal 120g", price: 7.0, available: true },
      { id: "item-ovo", name: "Ovo Frito na Chapa", price: 2.5, available: true },
      { id: "item-cebola-caram", name: "Cebola Caramelizada Especial", price: 3.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 20 * 86400000,
  },
  {
    id: "addon-burger-molhos",
    tenantId: "tenant-burger-town",
    name: "Molhos Especiais da Casa",
    description: "Potes de molho artesanal de 50ml",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-maio-alho", name: "Maionese Verde Temperada com Alho", price: 3.0, available: true },
      { id: "item-barbecue", name: "Molho Barbecue Defumado", price: 2.5, available: true },
      { id: "item-molho-especial", name: "Molho Especial Burger Town", price: 3.0, available: true },
    ],
    position: 2,
    createdAt: Date.now() - 20 * 86400000,
  },

  // 3. Bella Pizza (tenant-pizza-bella)
  {
    id: "addon-pizza-bordas",
    tenantId: "tenant-pizza-bella",
    name: "Bordas Recheadas Especiais",
    description: "Escolha o recheio para a borda da sua pizza",
    minSelection: 0,
    maxSelection: 1,
    required: false,
    items: [
      { id: "item-borda-catupiry", name: "Borda Vulcão de Catupiry Original", price: 8.0, available: true },
      { id: "item-borda-cheddar", name: "Borda de Cheddar Cremoso", price: 8.0, available: true },
      { id: "item-borda-chocolate", name: "Borda de Chocolate ao Leite Nobre", price: 9.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 15 * 86400000,
  },
  {
    id: "addon-pizza-ingredientes",
    tenantId: "tenant-pizza-bella",
    name: "Ingredientes Extras na Pizza",
    description: "Turbine sua pizza com mais recheio",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-extra-bacon", name: "Bacon Crocante Fatiado", price: 5.0, available: true },
      { id: "item-extra-alho", name: "Alho Dourado Crocante", price: 3.0, available: true },
      { id: "item-extra-azeitonas", name: "Azeitonas Pretas Chilenas", price: 4.0, available: true },
      { id: "item-extra-parmesao", name: "Parmesão Ralado Farto", price: 5.0, available: true },
    ],
    position: 2,
    createdAt: Date.now() - 15 * 86400000,
  },

  // 4. Gelateria Imperial (tenant-sorvetes-imperial)
  {
    id: "addon-gelato-caldas",
    tenantId: "tenant-sorvetes-imperial",
    name: "Caldas Especiais & Fudge",
    description: "Caldas artesanais quentes ou frias para o gelato",
    minSelection: 0,
    maxSelection: 2,
    required: false,
    items: [
      { id: "item-calda-fudge", name: "Calda Quente de Fudge de Chocolate Belga", price: 5.0, available: true },
      { id: "item-calda-morango", name: "Calda Caseira de Morangos com Pedaços", price: 4.5, available: true },
      { id: "item-calda-caramelo", name: "Calda de Caramelo Salgado Gourmet", price: 4.5, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 12 * 86400000,
  },
  {
    id: "addon-gelato-toppings",
    tenantId: "tenant-sorvetes-imperial",
    name: "Toppings & Castanhas Crocantes",
    description: "Complementos para adicionar textura ao gelato",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-castanha-caju", name: "Castanha de Caju Crocante Tostada", price: 3.5, available: true },
      { id: "item-waffle-chips", name: "Casquinha Waffle Triturada", price: 2.5, available: true },
      { id: "item-raspas-chocolate", name: "Raspas de Chocolate Meio Amargo", price: 3.5, available: true },
    ],
    position: 2,
    createdAt: Date.now() - 12 * 86400000,
  },

  // 5. Tokyo Sushi (tenant-sushi-ya)
  {
    id: "addon-sushi-molhos",
    tenantId: "tenant-sushi-ya",
    name: "Molhos & Condimentos Especiais",
    description: "Molhos artesanais extras para seu combinado",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-tare-extra", name: "Molho Tarê Artesanal 50ml", price: 4.0, available: true },
      { id: "item-gengibre-extra", name: "Gengibre em Conserva Artesanal", price: 3.5, available: true },
      { id: "item-wasabi-fresco", name: "Wasabi Fresco Extra", price: 3.0, available: true },
      { id: "item-geleiadepimenta", name: "Geleia de Pimenta Agridoce", price: 4.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 18 * 86400000,
  },
  {
    id: "addon-sushi-extras",
    tenantId: "tenant-sushi-ya",
    name: "Extras para Temakis & Rolinhos",
    description: "Turbine suas peças japonesas",
    minSelection: 0,
    maxSelection: 2,
    required: false,
    items: [
      { id: "item-extra-creamcheese", name: "Dobro de Cream Cheese Philadelphia", price: 4.5, available: true },
      { id: "item-extra-couve", name: "Crispy de Couve Frita Crocante", price: 3.0, available: true },
      { id: "item-extra-salmao", name: "Porção Extra de Cubos de Salmão", price: 8.0, available: true },
    ],
    position: 2,
    createdAt: Date.now() - 18 * 86400000,
  },

  // 6. Rei dos Salgados (tenant-rei-dos-salgados)
  {
    id: "addon-salgados-molhos",
    tenantId: "tenant-rei-dos-salgados",
    name: "Molhos da Casa para Salgados",
    description: "Potes de 50ml para mergulhar seus salgadinhos",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-pimenta-casa", name: "Molho de Pimenta Especial da Casa", price: 2.5, available: true },
      { id: "item-maio-verde-salg", name: "Maionese Verde Temperada com Ervas", price: 3.0, available: true },
      { id: "item-molho-rose", name: "Molho Rosé Especial", price: 2.5, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 14 * 86400000,
  },

  // 7. Marmitaria Dona Maria (tenant-marmitaria-dona-maria)
  {
    id: "addon-marmita-extras",
    tenantId: "tenant-marmitaria-dona-maria",
    name: "Complementos Caseiros para a Marmita",
    description: "Adicione mais itens ao seu almoço",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-ovo-frito", name: "Ovo Caipira Frito na Hora", price: 2.5, available: true },
      { id: "item-torresmo-porcao", name: "Porção de Torresmo Pururuca Crocante", price: 6.0, available: true },
      { id: "item-farofa-alho", name: "Farofa de Alho e Manteiga", price: 3.5, available: true },
      { id: "item-feijao-tropeiro", name: "Concha Extra de Feijão Tropeiro", price: 5.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 25 * 86400000,
  },

  // 8. Doce Encanto (tenant-doce-encanto)
  {
    id: "addon-doce-toppings",
    tenantId: "tenant-doce-encanto",
    name: "Toppings & Embalagens Especiais",
    description: "Personalize sua sobremesa ou bolo",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-morangos-frescos", name: "Morangos Frescos Fatiados", price: 4.5, available: true },
      { id: "item-granulado-belga", name: "Granulado Belga Callebaut", price: 4.0, available: true },
      { id: "item-sacola-presente", name: "Sacola Decorativa para Presente com Laço", price: 6.0, available: true },
      { id: "item-vela-aniversario", name: "Vela de Aniversário Especial", price: 3.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 16 * 86400000,
  },

  // 9. Sabor & Brasa (tenant-sabor-e-brasa)
  {
    id: "addon-brasa-guarnicoes",
    tenantId: "tenant-sabor-e-brasa",
    name: "Guarnições & Acompanhamentos de Churrasco",
    description: "Complementos saborosos para acompanhar suas carnes",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-farofa-bacon-brasa", name: "Farofa Crocante de Bacon com Alho", price: 4.5, available: true },
      { id: "item-vinagrete-brasa", name: "Vinagrete Especial com Ervas Finas", price: 3.5, available: true },
      { id: "item-queijo-coalho-extra", name: "Espeto de Queijo Coalho Dourado", price: 9.0, available: true },
      { id: "item-pao-alho-brasa", name: "Pão de Alho Especial Recheado", price: 7.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 20 * 86400000,
  },

  // 10. Adega Zero Grau (tenant-adega-zero-grau)
  {
    id: "addon-adega-conveniencia",
    tenantId: "tenant-adega-zero-grau",
    name: "Conveniência, Gelo & Petiscos",
    description: "Itens essenciais para o seu evento",
    minSelection: 0,
    maxSelection: 3,
    required: false,
    items: [
      { id: "item-gelo-5kg", name: "Saco de Gelo Filtrado em Cubos 5kg", price: 12.0, available: true },
      { id: "item-copos-descartaveis", name: "Pacote com 10 Copos Térmicos 500ml", price: 6.0, available: true },
      { id: "item-limoes-fatiados", name: "Potinho com Limões Fatiados Frescos", price: 3.5, available: true },
      { id: "item-amendoim-petisco", name: "Amendoim Japonês Crocante 150g", price: 6.0, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 22 * 86400000,
  },

  // 11. MS Preparações (tenant-ms-preparacoes)
  {
    id: "addon-ms-ingredientes",
    tenantId: "tenant-ms-preparacoes",
    name: "Adicionais Especiais",
    description: "Adicione mais sabor ao seu pedido",
    minSelection: 0,
    maxSelection: 4,
    required: false,
    items: [
      { id: "item-ms-bacon", name: "Bacon em Tiras Crocantes", price: 4.0, available: true },
      { id: "item-ms-queijo", name: "Queijo Prato Duplo", price: 3.5, available: true },
      { id: "item-ms-catupiry", name: "Catupiry Original", price: 4.0, available: true },
      { id: "item-ms-ovo", name: "Ovo Frito Caipira", price: 2.5, available: true },
    ],
    position: 1,
    createdAt: Date.now() - 5 * 86400000,
  },
  ...extraAddonGroups,
];

export interface OrderItemRecord {
  id: string;
  orderId: string;
  tenantId: string;
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  optionsJson?: string;
  createdAt: number;
}

function extractOrderItemsFromOrders(orders: Order[]): OrderItemRecord[] {
  const list: OrderItemRecord[] = [];
  for (const ord of orders) {
    if (!ord.items || !Array.isArray(ord.items)) continue;
    for (const it of ord.items) {
      list.push({
        id: it.id || `oi-${ord.id}-${list.length + 1}`,
        orderId: ord.id,
        tenantId: ord.tenantId || "tenant-ms-preparacoes",
        productId: it.product?.id || `p-${list.length + 1}`,
        name: it.product?.name || "Lanche Especial",
        price: Number(it.product?.price) || 0,
        quantity: Number(it.quantity) || 1,
        image: it.product?.image || "",
        optionsJson: JSON.stringify(it.selectedOptions || []),
        createdAt: ord.createdAt || Date.now(),
      });
    }
  }
  return list;
}

function getPersistedSuperAdmin(): { id?: string; email?: string; password?: string; updatedAt?: number } | null {
  try {
    if (typeof globalThis !== "undefined" && (globalThis as any).__TOPFOOD_SUPERADMIN__) {
      return (globalThis as any).__TOPFOOD_SUPERADMIN__;
    }
  } catch {
    // ignore
  }
  return null;
}

export function setPersistedSuperAdmin(admin: { id: string; email: string; password: string; updatedAt: number }) {
  try {
    if (typeof globalThis !== "undefined") {
      (globalThis as any).__TOPFOOD_SUPERADMIN__ = admin;
    }
  } catch {
    // ignore
  }
}

// In-memory data store for Node.js / preview runtime (with persistence)
class MemoryStore {
  tenants: Tenant[] = (() => {
    const overrides = getPersistedTenantOverrides();
    return initialTenants
      .filter((t) => !isTenantPermanentlyDeleted(t.id) && !isTenantPermanentlyDeleted(t.slug))
      .map((t) => {
        const ov = overrides[t.id] || overrides[t.slug];
        if (ov) {
          const merged = { ...t, ...ov };
          const resolvedCat =
            merged.businessType ||
            merged.category ||
            merged.categoryId ||
            (merged as any).category_id ||
            t.businessType ||
            "Hambúrgueres";
          merged.businessType = resolvedCat;
          merged.category = resolvedCat;
          merged.categoryId = resolvedCat;
          return merged;
        }
        return {
          ...t,
          category: t.businessType,
          categoryId: t.businessType,
        };
      });
  })();
  users: User[] = (() => {
    const list = initialUsers.filter((u) => !u.tenantId || !isTenantPermanentlyDeleted(u.tenantId));
    const persisted = getPersistedSuperAdmin();
    if (persisted && persisted.email && persisted.password) {
      // Remove qualquer super admin padrão e mantém estritamente o persistido
      const filtered = list.filter(
        (u) => !["super_admin", "superadmin", "SUPER_ADMIN"].includes(u.role)
      );
      filtered.push({
        id: persisted.id || "user-superadmin",
        email: persisted.email,
        password: persisted.password,
        name: "Diretor da Plataforma",
        role: "super_admin",
        tenantId: null,
        status: "active",
        createdAt: Date.now() - 60 * 86400000,
        updatedAt: persisted.updatedAt || Date.now(),
      });
      return filtered;
    }
    return list;
  })();
  products: Product[] = initialProducts.filter((p) => !isTenantPermanentlyDeleted(p.tenantId));
  categories: Category[] = [...defaultCategories];
  establishmentCategories: EstablishmentCategory[] = [...defaultEstablishmentCategories];
  orders: Order[] = initialOrders.filter((o) => !isTenantPermanentlyDeleted(o.tenantId));
  orderItems: OrderItemRecord[] = extractOrderItemsFromOrders(initialOrders).filter((oi) => !isTenantPermanentlyDeleted(oi.tenantId));
  customers: Customer[] = initialCustomers.filter((c) => !isTenantPermanentlyDeleted(c.tenantId));
  platformSettings: PlatformSettings = { ...defaultPlatformSettings };
  stories: StoreStory[] = initialStories.filter((s) => !isTenantPermanentlyDeleted(s.tenantId));
  addonGroups: AddonGroup[] = initialAddonGroups.filter((g) => !isTenantPermanentlyDeleted(g.tenantId));
  merchantPushTokens: Map<string, Array<{ token: string; platform: string; userId?: string; isLoggedIn: boolean; updatedAt: number }>> = new Map();

  // Helper to slugify
  slugify(text: string): string {
    return text
      .toString()
      .toLowerCase()
      .trim()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, "-")
      .replace(/[^\w-]+/g, "")
      .replace(/--+/g, "-");
  }
}

// Global store singleton for Node.js / Hono
const globalStore = new MemoryStore();

/**
 * Data Access Layer for Multi-tenancy
 * Uses env.DB (Cloudflare D1) if configured, or falls back seamlessly to memory store
 */
/**
 * Normaliza o tipo do pedido salvo no banco ('delivery' | 'pickup' | 'dine_in' e variantes)
 * para o 'tipo_pedido' canônico: 'delivery' | 'retirada' | 'mesa'.
 */
export function resolveTipoPedido(orderType?: string | null, tableNumber?: string | null): "delivery" | "retirada" | "mesa" {
  const t = String(orderType || "").toLowerCase().trim();
  if (t === "dine_in" || t === "mesa" || t === "dinein" || t === "dine-in") return "mesa";
  if (t === "pickup" || t === "retirada" || t === "takeaway" || t === "balcao" || t === "balcão") return "retirada";
  if (t === "delivery" || t === "entrega") return "delivery";
  return tableNumber && String(tableNumber).trim() ? "mesa" : "delivery";
}

export class Database {
  private env?: Env;
  private ctx?: { waitUntil(promise: Promise<unknown>): void };

  constructor(env?: Env) {
    this.env = env;
  }

  /** Permite que tarefas secundárias terminem depois da resposta (Cloudflare Workers). */
  setExecutionContext(ctx?: { waitUntil(promise: Promise<unknown>): void }): void {
    this.ctx = ctx;
  }

  private static tablesInitialized = false;

  private async ensureTables(): Promise<void> {
    if (Database.tablesInitialized || !this.env?.DB) return;
    try {
      const db = this.env.DB;

      // 1. Criação das tabelas principais com todos os campos necessários
      const tableQueries = [
        `CREATE TABLE IF NOT EXISTS tenants (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          slug TEXT NOT NULL UNIQUE,
          email TEXT NOT NULL DEFAULT '',
          phone TEXT DEFAULT '',
          whatsapp TEXT NOT NULL DEFAULT '',
          pix_key TEXT DEFAULT '',
          pix_key_type TEXT DEFAULT 'email',
          delivery_fee REAL DEFAULT 5.0,
          min_order REAL DEFAULT 0,
          estimated_time TEXT DEFAULT '30-45 min',
          address TEXT DEFAULT 'Centro',
          hours TEXT DEFAULT '18:00 - 23:30',
          tagline TEXT DEFAULT '',
          announcement TEXT DEFAULT '',
          logo TEXT DEFAULT '🍔',
          banner TEXT DEFAULT '',
          banner_image TEXT DEFAULT '',
          primary_color TEXT DEFAULT '#E63946',
          secondary_color TEXT DEFAULT '#1E293B',
          primary_dark TEXT DEFAULT '#C1121F',
          primary_light TEXT DEFAULT '#F77F00',
          accent_color TEXT DEFAULT '#FCBF49',
          localidade TEXT NOT NULL DEFAULT 'Gargaú',
          motoboy_phone TEXT DEFAULT '',
          motoboy_name TEXT DEFAULT '',
          status TEXT DEFAULT 'active',
          subscription_status TEXT DEFAULT 'demo',
          billing_day INTEGER,
          last_payment_at INTEGER,
          monthly_fee REAL DEFAULT 49.90,
          is_open INTEGER DEFAULT 1,
          is_featured INTEGER DEFAULT 0,
          priority_order INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL,
          updated_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS platform_settings (
          id TEXT PRIMARY KEY,
          settings_json TEXT NOT NULL,
          updated_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT NOT NULL DEFAULT 'tenant_admin',
          tenant_id TEXT,
          status TEXT NOT NULL DEFAULT 'active',
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS products (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT,
          price REAL NOT NULL,
          category TEXT NOT NULL DEFAULT 'lanches',
          image TEXT NOT NULL DEFAULT '',
          available INTEGER NOT NULL DEFAULT 1,
          options_json TEXT DEFAULT '[]',
          position INTEGER DEFAULT 0,
          ordem INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS categories (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          name TEXT NOT NULL,
          icon TEXT DEFAULT '🍽️',
          order_index INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS establishment_categories (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          icon TEXT NOT NULL DEFAULT '🍽️',
          order_index INTEGER DEFAULT 0,
          active INTEGER DEFAULT 1,
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS orders (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          customer_name TEXT NOT NULL,
          customer_phone TEXT NOT NULL,
          order_type TEXT NOT NULL DEFAULT 'delivery',
          table_number TEXT DEFAULT '',
          payment_method TEXT NOT NULL DEFAULT 'pix',
          card_type TEXT,
          payment_details TEXT,
          pix_receipt_url TEXT,
          location_url TEXT,
          address_json TEXT DEFAULT '{}',
          change_for TEXT,
          subtotal REAL NOT NULL,
          delivery_fee REAL NOT NULL,
          total REAL NOT NULL,
          status TEXT NOT NULL DEFAULT 'received',
          items_json TEXT NOT NULL DEFAULT '[]',
          status_history_json TEXT NOT NULL DEFAULT '[]',
          idempotency_key TEXT DEFAULT '',
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS customers (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          name TEXT NOT NULL,
          phone TEXT NOT NULL,
          address_street TEXT,
          address_number TEXT,
          address_district TEXT,
          address_complement TEXT,
          address_reference TEXT,
          total_orders INTEGER DEFAULT 1,
          total_spent REAL DEFAULT 0,
          last_order_at INTEGER NOT NULL,
          created_at INTEGER NOT NULL,
          updated_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS order_items (
          id TEXT PRIMARY KEY,
          order_id TEXT NOT NULL,
          tenant_id TEXT NOT NULL,
          product_id TEXT NOT NULL,
          name TEXT NOT NULL,
          price REAL NOT NULL,
          quantity INTEGER NOT NULL DEFAULT 1,
          image TEXT DEFAULT '',
          options_json TEXT DEFAULT '[]',
          created_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS store_stories (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          media_url TEXT NOT NULL,
          media_type TEXT NOT NULL DEFAULT 'image',
          caption TEXT,
          created_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS addon_groups (
          id TEXT PRIMARY KEY,
          tenant_id TEXT NOT NULL,
          name TEXT NOT NULL,
          description TEXT DEFAULT '',
          min_selection INTEGER DEFAULT 0,
          max_selection INTEGER DEFAULT 0,
          required INTEGER DEFAULT 0,
          items_json TEXT NOT NULL DEFAULT '[]',
          position INTEGER DEFAULT 0,
          created_at INTEGER NOT NULL,
          updated_at INTEGER NOT NULL
        )`,
        `CREATE TABLE IF NOT EXISTS deleted_tenants (
          id TEXT PRIMARY KEY,
          slug TEXT,
          deleted_at INTEGER NOT NULL
        )`
      ];

      for (const query of tableQueries) {
        try {
          await db.prepare(query).run();
        } catch (e) {
          console.warn("D1 create table warning:", e);
        }
      }

      // Sincroniza lista de lojas permanentemente excluídas do D1
      try {
        const delRes = await db.prepare("SELECT id, slug FROM deleted_tenants").all<any>();
        if (delRes?.results && Array.isArray(delRes.results)) {
          for (const r of delRes.results) {
            if (r.id) persistDeletedTenant(r.id);
            if (r.slug) persistDeletedTenant(r.slug);
          }
        }
      } catch (_e) {
        void _e;
      }

      // 2. Migração segura de colunas para tabelas já existentes no D1 (evita erro de coluna ausente)
      const alterQueries = [
        "ALTER TABLE tenants ADD COLUMN email TEXT NOT NULL DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN phone TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN whatsapp TEXT NOT NULL DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN pix_key TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN pix_key_type TEXT DEFAULT 'email'",
        "ALTER TABLE tenants ADD COLUMN delivery_fee REAL DEFAULT 5.0",
        "ALTER TABLE tenants ADD COLUMN min_order REAL DEFAULT 0",
        "ALTER TABLE tenants ADD COLUMN estimated_time TEXT DEFAULT '30-45 min'",
        "ALTER TABLE tenants ADD COLUMN address TEXT DEFAULT 'Centro'",
        "ALTER TABLE tenants ADD COLUMN hours TEXT DEFAULT '18:00 - 23:30'",
        "ALTER TABLE tenants ADD COLUMN tagline TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN announcement TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN logo TEXT DEFAULT '🍔'",
        "ALTER TABLE tenants ADD COLUMN banner TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN banner_image TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN primary_color TEXT DEFAULT '#E63946'",
        "ALTER TABLE tenants ADD COLUMN secondary_color TEXT DEFAULT '#1E293B'",
        "ALTER TABLE tenants ADD COLUMN primary_dark TEXT DEFAULT '#C1121F'",
        "ALTER TABLE tenants ADD COLUMN primary_light TEXT DEFAULT '#F77F00'",
        "ALTER TABLE tenants ADD COLUMN accent_color TEXT DEFAULT '#FCBF49'",
        "ALTER TABLE tenants ADD COLUMN status TEXT DEFAULT 'active'",
        "ALTER TABLE tenants ADD COLUMN is_open INTEGER DEFAULT 1",
        "ALTER TABLE tenants ADD COLUMN created_at INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE tenants ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE products ADD COLUMN options_json TEXT DEFAULT '[]'",
        "ALTER TABLE products ADD COLUMN available INTEGER NOT NULL DEFAULT 1",
        "ALTER TABLE products ADD COLUMN position INTEGER DEFAULT 0",
        "ALTER TABLE products ADD COLUMN ordem INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN tenant_id TEXT",
        "ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'active'",
        "ALTER TABLE users ADD COLUMN updated_at INTEGER DEFAULT 0",
        "ALTER TABLE tenants ADD COLUMN business_type TEXT DEFAULT 'Lanchonetes'",
        "ALTER TABLE tenants ADD COLUMN category TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN category_id TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN is_featured INTEGER DEFAULT 0",
        "ALTER TABLE tenants ADD COLUMN priority_order INTEGER DEFAULT 0",
        "ALTER TABLE establishment_categories ADD COLUMN order_index INTEGER DEFAULT 0",
        "ALTER TABLE establishment_categories ADD COLUMN active INTEGER DEFAULT 1",
        "ALTER TABLE tenants ADD COLUMN subscription_status TEXT DEFAULT 'demo'",
        "ALTER TABLE tenants ADD COLUMN billing_day INTEGER",
        "ALTER TABLE tenants ADD COLUMN last_payment_at INTEGER",
        "ALTER TABLE tenants ADD COLUMN paid_until INTEGER",
        "ALTER TABLE tenants ADD COLUMN next_due_date INTEGER",
        "ALTER TABLE tenants ADD COLUMN monthly_fee REAL DEFAULT 49.90",
        "ALTER TABLE orders ADD COLUMN pix_receipt_url TEXT",
        "ALTER TABLE orders ADD COLUMN card_type TEXT",
        "ALTER TABLE orders ADD COLUMN payment_details TEXT",
        "ALTER TABLE orders ADD COLUMN location_url TEXT",
        "ALTER TABLE orders ADD COLUMN table_number TEXT DEFAULT ''",
        "ALTER TABLE products ADD COLUMN addon_group_ids TEXT DEFAULT '[]'",
        "ALTER TABLE tenants ADD COLUMN localidade TEXT DEFAULT 'Gargaú'",
        "ALTER TABLE tenants ADD COLUMN motoboy_phone TEXT DEFAULT ''",
        "ALTER TABLE tenants ADD COLUMN motoboy_name TEXT DEFAULT ''",
        "ALTER TABLE orders ADD COLUMN idempotency_key TEXT DEFAULT ''"
      ];

      for (const alter of alterQueries) {
        try {
          await db.prepare(alter).run();
        } catch {
          // Coluna já existe no D1, ignorar
        }
      }

      // 3. Índices de performance e Views
      const indexQueries = [
        "CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug)",
        "CREATE INDEX IF NOT EXISTS idx_tenants_localidade ON tenants(localidade)",
        "CREATE INDEX IF NOT EXISTS idx_tenants_featured ON tenants(is_featured, priority_order)",
        "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
        "CREATE INDEX IF NOT EXISTS idx_products_tenant ON products(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_addon_groups_tenant ON addon_groups(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_categories_tenant ON categories(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_establishment_categories_order ON establishment_categories(order_index)",
        "CREATE INDEX IF NOT EXISTS idx_orders_tenant ON orders(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_orders_idempotency ON orders(idempotency_key)",
        "CREATE INDEX IF NOT EXISTS idx_order_items_product ON order_items(product_id)",
        "CREATE INDEX IF NOT EXISTS idx_order_items_tenant ON order_items(tenant_id)",
        "CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id)",
        "CREATE VIEW IF NOT EXISTS stores AS SELECT * FROM tenants"
      ];

      for (const idx of indexQueries) {
        try {
          await db.prepare(idx).run();
        } catch {
          // Ignorar se já existir
        }
      }

      // 4. Garante que todos os tenants, users, produtos, categorias, stories e grupos de adicionais iniciais existam no D1 (exceto se excluídos)
      try {
        for (const t of initialTenants) {
          if (isTenantPermanentlyDeleted(t.id) || isTenantPermanentlyDeleted(t.slug)) continue;
          await this.insertTenantRow(t);
        }
        for (const u of initialUsers) {
          if (u.tenantId && isTenantPermanentlyDeleted(u.tenantId)) continue;
          await this.insertUserRow(u);
        }
        for (const p of initialProducts) {
          if (isTenantPermanentlyDeleted(p.tenantId)) continue;
          await this.insertProductRow(p);
        }
        for (const ec of defaultEstablishmentCategories) {
          await this.insertEstablishmentCategoryRow(ec);
        }
        for (const s of initialStories) {
          if (isTenantPermanentlyDeleted(s.tenantId)) continue;
          await this.insertStoryRow(s);
        }
        for (const ag of initialAddonGroups) {
          if (isTenantPermanentlyDeleted(ag.tenantId)) continue;
          await this.insertAddonGroupRow(ag);
        }

        // 5. Seed de pedidos e order_items se estiver vazia
        try {
          const ordCountRes = await db.prepare("SELECT count(*) as total FROM orders").first<{ total: number }>();
          if (!ordCountRes || Number(ordCountRes.total) === 0) {
            for (const ord of initialOrders) {
              await this.insertOrderRow(ord);
            }
          }

          const oiCountRes = await db.prepare("SELECT count(*) as total FROM order_items").first<{ total: number }>();
          if (!oiCountRes || Number(oiCountRes.total) === 0) {
            const ordersRes = await db.prepare("SELECT id, tenant_id, items_json, created_at FROM orders").all<{ id: string; tenant_id: string; items_json: string; created_at: number }>();
            if (ordersRes?.results && ordersRes.results.length > 0) {
              for (const ord of ordersRes.results) {
                try {
                  const items = JSON.parse(ord.items_json || "[]");
                  for (const it of items) {
                    const oiId = it.id || `oi-${ord.id}-${Math.random().toString(36).substring(2, 7)}`;
                    const pId = it.product?.id || `p-${Math.random().toString(36).substring(2, 7)}`;
                    const pName = it.product?.name || "Lanche Especial";
                    const pPrice = Number(it.product?.price) || 0;
                    const pImg = it.product?.image || "";
                    const pQty = Number(it.quantity) || 1;
                    const optJson = JSON.stringify(it.selectedOptions || []);
                    await db.prepare(
                      `INSERT OR IGNORE INTO order_items (
                        id, order_id, tenant_id, product_id, name, price, quantity, image, options_json, created_at
                      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
                    ).bind(oiId, ord.id, ord.tenant_id, pId, pName, pPrice, pQty, pImg, optJson, ord.created_at || Date.now()).run();
                  }
                } catch {
                  // Ignore item insertion error during initial backfill
                }
              }
            }
          }
        } catch (backfillErr) {
          console.warn("orders/order_items backfill notice:", backfillErr);
        }

        // 6. Varredura e higienização para garantir estritamente 1 único Super Admin no D1
        try {
          const superAdminsRes = await db
            .prepare(
              `SELECT id FROM users 
               WHERE UPPER(role) = 'SUPER_ADMIN' OR LOWER(role) = 'super_admin' OR LOWER(role) = 'superadmin' 
               ORDER BY COALESCE(updated_at, 0) DESC, created_at DESC`
            )
            .all<{ id: string }>();
          if (superAdminsRes?.results && superAdminsRes.results.length > 1) {
            const keepId = superAdminsRes.results[0].id;
            await db
              .prepare(
                `DELETE FROM users 
                 WHERE (UPPER(role) = 'SUPER_ADMIN' OR LOWER(role) = 'super_admin' OR LOWER(role) = 'superadmin') 
                   AND id != ?`
              )
              .bind(keepId)
              .run();
          }
        } catch (sweepErr) {
          console.warn("D1 super admin cleanup sweep warning:", sweepErr);
        }
      } catch (e) {
        console.warn("D1 seed initial check warning:", e);
      }

      Database.tablesInitialized = true;
    } catch (e) {
      console.warn("D1 ensureTables warning:", e);
    }
  }

  private async insertTenantRow(t: Tenant): Promise<void> {
    if (!this.env?.DB) return;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO tenants (
          id, name, slug, email, phone, whatsapp, pix_key, pix_key_type,
          delivery_fee, min_order, estimated_time, address, hours, tagline,
          announcement, logo, banner, banner_image, primary_color, secondary_color,
          primary_dark, primary_light, accent_color, business_type, localidade, motoboy_phone, motoboy_name, status, is_open,
          is_featured, priority_order,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          t.id,
          t.name,
          t.slug,
          t.email,
          t.phone || "",
          t.whatsapp,
          t.pixKey,
          t.pixKeyType,
          t.deliveryFee,
          0,
          "30-45 min",
          t.address,
          t.hours,
          t.tagline,
          t.announcement || "",
          t.logo,
          t.bannerImage || "",
          t.bannerImage || "",
          t.primaryColor,
          t.secondaryColor || "#1E293B",
          t.primaryDark,
          t.primaryLight,
          t.accentColor,
          t.businessType || "Hambúrgueres",
          t.localidade || "Gargaú",
          t.motoboyPhone || (t as any).motoboy_phone || "",
          t.motoboyName || (t as any).motoboy_name || "",
          t.status,
          t.isOpen ? 1 : 0,
          t.isFeatured ? 1 : 0,
          t.priorityOrder || 0,
          t.createdAt,
          t.updatedAt
        )
        .run();
    } catch {
      try {
        await this.env.DB.prepare(
          `INSERT OR IGNORE INTO tenants (
            id, name, slug, email, phone, whatsapp, pix_key, pix_key_type,
            delivery_fee, min_order, estimated_time, address, hours, tagline,
            announcement, logo, banner, banner_image, primary_color, secondary_color,
            primary_dark, primary_light, accent_color, localidade, status, is_open,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            t.id,
            t.name,
            t.slug,
            t.email,
            t.phone || "",
            t.whatsapp,
            t.pixKey,
            t.pixKeyType,
            t.deliveryFee,
            0,
            "30-45 min",
            t.address,
            t.hours,
            t.tagline,
            t.announcement || "",
            t.logo,
            t.bannerImage || "",
            t.bannerImage || "",
            t.primaryColor,
            t.secondaryColor || "#1E293B",
            t.primaryDark,
            t.primaryLight,
            t.accentColor,
            t.localidade || "Gargaú",
            t.status,
            t.isOpen ? 1 : 0,
            t.createdAt,
            t.updatedAt
          )
          .run();
      } catch {
        // ignore
      }
    }
  }

  private async insertUserRow(u: User): Promise<void> {
    if (!this.env?.DB) return;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO users (id, email, password, name, role, tenant_id, status, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          u.id,
          u.email,
          u.password || "123456",
          u.name,
          u.role,
          u.tenantId || null,
          u.status,
          u.createdAt
        )
        .run();
    } catch {
      // ignore
    }
  }

  private async insertProductRow(p: Product): Promise<void> {
    if (!this.env?.DB) return;
    const createdAt = p.createdAt || Date.now();
    const pos = typeof p.position === "number" ? p.position : 0;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO products (id, tenant_id, name, description, price, category, image, available, position, options_json, addon_group_ids, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          p.id,
          p.tenantId,
          p.name,
          p.description || "",
          p.price,
          p.category,
          p.image || "",
          p.available ? 1 : 0,
          pos,
          JSON.stringify(p.options || []),
          JSON.stringify(p.addonGroupIds || []),
          createdAt
        )
        .run();
    } catch {
      try {
        await this.env.DB.prepare(
          `INSERT OR IGNORE INTO products (id, tenant_id, name, description, price, category, image, available, options_json, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            p.id,
            p.tenantId,
            p.name,
            p.description || "",
            p.price,
            p.category,
            p.image || "",
            p.available ? 1 : 0,
            JSON.stringify(p.options || []),
            createdAt
          )
          .run();
      } catch {
        // ignore
      }
    }
  }

  private async insertAddonGroupRow(g: AddonGroup): Promise<void> {
    if (!this.env?.DB) return;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO addon_groups (
          id, tenant_id, name, description, min_selection, max_selection, required, items_json, position, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          g.id,
          g.tenantId,
          g.name,
          g.description || "",
          g.minSelection || 0,
          g.maxSelection || 0,
          g.required ? 1 : (g.minSelection && g.minSelection > 0 ? 1 : 0),
          JSON.stringify(g.items || []),
          g.position ?? 0,
          g.createdAt || Date.now(),
          g.updatedAt || Date.now()
        )
        .run();
    } catch (e) {
      console.warn("D1 insertAddonGroupRow error:", e);
    }
  }

  private async insertEstablishmentCategoryRow(ec: EstablishmentCategory): Promise<void> {
    if (!this.env?.DB) return;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO establishment_categories (id, name, icon, order_index, active, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
        .bind(
          ec.id,
          ec.name,
          ec.icon || "🍽️",
          ec.order ?? ec.order_index ?? 0,
          ec.active !== false ? 1 : 0,
          ec.createdAt || Date.now()
        )
        .run();
    } catch {
      // ignore
    }
  }

  private async insertStoryRow(s: StoreStory): Promise<void> {
    if (!this.env?.DB) return;
    try {
      await this.env.DB.prepare(
        `INSERT OR IGNORE INTO store_stories (id, tenant_id, media_url, media_type, caption, created_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
        .bind(
          s.id,
          s.tenantId,
          s.mediaUrl,
          s.mediaType || "image",
          s.caption || null,
          s.createdAt,
          s.expiresAt
        )
        .run();
    } catch {
      // ignore
    }
  }

  private async insertOrderRow(o: Order): Promise<void> {
    if (!this.env?.DB) return;
    try {
      try {
        await this.env.DB.prepare(
          `INSERT OR IGNORE INTO orders (
            id, tenant_id, customer_name, customer_phone, order_type, table_number, payment_method,
            card_type, payment_details, pix_receipt_url, location_url,
            address_json, change_for, subtotal, delivery_fee, total, status,
            items_json, status_history_json, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            o.id,
            o.tenantId,
            o.customerName,
            o.customerPhone,
            o.orderType,
            o.tableNumber || o.table_number || (o as any).mesa || (o as any).table || "",
            o.paymentMethod,
            o.cardType || null,
            o.paymentDetails || null,
            o.pixReceiptUrl || o.pix_receipt_url || null,
            o.location_url || o.locationUrl || null,
            JSON.stringify(o.address || {}),
            o.changeFor || "",
            o.subtotal,
            o.deliveryFee,
            o.total,
            o.status,
            JSON.stringify(o.items || []),
            JSON.stringify(o.statusHistory || []),
            o.createdAt
          )
          .run();
      } catch {
        await this.env.DB.prepare(
          `INSERT OR IGNORE INTO orders (
            id, tenant_id, customer_name, customer_phone, order_type, payment_method,
            card_type, payment_details, pix_receipt_url, location_url,
            address_json, change_for, subtotal, delivery_fee, total, status,
            items_json, status_history_json, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            o.id,
            o.tenantId,
            o.customerName,
            o.customerPhone,
            o.orderType,
            o.paymentMethod,
            o.cardType || null,
            o.paymentDetails || null,
            o.pixReceiptUrl || o.pix_receipt_url || null,
            o.location_url || o.locationUrl || null,
            JSON.stringify(o.address || {}),
            o.changeFor || "",
            o.subtotal,
            o.deliveryFee,
            o.total,
            o.status,
            JSON.stringify(o.items || []),
            JSON.stringify(o.statusHistory || []),
            o.createdAt
          )
          .run();
      }

      if (o.items && o.items.length > 0) {
        for (const it of o.items) {
          const oiId = it.id || `oi-${o.id}-${Math.random().toString(36).substring(2, 7)}`;
          const pId = it.product?.id || `p-${Math.random().toString(36).substring(2, 7)}`;
          const pName = it.product?.name || "Lanche Especial";
          const pPrice = Number(it.product?.price) || 0;
          const pImg = it.product?.image || "";
          const pQty = Number(it.quantity) || 1;
          const optJson = JSON.stringify(it.selectedOptions || []);
          await this.env.DB.prepare(
            `INSERT OR IGNORE INTO order_items (
              id, order_id, tenant_id, product_id, name, price, quantity, image, options_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              oiId,
              o.id,
              o.tenantId,
              pId,
              pName,
              pPrice,
              pQty,
              pImg,
              optJson,
              o.createdAt || Date.now()
            )
            .run();
        }
      }
    } catch (e) {
      console.warn("D1 insertOrderRow warning:", e);
    }
  }

  private getKv() {
    return this.env?.KV || this.env?.STORE_KV;
  }

  // ===================== TENANTS =====================

  async getTenants(): Promise<Tenant[]> {
    await this.ensureTables();
    if (this.env?.DB) {
      try {
        let res: any;
        try {
          res = await this.env.DB.prepare(
            "SELECT * FROM tenants ORDER BY is_featured DESC, priority_order DESC, created_at DESC"
          ).all<any>();
        } catch {
          res = await this.env.DB.prepare(
            "SELECT * FROM tenants ORDER BY created_at DESC"
          ).all<any>();
        }
        if (res.results && res.results.length > 0) {
          let d1Tenants = res.results.map((r: any) => this.mapTenantRow(r));
          d1Tenants.sort((a: Tenant, b: Tenant) => {
            const aFeat = Boolean(a.isFeatured);
            const bFeat = Boolean(b.isFeatured);
            if (aFeat && !bFeat) return -1;
            if (!aFeat && bFeat) return 1;
            if (aFeat && bFeat) {
              const aOrder = Number(a.priorityOrder) || 0;
              const bOrder = Number(b.priorityOrder) || 0;
              if (aOrder !== bOrder) return bOrder - aOrder;
            }
            return (b.createdAt || 0) - (a.createdAt || 0);
          });
          // Sincroniza store em memória para manter consistência
          for (const dt of d1Tenants) {
            const idx = globalStore.tenants.findIndex((t) => t.id === dt.id || t.slug === dt.slug);
            if (idx >= 0) {
              globalStore.tenants[idx] = dt;
            } else {
              globalStore.tenants.push(dt);
            }
          }

          // Filtra lojas permanentemente deletadas
          d1Tenants = d1Tenants.filter(
            (dt: Tenant) => !isTenantPermanentlyDeleted(dt.id) && !isTenantPermanentlyDeleted(dt.slug)
          );

          // Garante que todas as lojas demonstrativas ativas estejam presentes
          for (const initT of initialTenants) {
            if (isTenantPermanentlyDeleted(initT.id) || isTenantPermanentlyDeleted(initT.slug)) continue;
            if (!d1Tenants.some((dt: Tenant) => dt.id === initT.id || dt.slug === initT.slug)) {
              d1Tenants.push(initT);
              this.insertTenantRow(initT).catch(() => {});
            }
          }
      const normalizeTenantLoc = (t: Tenant): Tenant => {
        const loc = (t.localidade || t.location || "Gargaú").trim() || "Gargaú";
        return { ...t, localidade: loc, location: loc };
      };
      return d1Tenants.map(normalizeTenantLoc);
        }
      } catch (e) {
        console.warn("D1 query failed, using memory store:", e);
      }
    }
    const memTenants = globalStore.tenants
      .filter((t) => !isTenantPermanentlyDeleted(t.id) && !isTenantPermanentlyDeleted(t.slug))
      .map((t) => {
        const loc = (t.localidade || t.location || "Gargaú").trim() || "Gargaú";
        return { ...t, localidade: loc, location: loc };
      });
    memTenants.sort((a, b) => {
      const aFeat = Boolean(a.isFeatured);
      const bFeat = Boolean(b.isFeatured);
      if (aFeat && !bFeat) return -1;
      if (!aFeat && bFeat) return 1;
      if (aFeat && bFeat) {
        const aOrder = Number(a.priorityOrder) || 0;
        const bOrder = Number(b.priorityOrder) || 0;
        if (aOrder !== bOrder) return bOrder - aOrder;
      }
      return (b.createdAt || 0) - (a.createdAt || 0);
    });
    return memTenants;
  }

  async getTenantByIdOrSlug(idOrSlug: string): Promise<Tenant | null> {
    if (!idOrSlug) return null;
    const clean = idOrSlug.trim().toLowerCase();

    // Se estiver na lista de exclusão definitiva, rejeita imediatamente
    if (isTenantPermanentlyDeleted(clean)) {
      return null;
    }

    // 1. Tentar obter do Cloudflare KV para resposta ultra rápida
    const kv = this.getKv();
    if (kv) {
      try {
        const cached = await kv.get(`tenant:${clean}`);
        if (cached) {
          return JSON.parse(cached) as Tenant;
        }
      } catch (e) {
        console.warn("KV getTenant error:", e);
      }
    }

    // 2. Consultar banco de dados D1 (Cloudflare Workers SQL)
    const altSlug =
      clean === "ms-preparacoes"
        ? "marcelino"
        : clean === "marcelino"
        ? "ms-preparacoes"
        : clean;

    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare(
          "SELECT * FROM tenants WHERE id = ? OR LOWER(slug) = ? OR LOWER(slug) = ? LIMIT 1"
        )
          .bind(clean, clean, altSlug)
          .first<any>();
        if (row) {
          const tenant = this.mapTenantRow(row);
          if (kv) {
            try {
              await kv.put(`tenant:${tenant.id}`, JSON.stringify(tenant));
              await kv.put(`tenant:${tenant.slug.toLowerCase()}`, JSON.stringify(tenant));
            } catch (e) {
              console.warn("KV sync tenant error:", e);
            }
          }
          return tenant;
        }
      } catch (e) {
        console.warn("D1 getTenantByIdOrSlug error:", e);
      }
    }

    // 3. Fallback em memória
    const found = globalStore.tenants.find(
      (t) =>
        t.id === idOrSlug ||
        t.slug.toLowerCase() === clean ||
        ((clean === "ms-preparacoes" || clean === "marcelino") &&
          (t.id === "tenant-ms-preparacoes" || t.slug === "marcelino" || t.slug === "ms-preparacoes"))
    );

    if (found && kv) {
      try {
        await kv.put(`tenant:${found.id}`, JSON.stringify(found));
        await kv.put(`tenant:${found.slug.toLowerCase()}`, JSON.stringify(found));
      } catch (e) {
        console.warn("KV sync fallback tenant error:", e);
      }
    }

    return found || null;
  }

  async getTenantBySlug(slug: string): Promise<Tenant | null> {
    return this.getTenantByIdOrSlug(slug);
  }

  private isAllLocationsFilter(location?: string): boolean {
    if (!location) return true;
    const norm = location.trim().toLowerCase();
    return (
      norm === "" ||
      norm === "todas" ||
      norm === "todas as localidades" ||
      norm === "todas as regiões" ||
      norm === "todas as regioes" ||
      norm === "todos" ||
      norm === "all"
    );
  }

  private matchesLocationFilter(tenantLocation?: string, filterLocation?: string): boolean {
    if (this.isAllLocationsFilter(filterLocation)) return true;
    const tLoc = (tenantLocation || "Gargaú").trim().toLowerCase();
    const fLoc = (filterLocation || "").trim().toLowerCase();
    return tLoc === fLoc;
  }

  // Retorna a lista única de localidades cadastradas nas lojas ativas
  async getDistinctLocalities(): Promise<string[]> {
    await this.ensureTables();
    if (this.env?.DB) {
      try {
        const res = await this.env.DB.prepare(
          "SELECT DISTINCT localidade AS location FROM tenants WHERE status != 'inactive' AND localidade IS NOT NULL AND TRIM(localidade) != '' ORDER BY localidade ASC"
        ).all<{ location: string }>();
        if (res.results && res.results.length > 0) {
          const list = res.results
            .map((r: any) => (r.location || r.localidade || "").trim())
            .filter(Boolean) as string[];
          if (list.length > 0) {
            return Array.from(new Set(list)).sort((a, b) => a.localeCompare(b, "pt-BR"));
          }
        }
      } catch (e) {
        console.warn("D1 getDistinctLocalities failed, fallback to memory:", e);
      }
    }

    const activeTenants = globalStore.tenants.filter(
      (t) =>
        t.status !== "inactive" &&
        !isTenantPermanentlyDeleted(t.id) &&
        !isTenantPermanentlyDeleted(t.slug) &&
        t.localidade &&
        t.localidade.trim() !== ""
    );
    const unique = Array.from(
      new Set(
        activeTenants
          .map((t) => (t.localidade || "").trim())
          .filter(Boolean)
      )
    ).sort((a, b) => a.localeCompare(b, "pt-BR"));

    return unique;
  }

  async createTenant(data: {
    name: string;
    slug?: string;
    email: string;
    phone?: string;
    whatsapp: string;
    pixKey?: string;
    pixKeyType?: Tenant["pixKeyType"];
    deliveryFee?: number;
    address?: string;
    primaryColor?: string;
    bannerImage?: string;
    logo?: string;
    tagline?: string;
    description?: string;
    businessType?: string;
    localidade?: string;
  }): Promise<Tenant> {
    const slug = data.slug
      ? globalStore.slugify(data.slug)
      : globalStore.slugify(data.name);

    // Ensure unique slug in memory and in Cloudflare D1
    let finalSlug = slug;
    let counter = 1;
    while (globalStore.tenants.some((t) => t.slug === finalSlug)) {
      finalSlug = `${slug}-${counter++}`;
    }

    await this.ensureTables();

    if (this.env?.DB) {
      try {
        const existingInD1 = await this.env.DB.prepare(
          "SELECT id FROM tenants WHERE LOWER(slug) = ? LIMIT 1"
        )
          .bind(finalSlug.toLowerCase())
          .first<any>();
        if (existingInD1) {
          finalSlug = `${finalSlug}-${Date.now().toString(36).slice(-4)}`;
        }
      } catch {
        // ignore
      }
    }

    const tenantId = `tenant-${finalSlug}`;
    const newTenant: Tenant = {
      id: tenantId,
      name: data.name.trim(),
      slug: finalSlug,
      email: data.email.trim().toLowerCase(),
      phone: data.phone || "",
      whatsapp: data.whatsapp.replace(/\D/g, "") || "5511999999999",
      pixKey: data.pixKey?.trim() || data.email.trim().toLowerCase(),
      pixKeyType: data.pixKeyType || "email",
      deliveryFee: data.deliveryFee ?? 5.0,
      address: data.address?.trim() || "Endereço da Loja",
      hours: "18:00 - 23:30",
      tagline: data.tagline || data.description || `Cardápio Online - ${data.name}`,
      logo: data.logo || "🍔",
      bannerImage: data.bannerImage || "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1200&q=80",
      primaryColor: data.primaryColor || "#E63946",
      primaryDark: "#C1121F",
      primaryLight: "#F77F00",
      accentColor: "#FCBF49",
      businessType: data.businessType?.trim() || "Lanchonetes",
      localidade: data.localidade?.trim() || "Gargaú",
      motoboyPhone: data.motoboyPhone || (data as any).motoboy_phone || "",
      motoboy_phone: data.motoboyPhone || (data as any).motoboy_phone || "",
      motoboyName: data.motoboyName || (data as any).motoboy_name || "",
      motoboy_name: data.motoboyName || (data as any).motoboy_name || "",
      status: "active",
      isOpen: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    // GRAVAÇÃO OBRIGATÓRIA E DIRETA NO CLOUDFLARE D1
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO tenants (
            id, name, slug, email, phone, whatsapp, pix_key, pix_key_type,
            delivery_fee, min_order, estimated_time, address, hours, tagline,
            announcement, logo, banner, banner_image, primary_color, secondary_color,
            primary_dark, primary_light, accent_color, business_type, localidade, motoboy_phone, motoboy_name, status, is_open,
            created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newTenant.id,
            newTenant.name,
            newTenant.slug,
            newTenant.email,
            newTenant.phone || "",
            newTenant.whatsapp,
            newTenant.pixKey,
            newTenant.pixKeyType,
            newTenant.deliveryFee,
            0,
            "30-45 min",
            newTenant.address,
            newTenant.hours,
            newTenant.tagline,
            newTenant.announcement || "",
            newTenant.logo,
            newTenant.bannerImage || "",
            newTenant.bannerImage || "",
            newTenant.primaryColor,
            newTenant.secondaryColor || "#1E293B",
            newTenant.primaryDark,
            newTenant.primaryLight,
            newTenant.accentColor,
            newTenant.businessType || "Lanchonetes",
            newTenant.localidade || "Gargaú",
            newTenant.motoboyPhone || "",
            newTenant.motoboyName || "",
            newTenant.status,
            newTenant.isOpen ? 1 : 0,
            newTenant.createdAt,
            newTenant.updatedAt
          )
          .run();

        console.log(`[D1 SUCCESS] Tenant ${newTenant.id} (${newTenant.name}) gravado diretamente no Cloudflare D1!`);
      } catch (err: any) {
        console.error("[CRITICAL D1 ERROR] Falha no insert completo do tenant no D1:", err);
        // Fallback resiliente com colunas essenciais
        try {
          await this.env.DB.prepare(
            `INSERT OR REPLACE INTO tenants (
              id, name, slug, email, phone, whatsapp, pix_key,
              delivery_fee, address, hours, tagline, logo,
              primary_color, business_type, localidade, status, is_open, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              newTenant.id,
              newTenant.name,
              newTenant.slug,
              newTenant.email,
              newTenant.phone || "",
              newTenant.whatsapp,
              newTenant.pixKey,
              newTenant.deliveryFee,
              newTenant.address,
              newTenant.hours,
              newTenant.tagline,
              newTenant.logo,
              newTenant.primaryColor,
              newTenant.businessType || "Lanchonetes",
              newTenant.localidade || "Gargaú",
              newTenant.status,
              newTenant.isOpen ? 1 : 0,
              newTenant.createdAt,
              newTenant.updatedAt
            )
            .run();
          console.log(`[D1 FALLBACK SUCCESS] Tenant ${newTenant.id} gravado no D1 via fallback.`);
        } catch (err2: any) {
          console.error("[FATAL D1 INSERT ERROR]:", err2);
          throw new Error(`Falha crítica de persistência no Cloudflare D1: ${err.message || err2.message}`);
        }
      }
    }

    globalStore.tenants.unshift(newTenant);
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`tenant:${newTenant.id}`, JSON.stringify(newTenant));
        await kv.put(`tenant:${newTenant.slug.toLowerCase()}`, JSON.stringify(newTenant));
      } catch (e) {
        console.warn("KV put tenant error:", e);
      }
    }
    return newTenant;
  }

  async updateTenant(id: string, partial: Partial<Tenant>): Promise<Tenant | null> {
    const tenant = await this.getTenantByIdOrSlug(id);
    if (!tenant) return null;

    const isFeaturedVal = partial.isFeatured !== undefined
      ? Boolean(partial.isFeatured)
      : ((partial as any).is_featured !== undefined
          ? Boolean((partial as any).is_featured)
          : (tenant.isFeatured ?? false));

    const priorityOrderVal = partial.priorityOrder !== undefined
      ? Number(partial.priorityOrder)
      : ((partial as any).priority_order !== undefined
          ? Number((partial as any).priority_order)
          : (tenant.priorityOrder ?? 0));

    const subscriptionStatusVal =
      partial.subscriptionStatus ||
      (partial as any).subscription_status ||
      tenant.subscriptionStatus ||
      "demo";

    const billingDayVal =
      partial.billingDay !== undefined
        ? (partial.billingDay !== null && !isNaN(Number(partial.billingDay)) ? Number(partial.billingDay) : undefined)
        : ((partial as any).billing_day !== undefined
            ? ((partial as any).billing_day !== null && !isNaN(Number((partial as any).billing_day)) ? Number((partial as any).billing_day) : undefined)
            : tenant.billingDay);

    const lastPaymentAtVal =
      partial.lastPaymentAt !== undefined
        ? (partial.lastPaymentAt !== null && !isNaN(Number(partial.lastPaymentAt)) ? Number(partial.lastPaymentAt) : undefined)
        : ((partial as any).last_payment_at !== undefined
            ? ((partial as any).last_payment_at !== null && !isNaN(Number((partial as any).last_payment_at)) ? Number((partial as any).last_payment_at) : undefined)
            : tenant.lastPaymentAt);

    const paidUntilVal =
      partial.paidUntil !== undefined
        ? (partial.paidUntil !== null && !isNaN(Number(partial.paidUntil)) ? Number(partial.paidUntil) : undefined)
        : ((partial as any).paid_until !== undefined
            ? ((partial as any).paid_until !== null && !isNaN(Number((partial as any).paid_until)) ? Number((partial as any).paid_until) : undefined)
            : tenant.paidUntil);

    const nextDueDateVal =
      partial.nextDueDate !== undefined
        ? (partial.nextDueDate !== null && !isNaN(Number(partial.nextDueDate)) ? Number(partial.nextDueDate) : undefined)
        : ((partial as any).next_due_date !== undefined
            ? ((partial as any).next_due_date !== null && !isNaN(Number((partial as any).next_due_date)) ? Number((partial as any).next_due_date) : undefined)
            : tenant.nextDueDate);

    const monthlyFeeVal =
      partial.monthlyFee !== undefined
        ? Number(partial.monthlyFee)
        : ((partial as any).monthly_fee !== undefined
            ? Number((partial as any).monthly_fee)
            : (tenant.monthlyFee || 49.9));

    const localidadeVal =
      partial.localidade !== undefined
        ? partial.localidade.trim()
        : tenant.localidade || "Gargaú";

    const motoboyPhoneVal =
      partial.motoboyPhone !== undefined
        ? String(partial.motoboyPhone).trim()
        : ((partial as any).motoboy_phone !== undefined
            ? String((partial as any).motoboy_phone).trim()
            : (tenant.motoboyPhone || (tenant as any).motoboy_phone || ""));

    const motoboyNameVal =
      partial.motoboyName !== undefined
        ? String(partial.motoboyName).trim()
        : ((partial as any).motoboy_name !== undefined
            ? String((partial as any).motoboy_name).trim()
            : (tenant.motoboyName || (tenant as any).motoboy_name || ""));

    const resolvedBusinessType =
      partial.businessType !== undefined && String(partial.businessType).trim() !== ""
        ? String(partial.businessType).trim()
        : partial.category !== undefined && String(partial.category).trim() !== ""
        ? String(partial.category).trim()
        : partial.categoryId !== undefined && String(partial.categoryId).trim() !== ""
        ? String(partial.categoryId).trim()
        : (partial as any).category_id !== undefined && String((partial as any).category_id).trim() !== ""
        ? String((partial as any).category_id).trim()
        : (partial as any).business_type !== undefined && String((partial as any).business_type).trim() !== ""
        ? String((partial as any).business_type).trim()
        : tenant.businessType || tenant.category || "Hambúrgueres";

    const updated: Tenant = {
      ...tenant,
      ...partial,
      businessType: resolvedBusinessType,
      category: resolvedBusinessType,
      categoryId: resolvedBusinessType,
      category_id: resolvedBusinessType,
      localidade: localidadeVal,
      motoboyPhone: motoboyPhoneVal,
      motoboy_phone: motoboyPhoneVal,
      motoboyName: motoboyNameVal,
      motoboy_name: motoboyNameVal,
      isFeatured: isFeaturedVal,
      priorityOrder: priorityOrderVal,
      subscriptionStatus: subscriptionStatusVal,
      billingDay: billingDayVal,
      lastPaymentAt: lastPaymentAtVal,
      paidUntil: paidUntilVal,
      nextDueDate: nextDueDateVal,
      monthlyFee: monthlyFeeVal,
      updatedAt: Date.now(),
    };

    // Persiste em disco/memória global para manter a alteração mesmo após reinício ou refresh
    persistTenantOverride(tenant.id, {
      name: updated.name,
      whatsapp: updated.whatsapp,
      pixKey: updated.pixKey,
      pixKeyType: updated.pixKeyType,
      deliveryFee: updated.deliveryFee,
      address: updated.address,
      hours: updated.hours,
      tagline: updated.tagline,
      logo: updated.logo,
      bannerImage: updated.bannerImage,
      primaryColor: updated.primaryColor,
      primaryDark: updated.primaryDark,
      primaryLight: updated.primaryLight,
      accentColor: updated.accentColor,
      businessType: resolvedBusinessType,
      category: resolvedBusinessType,
      categoryId: resolvedBusinessType,
      category_id: resolvedBusinessType,
      localidade: updated.localidade,
      motoboyPhone: updated.motoboyPhone,
      motoboyName: updated.motoboyName,
      status: updated.status,
      isOpen: updated.isOpen,
      isFeatured: updated.isFeatured,
      priorityOrder: updated.priorityOrder,
      subscriptionStatus: updated.subscriptionStatus,
      billingDay: updated.billingDay,
      lastPaymentAt: updated.lastPaymentAt,
      paidUntil: updated.paidUntil,
      nextDueDate: updated.nextDueDate,
      monthlyFee: updated.monthlyFee,
      updatedAt: updated.updatedAt,
    });

    if (this.env?.DB) {
      await this.ensureTables();
      try {
        await this.env.DB.prepare(
          `UPDATE tenants SET 
            name = ?, whatsapp = ?, pix_key = ?, pix_key_type = ?, 
            delivery_fee = ?, address = ?, hours = ?, tagline = ?, 
            logo = ?, banner = ?, banner_image = ?, primary_color = ?, primary_dark = ?, primary_light = ?, 
            accent_color = ?, business_type = ?, category = ?, category_id = ?, localidade = ?, motoboy_phone = ?, motoboy_name = ?, status = ?, is_open = ?,
            is_featured = ?, priority_order = ?,
            subscription_status = ?, billing_day = ?, last_payment_at = ?, monthly_fee = ?,
            updated_at = ?
          WHERE id = ?`
        )
          .bind(
            updated.name,
            updated.whatsapp,
            updated.pixKey,
            updated.pixKeyType,
            updated.deliveryFee,
            updated.address,
            updated.hours,
            updated.tagline,
            updated.logo,
            updated.bannerImage || "",
            updated.bannerImage || "",
            updated.primaryColor,
            updated.primaryDark,
            updated.primaryLight,
            updated.accentColor,
            resolvedBusinessType,
            resolvedBusinessType,
            resolvedBusinessType,
            updated.localidade || "Gargaú",
            updated.motoboyPhone || "",
            updated.motoboyName || "",
            updated.status,
            updated.isOpen ? 1 : 0,
            updated.isFeatured ? 1 : 0,
            updated.priorityOrder || 0,
            updated.subscriptionStatus || "demo",
            updated.billingDay !== undefined ? updated.billingDay : null,
            updated.lastPaymentAt !== undefined ? updated.lastPaymentAt : null,
            updated.monthlyFee || 49.9,
            updated.updatedAt,
            tenant.id
          )
          .run();
      } catch {
        // Fallback in case D1 table schema migration is in progress
        try {
          await this.env.DB.prepare(
            `UPDATE tenants SET 
              name = ?, whatsapp = ?, pix_key = ?, pix_key_type = ?, 
              delivery_fee = ?, address = ?, hours = ?, tagline = ?, 
              logo = ?, banner_image = ?, primary_color = ?, primary_dark = ?, primary_light = ?, 
              accent_color = ?, business_type = ?, localidade = ?, motoboy_phone = ?, motoboy_name = ?, status = ?, is_open = ?,
              is_featured = ?, priority_order = ?, updated_at = ?
            WHERE id = ?`
          )
            .bind(
              updated.name,
              updated.whatsapp,
              updated.pixKey,
              updated.pixKeyType,
              updated.deliveryFee,
              updated.address,
              updated.hours,
              updated.tagline,
              updated.logo,
              updated.bannerImage || "",
              updated.primaryColor,
              updated.primaryDark,
              updated.primaryLight,
              updated.accentColor,
              resolvedBusinessType,
              updated.localidade || "Gargaú",
              updated.motoboyPhone || "",
              updated.motoboyName || "",
              updated.status,
              updated.isOpen ? 1 : 0,
              updated.isFeatured ? 1 : 0,
              updated.priorityOrder || 0,
              updated.updatedAt,
              tenant.id
            )
            .run();
        } catch (e2) {
          console.warn("D1 updateTenant error:", e2);
        }
      }
    }

    const idx = globalStore.tenants.findIndex((t) => t.id === tenant.id);
    if (idx >= 0) {
      globalStore.tenants[idx] = updated;
    }
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`tenant:${updated.id}`, JSON.stringify(updated));
        await kv.put(`tenant:${updated.slug.toLowerCase()}`, JSON.stringify(updated));
        await kv.delete("tenants:all");
        await kv.delete("categories:active");
      } catch (e) {
        console.warn("KV update tenant error:", e);
      }
    }
    return updated;
  }

  async setTenantStatus(id: string, status: TenantStatus): Promise<Tenant | null> {
    return this.updateTenant(id, { status });
  }

  async activateSubscription(
    idOrSlug: string,
    customBillingDay?: number
  ): Promise<{ success: boolean; tenant: Tenant; billingDay: number; nextDueDate: number }> {
    const tenant = await this.getTenantByIdOrSlug(idOrSlug);
    if (!tenant) {
      throw new Error("Lanchonete não encontrada.");
    }

    // Captura automática do dia atual (1 a 31) ou usa customizado se fornecido
    const now = new Date();
    const billingDay =
      customBillingDay && customBillingDay >= 1 && customBillingDay <= 31
        ? customBillingDay
        : now.getDate();

    const timestamp = now.getTime();

    // Vencimento DEVE SER no mês seguinte no dia X (ex: se ativou em 23/09, o vencimento é 23/10)
    const nextMonthObj = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const targetYear = nextMonthObj.getFullYear();
    const targetMonth = nextMonthObj.getMonth();
    const daysInTargetMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
    const targetDay = Math.min(billingDay, daysInTargetMonth);
    const nextDueDate = new Date(targetYear, targetMonth, targetDay, 23, 59, 59, 999).getTime();

    const updated = await this.updateTenant(tenant.id, {
      subscriptionStatus: "active",
      billingDay,
      lastPaymentAt: timestamp,
      paidUntil: nextDueDate,
      nextDueDate,
      status: "active",
    });

    if (!updated) {
      throw new Error("Falha ao salvar ativação da mensalidade.");
    }

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "UPDATE tenants SET subscription_status = 'active', billing_day = ?, last_payment_at = ?, status = 'active', updated_at = ? WHERE id = ?"
        )
          .bind(billingDay, timestamp, timestamp, tenant.id)
          .run();
      } catch (e) {
        console.warn("D1 direct activateSubscription warning:", e);
      }
    }

    return { success: true, tenant: updated, billingDay, nextDueDate };
  }

  async confirmMonthlyPayment(
    idOrSlug: string
  ): Promise<{ success: boolean; tenant: Tenant; billingDay: number; paymentAt: number; nextDueDate: number }> {
    const tenant = await this.getTenantByIdOrSlug(idOrSlug);
    if (!tenant) {
      throw new Error("Lanchonete não encontrada.");
    }

    const timestamp = Date.now();
    // Preserva o billing_day original já salvo; se não houver, adota o dia de hoje
    const originalBillingDay = tenant.billingDay || new Date().getDate();

    // Calcula próximo vencimento somando +1 mês ao vencimento atual (se futuro) ou +1 mês a partir do mês atual
    const now = new Date();
    let baseYear = now.getFullYear();
    let baseMonth = now.getMonth();

    const currentDueTimestamp = tenant.nextDueDate || tenant.paidUntil;
    if (currentDueTimestamp && currentDueTimestamp > now.getTime()) {
      const currentDueDate = new Date(currentDueTimestamp);
      baseYear = currentDueDate.getFullYear();
      baseMonth = currentDueDate.getMonth();
    }

    const nextMonthObj = new Date(baseYear, baseMonth + 1, 1);
    const targetYear = nextMonthObj.getFullYear();
    const targetMonth = nextMonthObj.getMonth();
    const daysInTargetMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
    const targetDay = Math.min(originalBillingDay, daysInTargetMonth);
    const nextDueDate = new Date(targetYear, targetMonth, targetDay, 23, 59, 59, 999).getTime();

    const updated = await this.updateTenant(tenant.id, {
      subscriptionStatus: "active",
      billingDay: originalBillingDay,
      lastPaymentAt: timestamp,
      paidUntil: nextDueDate,
      nextDueDate,
      status: "active",
    });

    if (!updated) {
      throw new Error("Falha ao confirmar pagamento da mensalidade.");
    }

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "UPDATE tenants SET subscription_status = 'active', last_payment_at = ?, status = 'active', updated_at = ? WHERE id = ?"
        )
          .bind(timestamp, timestamp, tenant.id)
          .run();
      } catch (e) {
        console.warn("D1 direct confirmMonthlyPayment warning:", e);
      }
    }

    return {
      success: true,
      tenant: updated,
      billingDay: originalBillingDay,
      paymentAt: timestamp,
      nextDueDate,
    };
  }

  async cancelSubscription(
    idOrSlug: string
  ): Promise<{ success: boolean; tenant: Tenant }> {
    const tenant = await this.getTenantByIdOrSlug(idOrSlug);
    if (!tenant) {
      throw new Error("Lanchonete não encontrada.");
    }

    const timestamp = Date.now();

    // Redefine status para 'demo' e limpa todos os dados do ciclo atual
    const updated = await this.updateTenant(tenant.id, {
      subscriptionStatus: "demo",
      billingDay: null as any,
      lastPaymentAt: null as any,
      paidUntil: null as any,
      nextDueDate: null as any,
      updatedAt: timestamp,
    });

    if (!updated) {
      throw new Error("Falha ao cancelar assinatura da lanchonete.");
    }

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "UPDATE tenants SET subscription_status = 'demo', billing_day = NULL, last_payment_at = NULL, paid_until = NULL, next_due_date = NULL, updated_at = ? WHERE id = ?"
        )
          .bind(timestamp, tenant.id)
          .run();
      } catch (e) {
        console.warn("D1 direct cancelSubscription warning:", e);
      }
    }

    return {
      success: true,
      tenant: updated,
    };
  }

  async deleteTenant(id: string): Promise<boolean> {
    const tenant = await this.getTenantByIdOrSlug(id);
    const targetId = tenant ? tenant.id : id;
    const targetSlug = tenant ? tenant.slug : id;

    // 1. Marca imediatamente como permanentemente excluído (memória + arquivo persistente em disco)
    persistDeletedTenant(targetId);
    persistDeletedTenant(targetSlug);

    // 2. Remoção definitiva de todas as entidades associadas no banco Cloudflare D1
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "CREATE TABLE IF NOT EXISTS deleted_tenants (id TEXT PRIMARY KEY, slug TEXT, deleted_at INTEGER NOT NULL)"
        ).run();
        await this.env.DB.prepare(
          "INSERT OR REPLACE INTO deleted_tenants (id, slug, deleted_at) VALUES (?, ?, ?)"
        ).bind(targetId, targetSlug, Date.now()).run();

        await this.env.DB.prepare("DELETE FROM tenants WHERE id = ? OR slug = ?").bind(targetId, targetSlug).run();
        await this.env.DB.prepare("DELETE FROM products WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM categories WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM store_stories WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM addon_groups WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM orders WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM users WHERE tenant_id = ?").bind(targetId).run();
        await this.env.DB.prepare("DELETE FROM coupons WHERE tenant_id = ?").bind(targetId).run();
      } catch (e) {
        console.warn("D1 deleteTenant error:", e);
      }
    }

    // 3. Remoção do Cloudflare KV e marcação como excluída
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`deleted_tenant:${targetId.toLowerCase()}`, "1");
        await kv.put(`deleted_tenant:${targetSlug.toLowerCase()}`, "1");
        await kv.delete(`tenant:${targetId}`);
        await kv.delete(`tenant:${targetSlug.toLowerCase()}`);
        await kv.delete(`products:${targetId}`);
        await kv.delete(`categories:${targetId}`);
        await kv.delete(`addons:${targetId}`);
        await kv.delete(`stories:${targetId}`);
      } catch (e) {
        console.warn("KV delete tenant error:", e);
      }
    }

    // 4. Limpeza completa na store em memória (globalStore)
    globalStore.tenants = globalStore.tenants.filter((t) => t.id !== targetId && t.slug !== targetSlug);
    globalStore.products = globalStore.products.filter((p) => p.tenantId !== targetId);
    globalStore.categories = (globalStore.categories || []).filter((c) => c.tenantId !== targetId);
    globalStore.stories = (globalStore.stories || []).filter((s) => s.tenantId !== targetId);
    globalStore.addonGroups = (globalStore.addonGroups || []).filter((g) => g.tenantId !== targetId);
    globalStore.orders = globalStore.orders.filter((o) => o.tenantId !== targetId);
    globalStore.users = globalStore.users.filter((u) => u.tenantId !== targetId);
    return true;
  }

  // ===================== ESTABLISHMENT CATEGORIES =====================

  async getEstablishmentCategories(): Promise<EstablishmentCategory[]> {
    await this.ensureTables();
    let d1Categories: EstablishmentCategory[] = [];

    if (this.env?.DB) {
      try {
        const res = await this.env.DB.prepare(
          "SELECT * FROM establishment_categories WHERE active = 1 ORDER BY order_index ASC, created_at ASC"
        ).all<any>();
        if (res.results && res.results.length > 0) {
          d1Categories = res.results.map((r: any) => ({
            id: r.id,
            name: r.name,
            icon: r.icon || "🍽️",
            order: Number(r.order_index) || 0,
            order_index: Number(r.order_index) || 0,
            active: r.active !== 0,
            createdAt: Number(r.created_at) || Date.now(),
          }));
        }
      } catch (e) {
        console.warn("D1 getEstablishmentCategories error:", e);
      }
    }

    // Merge default, memory and D1 categories
    const combinedMap = new Map<string, EstablishmentCategory>();

    defaultEstablishmentCategories.forEach((cat) => {
      combinedMap.set(cat.id.toLowerCase(), { ...cat });
    });

    (globalStore.establishmentCategories || []).forEach((cat) => {
      combinedMap.set(cat.id.toLowerCase(), { ...cat });
    });

    d1Categories.forEach((cat) => {
      combinedMap.set(cat.id.toLowerCase(), { ...cat });
    });

    return Array.from(combinedMap.values()).sort(
      (a, b) => (a.order ?? a.order_index ?? 0) - (b.order ?? b.order_index ?? 0)
    );
  }

  async createEstablishmentCategory(data: {
    name: string;
    icon?: string;
    order?: number;
  }): Promise<EstablishmentCategory> {
    await this.ensureTables();
    const cleanName = data.name.trim();
    if (!cleanName) {
      throw new Error("O nome da categoria não pode ser vazio.");
    }

    const id = globalStore.slugify(cleanName);
    const existingList = await this.getEstablishmentCategories();
    const existing = existingList.find(
      (c) => c.name.toLowerCase() === cleanName.toLowerCase() || c.id === id
    );
    if (existing) {
      return existing;
    }

    const maxOrder = existingList.reduce((max, c) => Math.max(max, c.order ?? 0), 0);
    const newCat: EstablishmentCategory = {
      id,
      name: cleanName,
      icon: data.icon?.trim() || "🍽️",
      order: data.order !== undefined ? Number(data.order) : maxOrder + 1,
      order_index: data.order !== undefined ? Number(data.order) : maxOrder + 1,
      active: true,
      createdAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO establishment_categories (id, name, icon, order_index, active, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newCat.id,
            newCat.name,
            newCat.icon,
            newCat.order,
            newCat.active ? 1 : 0,
            newCat.createdAt
          )
          .run();
      } catch (err: any) {
        console.error("D1 createEstablishmentCategory error:", err);
      }
    }

    globalStore.establishmentCategories = (globalStore.establishmentCategories || []).filter(
      (c) => c.id !== newCat.id
    );
    globalStore.establishmentCategories.push(newCat);

    return newCat;
  }

  async deleteEstablishmentCategory(id: string): Promise<boolean> {
    await this.ensureTables();
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "DELETE FROM establishment_categories WHERE id = ?"
        ).bind(id).run();
      } catch (e) {
        console.warn("D1 deleteEstablishmentCategory error:", e);
      }
    }

    globalStore.establishmentCategories = (globalStore.establishmentCategories || []).filter(
      (c) => c.id !== id
    );
    return true;
  }

  // ===================== PLATFORM APPEARANCE & SETTINGS (CLOUDFLARE D1 / KV) =====================

  async getPlatformSettings(): Promise<PlatformSettings> {
    const kv = this.getKv();
    if (kv) {
      try {
        const cached = await kv.get("platform:settings");
        if (cached) {
          const parsed = JSON.parse(cached) as PlatformSettings;
          return { ...defaultPlatformSettings, ...parsed };
        }
      } catch (e) {
        console.warn("KV getPlatformSettings error:", e);
      }
    }

    await this.ensureTables();
    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare(
          "SELECT settings_json FROM platform_settings WHERE id = 'main' LIMIT 1"
        ).first<{ settings_json: string }>();
        if (row?.settings_json) {
          const parsed = JSON.parse(row.settings_json) as PlatformSettings;
          const merged = { ...defaultPlatformSettings, ...parsed };
          globalStore.platformSettings = merged;
          if (kv) {
            try {
              await kv.put("platform:settings", JSON.stringify(merged));
            } catch (err) {
              console.warn("KV put platform:settings error:", err);
            }
          }
          return merged;
        }
      } catch (e) {
        console.warn("D1 getPlatformSettings error:", e);
      }
    }

    return { ...globalStore.platformSettings };
  }

  async updatePlatformSettings(partial: Partial<PlatformSettings>): Promise<PlatformSettings> {
    const current = await this.getPlatformSettings();
    const updated: PlatformSettings = {
      ...current,
      ...partial,
      updatedAt: Date.now(),
    };

    globalStore.platformSettings = updated;

    await this.ensureTables();
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO platform_settings (id, settings_json, updated_at) 
           VALUES ('main', ?, ?)
           ON CONFLICT(id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at`
        )
          .bind(JSON.stringify(updated), updated.updatedAt || Date.now())
          .run();
      } catch (e) {
        console.warn("D1 updatePlatformSettings error:", e);
      }
    }

    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put("platform:settings", JSON.stringify(updated));
      } catch (e) {
        console.warn("KV updatePlatformSettings error:", e);
      }
    }

    return updated;
  }

  // ===================== USERS & AUTH =====================

  async authenticateUser(email: string, password: string): Promise<User | null> {
    const cleanEmail = email.trim().toLowerCase();

    // 1. Consulta segura ao Cloudflare D1
    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare(
          "SELECT * FROM users WHERE LOWER(email) = ? AND status = 'active' LIMIT 1"
        )
          .bind(cleanEmail)
          .first<any>();

        if (row) {
          const isValid = await verifyPassword(password, row.password);
          if (isValid) {
            // Se a senha armazenada ainda for texto puro pré-migração, atualiza para hash PBKDF2 transparente
            if (row.password && !String(row.password).startsWith("pbkdf2:")) {
              try {
                const newHash = await hashPassword(password);
                await this.env.DB.prepare("UPDATE users SET password = ? WHERE id = ?")
                  .bind(newHash, row.id)
                  .run();
                const memU = globalStore.users.find((u) => u.id === row.id);
                if (memU) memU.password = newHash;
              } catch (rehashErr) {
                console.warn("Aviso ao atualizar senha legada para PBKDF2:", rehashErr);
              }
            }
            return this.mapUserRow(row);
          }
          // Senha informada não confere com o hash PBKDF2 gravado no D1 -> Rejeita imediatamente
          return null;
        }

        // Se o D1 está ativo e o e-mail não existe no D1, REJEITA imediatamente!
        // Impede que credenciais antigas excluídas do D1 consigam autenticar
        return null;
      } catch (e) {
        console.warn("D1 authenticateUser error:", e);
      }
    }

    // 2. Consulta em memória
    const user = globalStore.users.find(
      (u) =>
        u.email.toLowerCase() === cleanEmail &&
        u.status === "active"
    );

    if (!user) return null;

    const isValid = await verifyPassword(password, user.password || "");
    if (!isValid) return null;

    // Atualiza senha em memória para hash PBKDF2 se ainda for texto puro
    if (user.password && !user.password.startsWith("pbkdf2:")) {
      try {
        user.password = await hashPassword(password);
      } catch {
        // ignore
      }
    }

    // Omit password from return object
    const { password: _, ...safeUser } = user;
    return safeUser as User;
  }

  async verifyUser(email: string, password: string): Promise<User | null> {
    return this.authenticateUser(email, password);
  }

  async getUserById(userId: string): Promise<User | null> {
    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare(
          "SELECT * FROM users WHERE id = ? AND status = 'active' LIMIT 1"
        )
          .bind(userId)
          .first<any>();
        if (row) return this.mapUserRow(row);
      } catch (e) {
        console.warn("D1 getUserById error:", e);
      }
    }

    const user = globalStore.users.find(
      (u) => u.id === userId && u.status === "active"
    );
    if (!user) return null;
    const { password: _, ...safeUser } = user;
    return safeUser as User;
  }

  async createUser(data: {
    email: string;
    password: string;
    name: string;
    role: "super_admin" | "tenant_admin";
    tenantId?: string | null;
  }): Promise<User> {
    const userId = `user-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const hashedPassword = await hashPassword(data.password.trim());
    const newUser: User = {
      id: userId,
      email: data.email.trim().toLowerCase(),
      password: hashedPassword,
      name: data.name.trim(),
      role: data.role,
      tenantId: data.tenantId || null,
      status: "active",
      createdAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO users (id, email, password, name, role, tenant_id, status, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newUser.id,
            newUser.email,
            newUser.password,
            newUser.name,
            newUser.role,
            newUser.tenantId,
            newUser.status,
            newUser.createdAt
          )
          .run();
      } catch (e) {
        console.warn("D1 createUser error:", e);
      }
    }

    globalStore.users.push(newUser);
    const { password: _, ...safeUser } = newUser;
    return safeUser as User;
  }

  async getUsersByTenant(tenantId: string): Promise<User[]> {
    return globalStore.users
      .filter((u) => u.tenantId === tenantId)
      .map(({ password: _, ...rest }) => rest as User);
  }

  async getTenantCredentials(tenantIdOrSlug: string): Promise<{
    userId: string;
    email: string;
    password?: string;
    name: string;
    tenantId: string;
    tenantSlug: string;
    tenantName: string;
  } | null> {
    const tenant = await this.getTenantByIdOrSlug(tenantIdOrSlug);
    if (!tenant) return null;

    let user: any = null;

    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare(
          "SELECT id, email, password, name, tenant_id FROM users WHERE tenant_id = ? AND role = 'tenant_admin' LIMIT 1"
        )
          .bind(tenant.id)
          .first<any>();
        if (row) {
          user = {
            id: row.id,
            email: row.email,
            password: row.password,
            name: row.name,
            tenantId: row.tenant_id,
          };
        }
      } catch (e) {
        console.warn("D1 getTenantCredentials error:", e);
      }
    }

    if (!user) {
      user = globalStore.users.find(
        (u) => u.tenantId === tenant.id && u.role === "tenant_admin"
      );
    }

    if (!user && tenant.email) {
      user = globalStore.users.find(
        (u) => u.email.toLowerCase() === tenant.email.toLowerCase()
      );
    }

    const email = user?.email || tenant.email || `admin@${tenant.slug}.com`;
    // Se a senha for hash PBKDF2, mascara para privacidade
    const rawPass = user?.password || "123456";
    const password = rawPass.startsWith("pbkdf2:") ? "••••••••" : rawPass;
    const userId = user?.id || `user-${tenant.id}`;
    const name = user?.name || `Admin ${tenant.name}`;

    return {
      userId,
      email,
      password,
      name,
      tenantId: tenant.id,
      tenantSlug: tenant.slug,
      tenantName: tenant.name,
    };
  }

  async getAllTenantCredentials(): Promise<
    Array<{
      tenantId: string;
      tenantName: string;
      tenantSlug: string;
      userId: string;
      email: string;
      password?: string;
      name: string;
      status: TenantStatus;
    }>
  > {
    const tenants = await this.getTenants();
    const list = [];
    for (const t of tenants) {
      const creds = await this.getTenantCredentials(t.id);
      if (creds) {
        list.push({
          tenantId: t.id,
          tenantName: t.name,
          tenantSlug: t.slug,
          userId: creds.userId,
          email: creds.email,
          password: creds.password || "••••••••",
          name: creds.name,
          status: t.status,
        });
      }
    }
    return list;
  }

  async updateTenantCredentials(
    tenantIdOrSlug: string,
    email: string,
    password: string,
    name?: string
  ): Promise<{
    success: boolean;
    user: User;
    tenant: Tenant;
    credentials: {
      userId: string;
      email: string;
      password?: string;
      name: string;
      tenantId: string;
      tenantSlug: string;
      tenantName: string;
    };
  }> {
    const tenant = await this.getTenantByIdOrSlug(tenantIdOrSlug);
    if (!tenant) {
      throw new Error("Lanchonete não encontrada.");
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();
    const hashedPassword = await hashPassword(cleanPassword);

    // 1. Atualização persistente no Cloudflare D1 com hash PBKDF2
    if (this.env?.DB) {
      try {
        const existing = await this.env.DB.prepare(
          "SELECT id FROM users WHERE tenant_id = ? AND role = 'tenant_admin' LIMIT 1"
        )
          .bind(tenant.id)
          .first<any>();

        if (existing) {
          await this.env.DB.prepare(
            "UPDATE users SET email = ?, password = ?, name = COALESCE(?, name) WHERE id = ?"
          )
            .bind(cleanEmail, hashedPassword, name || null, existing.id)
            .run();
        } else {
          const newUserId = `user-${tenant.id}-${Date.now()}`;
          await this.env.DB.prepare(
            `INSERT INTO users (id, email, password, name, role, tenant_id, status, created_at)
             VALUES (?, ?, ?, ?, 'tenant_admin', ?, 'active', ?)`
          )
            .bind(
              newUserId,
              cleanEmail,
              hashedPassword,
              name || `Admin ${tenant.name}`,
              tenant.id,
              Date.now()
            )
            .run();
        }

        // Também atualiza o e-mail cadastrado na tabela de tenants
        await this.env.DB.prepare(
          "UPDATE tenants SET email = ?, updated_at = ? WHERE id = ?"
        )
          .bind(cleanEmail, Date.now(), tenant.id)
          .run();
      } catch (e) {
        console.warn("D1 updateTenantCredentials error:", e);
      }
    }

    // 2. Limpeza de cache no Cloudflare KV
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.delete(`tenant:${tenant.id}`);
        await kv.delete(`tenant:${tenant.slug.toLowerCase()}`);
      } catch (e) {
        console.warn("KV delete cache error:", e);
      }
    }

    // 3. Sincronização imediata na memória (MemoryStore) com hash seguro
    let user = globalStore.users.find(
      (u) => u.tenantId === tenant.id && u.role === "tenant_admin"
    );

    if (user) {
      user.email = cleanEmail;
      user.password = hashedPassword;
      if (name) user.name = name;
    } else {
      user = {
        id: `user-${tenant.id}-${Date.now()}`,
        email: cleanEmail,
        password: hashedPassword,
        name: name || `Admin ${tenant.name}`,
        role: "tenant_admin",
        tenantId: tenant.id,
        status: "active",
        createdAt: Date.now(),
      };
      globalStore.users.push(user);
    }

    const memTenant = globalStore.tenants.find((t) => t.id === tenant.id);
    if (memTenant) {
      memTenant.email = cleanEmail;
      memTenant.updatedAt = Date.now();
      if (kv) {
        try {
          await kv.put(`tenant:${memTenant.id}`, JSON.stringify(memTenant));
          await kv.put(`tenant:${memTenant.slug.toLowerCase()}`, JSON.stringify(memTenant));
        } catch (err) {
          console.warn("KV put updated tenant error:", err);
        }
      }
    }

    const { password: _, ...safeUser } = user;
    return {
      success: true,
      user: safeUser as User,
      tenant: memTenant || tenant,
      credentials: {
        userId: user.id,
        email: cleanEmail,
        password: "••••••••",
        name: user.name,
        tenantId: tenant.id,
        tenantSlug: tenant.slug,
        tenantName: tenant.name,
      },
    };
  }

  async updateSuperAdminCredentials(
    userId: string | null | undefined,
    email: string,
    password: string
  ): Promise<User | null> {
    await this.ensureTables();

    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = password.trim();
    const hashedPassword = await hashPassword(cleanPassword);
    const now = Date.now();

    let targetId = userId || "user-superadmin";
    let updatedUser: User | null = null;

    // 1. Cloudflare D1 integration via env.DB com hash seguro PBKDF2
    if (this.env?.DB) {
      try {
        // Localiza os registros existentes com role de Super Admin (suportando maiúsculas e minúsculas)
        const existingSuperAdmins = await this.env.DB.prepare(
          `SELECT id, email, name, role FROM users 
           WHERE UPPER(role) = 'SUPER_ADMIN' OR LOWER(role) = 'super_admin' OR LOWER(role) = 'superadmin' 
           ORDER BY COALESCE(updated_at, 0) DESC, created_at DESC`
        ).all<any>();

        if (existingSuperAdmins?.results && existingSuperAdmins.results.length > 0) {
          // Se foi passado userId e ele existe na lista de super admins, prioriza ele; senão usa o mais recente
          const matched = userId
            ? existingSuperAdmins.results.find((r) => r.id === userId)
            : null;
          targetId = matched ? matched.id : existingSuperAdmins.results[0].id;

          // Remove qualquer outro registro que colida com o novo e-mail ANTES do update para evitar erro de UNIQUE constraint
          await this.env.DB.prepare(
            "DELETE FROM users WHERE LOWER(email) = ? AND id != ?"
          )
            .bind(cleanEmail, targetId)
            .run();

          // 1. SOBRESCREVER REGISTRO EXISTENTE (UPDATE NO D1):
          // Faz EXCLUSIVAMENTE um UPDATE no registro do Super Admin logado no banco D1, sem criar nova linha
          await this.env.DB.prepare(
            `UPDATE users 
             SET email = ?, password = ?, name = COALESCE(name, 'Diretor da Plataforma'), role = 'super_admin', status = 'active', updated_at = ? 
             WHERE id = ?`
          )
            .bind(cleanEmail, hashedPassword, now, targetId)
            .run();
        } else {
          // Se não houver nenhum super_admin cadastrado, tenta localizar por ID ou e-mail
          const existingAny = await this.env.DB.prepare(
            "SELECT id FROM users WHERE id = ? OR LOWER(email) = ? LIMIT 1"
          )
            .bind(targetId, cleanEmail)
            .first<any>();

          if (existingAny) {
            targetId = existingAny.id;
            await this.env.DB.prepare(
              `UPDATE users 
               SET email = ?, password = ?, role = 'super_admin', status = 'active', updated_at = ? 
               WHERE id = ?`
            )
              .bind(cleanEmail, hashedPassword, now, targetId)
              .run();
          } else {
            // Caso excepcional de tabela 100% vazia
            await this.env.DB.prepare(
              `INSERT INTO users (id, email, password, name, role, tenant_id, status, created_at, updated_at) 
               VALUES (?, ?, ?, 'Diretor da Plataforma', 'super_admin', NULL, 'active', ?, ?)`
            )
              .bind(targetId, cleanEmail, hashedPassword, now, now)
              .run();
          }
        }

        // 2. REMOÇÃO COMPLETA DA CREDENCIAL ANTIGA:
        // Limpeza (DELETE) na tabela de usuários para remover QUALQUER registro antigo de Super Admin que não seja a conta nova recém-atualizada.
        // Deve existir APENAS 1 registro na tabela com role = 'SUPER_ADMIN' / 'super_admin'.
        await this.env.DB.prepare(
          `DELETE FROM users 
           WHERE (UPPER(role) = 'SUPER_ADMIN' OR LOWER(role) = 'super_admin' OR LOWER(role) = 'superadmin') 
             AND id != ?`
        )
          .bind(targetId)
          .run();

        // Remove duplicidades de e-mail de outros registros que pudessem colidir com o novo e-mail
        await this.env.DB.prepare(
          "DELETE FROM users WHERE LOWER(email) = ? AND id != ?"
        )
          .bind(cleanEmail, targetId)
          .run();

        // Recupera o registro único e atualizado do D1
        const updatedRow = await this.env.DB.prepare(
          `SELECT * FROM users 
           WHERE (UPPER(role) = 'SUPER_ADMIN' OR LOWER(role) = 'super_admin' OR LOWER(role) = 'superadmin') 
             AND id = ? 
           LIMIT 1`
        )
          .bind(targetId)
          .first<any>();

        if (updatedRow) {
          updatedUser = this.mapUserRow(updatedRow);
        }
      } catch (e) {
        console.warn("D1 updateSuperAdminCredentials error:", e);
      }
    }

    // 3. Sincroniza store em memória garantindo ESTRITAMENTE 1 único Super Admin
    globalStore.users = globalStore.users.filter(
      (u) =>
        !["super_admin", "superadmin", "SUPER_ADMIN"].includes(u.role) &&
        u.email.toLowerCase() !== cleanEmail
    );

    const singleMemUser: User = {
      id: targetId,
      email: cleanEmail,
      password: hashedPassword,
      name: updatedUser?.name || "Diretor da Plataforma",
      role: "super_admin",
      tenantId: null,
      status: "active",
      createdAt: updatedUser?.createdAt || (now - 60 * 86400000),
      updatedAt: now,
    };
    globalStore.users.push(singleMemUser);

    // Atualiza initialUsers para que a credencial antiga seja completamente purgada
    for (const u of initialUsers) {
      if (["super_admin", "superadmin", "SUPER_ADMIN"].includes(u.role)) {
        u.id = targetId;
        u.email = cleanEmail;
        u.password = hashedPassword;
        u.updatedAt = now;
      }
    }

    // Grava persistência no singleton global
    setPersistedSuperAdmin({
      id: targetId,
      email: cleanEmail,
      password: hashedPassword,
      updatedAt: now,
    });

    if (updatedUser) {
      return updatedUser;
    }

    const { password: _, ...safeUser } = singleMemUser;
    return safeUser as User;
  }

  // ===================== PRODUCTS =====================

  async getProductsByTenant(tenantId: string): Promise<Product[]> {
    await this.ensureTables();

    // Resolver tenant para obter ID exato e slug correspondente
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedId = tenant ? tenant.id : tenantId;
    const resolvedSlug = tenant ? tenant.slug : tenantId;

    if (this.env?.DB) {
      try {
        const res = await this.env.DB.prepare(
          "SELECT * FROM products WHERE tenant_id = ? OR tenant_id = ? ORDER BY COALESCE(position, ordem, 0) ASC, created_at DESC"
        )
          .bind(resolvedId, resolvedSlug)
          .all<any>();
        if (res.results && res.results.length > 0) {
          return res.results.map((r: any) => this.mapProductRow(r));
        } else {
          const seeded = initialProducts.filter((p) => p.tenantId === resolvedId || p.tenantId === resolvedSlug);
          if (seeded.length > 0) {
            for (const sp of seeded) {
              await this.insertProductRow(sp);
            }
            return seeded;
          }
        }
      } catch (e) {
        console.warn("D1 getProducts error:", e);
      }
    }

    const memTenant = globalStore.tenants.find((t) => t.id === tenantId || t.slug === tenantId);
    const memId = memTenant ? memTenant.id : resolvedId;
    const memSlug = memTenant ? memTenant.slug : resolvedSlug;

    return globalStore.products
      .filter((p) => p.tenantId === memId || p.tenantId === memSlug)
      .sort((a, b) => (a.position ?? a.ordem ?? 0) - (b.position ?? b.ordem ?? 0));
  }

  async createProduct(tenantId: string, product: Omit<Product, "id" | "tenantId">): Promise<Product> {
    await this.ensureTables();
    const currentProducts = await this.getProductsByTenant(tenantId);
    const maxPosition = currentProducts.reduce(
      (max, p) => Math.max(max, p.position ?? p.ordem ?? 0),
      -1
    );
    const assignedPosition = product.position ?? product.ordem ?? maxPosition + 1;

    const newProduct: Product = {
      ...product,
      id: `prod-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      tenantId,
      available: product.available !== undefined ? Boolean(product.available) : true,
      options: product.options || [],
      addonGroupIds: Array.isArray(product.addonGroupIds) ? product.addonGroupIds : [],
      position: assignedPosition,
      ordem: assignedPosition,
      createdAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO products (id, tenant_id, name, description, price, category, image, available, options_json, addon_group_ids, position, ordem, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newProduct.id,
            newProduct.tenantId,
            newProduct.name,
            newProduct.description,
            newProduct.price,
            newProduct.category,
            newProduct.image || "",
            newProduct.available ? 1 : 0,
            JSON.stringify(newProduct.options || []),
            JSON.stringify(newProduct.addonGroupIds || []),
            newProduct.position ?? 0,
            newProduct.ordem ?? 0,
            newProduct.createdAt
          )
          .run();
      } catch (e) {
        console.warn("D1 createProduct error with addon_group_ids, trying fallback:", e);
        try {
          await this.env.DB.prepare(
            `INSERT INTO products (id, tenant_id, name, description, price, category, image, available, options_json, position, ordem, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              newProduct.id,
              newProduct.tenantId,
              newProduct.name,
              newProduct.description,
              newProduct.price,
              newProduct.category,
              newProduct.image || "",
              newProduct.available ? 1 : 0,
              JSON.stringify(newProduct.options || []),
              newProduct.position ?? 0,
              newProduct.ordem ?? 0,
              newProduct.createdAt
            )
            .run();
        } catch {
          /* ignore */
          void 0;
        }
      }
    }

    globalStore.products.unshift(newProduct);
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`product:${newProduct.id}`, JSON.stringify(newProduct));
        await kv.delete(`products:${tenantId}`);
      } catch (e) {
        console.warn("KV product error:", e);
      }
    }
    return newProduct;
  }

  async updateProduct(productId: string, partial: Partial<Product>): Promise<Product | null> {
    let existing = globalStore.products.find((p) => p.id === productId);

    if (!existing && this.env?.DB) {
      try {
        await this.ensureTables();
        const row = await this.env.DB.prepare("SELECT * FROM products WHERE id = ? LIMIT 1")
          .bind(productId)
          .first<any>();
        if (row) {
          existing = this.mapProductRow(row);
          globalStore.products.push(existing);
        }
      } catch (e) {
        console.warn("D1 get product for update error:", e);
      }
    }

    if (!existing) return null;

    const updated = { ...existing, ...partial };
    const idx = globalStore.products.findIndex((p) => p.id === productId);
    if (idx >= 0) {
      globalStore.products[idx] = updated;
    } else {
      globalStore.products.push(updated);
    }

    if (this.env?.DB) {
      try {
        await this.ensureTables();
        await this.env.DB.prepare(
          `UPDATE products SET name = ?, description = ?, price = ?, category = ?, image = ?, available = ?, options_json = ?, addon_group_ids = ?, position = ?, ordem = ? WHERE id = ?`
        )
          .bind(
            updated.name,
            updated.description,
            updated.price,
            updated.category,
            updated.image,
            updated.available ? 1 : 0,
            JSON.stringify(updated.options || []),
            JSON.stringify(updated.addonGroupIds || []),
            updated.position ?? updated.ordem ?? 0,
            updated.ordem ?? updated.position ?? 0,
            productId
          )
          .run();
      } catch (e) {
        console.warn("D1 updateProduct error with addon_group_ids, trying fallback:", e);
        try {
          await this.env.DB.prepare(
            `UPDATE products SET name = ?, description = ?, price = ?, category = ?, image = ?, available = ?, options_json = ?, position = ?, ordem = ? WHERE id = ?`
          )
            .bind(
              updated.name,
              updated.description,
              updated.price,
              updated.category,
              updated.image,
              updated.available ? 1 : 0,
              JSON.stringify(updated.options || []),
              updated.position ?? updated.ordem ?? 0,
              updated.ordem ?? updated.position ?? 0,
              productId
            )
            .run();
        } catch {
          /* ignore */
          void 0;
        }
      }
    }

    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`product:${updated.id}`, JSON.stringify(updated));
        if (updated.tenantId) {
          await kv.delete(`products:${updated.tenantId}`);
        }
      } catch (e) {
        console.warn("KV sync product error:", e);
      }
    }

    return updated;
  }

  async reorderProducts(tenantId: string, orderedIds: string[]): Promise<boolean> {
    await this.ensureTables();
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedId = tenant ? tenant.id : tenantId;
    const resolvedSlug = tenant ? tenant.slug : tenantId;

    for (let i = 0; i < orderedIds.length; i++) {
      const prodId = orderedIds[i];
      // Atualiza memória
      const prod = globalStore.products.find((p) => p.id === prodId);
      if (prod) {
        prod.position = i;
        prod.ordem = i;
        prod.order = i;
      }
      // Atualiza Cloudflare D1
      if (this.env?.DB) {
        try {
          await this.env.DB.prepare(
            "UPDATE products SET position = ?, ordem = ? WHERE id = ?"
          )
            .bind(i, i, prodId)
            .run();
        } catch (e) {
          console.warn("D1 reorderProduct error:", e);
        }
      }
    }

    // Invalida cache do KV
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.delete(`products:${resolvedId}`);
        await kv.delete(`products:${resolvedSlug}`);
      } catch (e) {
        console.warn("KV invalidate products error:", e);
      }
    }

    return true;
  }

  // ===================== ADDON GROUPS (GRUPOS DE COMPLEMENTOS / ADICIONAIS) =====================

  async getAddonGroupsByTenant(tenantId: string): Promise<AddonGroup[]> {
    await this.ensureTables();
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedId = tenant ? tenant.id : tenantId;
    const resolvedSlug = tenant ? tenant.slug : tenantId;

    if (this.env?.DB) {
      try {
        const res = await this.env.DB.prepare(
          "SELECT * FROM addon_groups WHERE tenant_id = ? OR tenant_id = ? ORDER BY position ASC, created_at ASC"
        )
          .bind(resolvedId, resolvedSlug)
          .all<any>();

        if (res.results && res.results.length > 0) {
          const groups = res.results.map((r: any) => this.mapAddonGroupRow(r));
          // Sincroniza memória
          for (const g of groups) {
            const idx = (globalStore.addonGroups || []).findIndex((x) => x.id === g.id);
            if (idx >= 0) {
              globalStore.addonGroups[idx] = g;
            } else {
              if (!globalStore.addonGroups) globalStore.addonGroups = [];
              globalStore.addonGroups.push(g);
            }
          }
          return groups;
        } else {
          // Se não houver no D1, verifica se há sementes para esse tenant
          const seeded = initialAddonGroups.filter(
            (g) => g.tenantId === resolvedId || g.tenantId === resolvedSlug
          );
          if (seeded.length > 0) {
            for (const sg of seeded) {
              await this.insertAddonGroupRow(sg);
            }
            return seeded;
          }
        }
      } catch (e) {
        console.warn("D1 getAddonGroupsByTenant error:", e);
      }
    }

    const memTenant = globalStore.tenants.find((t) => t.id === tenantId || t.slug === tenantId);
    const memId = memTenant ? memTenant.id : resolvedId;
    const memSlug = memTenant ? memTenant.slug : resolvedSlug;

    return (globalStore.addonGroups || [])
      .filter((g) => g.tenantId === memId || g.tenantId === memSlug)
      .sort((a, b) => (a.position ?? 0) - (b.position ?? 0));
  }

  async getAddonGroupById(groupId: string): Promise<AddonGroup | null> {
    if (!groupId) return null;
    await this.ensureTables();

    if (this.env?.DB) {
      try {
        const row = await this.env.DB.prepare("SELECT * FROM addon_groups WHERE id = ? LIMIT 1")
          .bind(groupId)
          .first<any>();
        if (row) {
          return this.mapAddonGroupRow(row);
        }
      } catch (e) {
        console.warn("D1 getAddonGroupById error:", e);
      }
    }

    return (globalStore.addonGroups || []).find((g) => g.id === groupId) || null;
  }

  async createAddonGroup(
    tenantId: string,
    data: Omit<AddonGroup, "id" | "tenantId">
  ): Promise<AddonGroup> {
    await this.ensureTables();
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedTenantId = tenant ? tenant.id : tenantId;

    const currentGroups = await this.getAddonGroupsByTenant(resolvedTenantId);
    const maxPos = currentGroups.reduce((max, g) => Math.max(max, g.position ?? 0), 0);

    const minSel = Number(data.minSelection ?? 0);
    const maxSel = Number(data.maxSelection ?? 0);

    const newGroup: AddonGroup = {
      id: `ag-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      tenantId: resolvedTenantId,
      name: data.name.trim(),
      description: data.description?.trim() || "",
      minSelection: minSel,
      maxSelection: maxSel,
      required: minSel > 0,
      items: Array.isArray(data.items)
        ? data.items.map((it, idx) => ({
            id: it.id || `ai-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
            name: it.name.trim(),
            price: Number(it.price) || 0,
            available: it.available !== false,
          }))
        : [],
      position: data.position ?? maxPos + 1,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO addon_groups (
            id, tenant_id, name, description, min_selection, max_selection, required, items_json, position, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newGroup.id,
            newGroup.tenantId,
            newGroup.name,
            newGroup.description,
            newGroup.minSelection,
            newGroup.maxSelection,
            newGroup.required ? 1 : 0,
            JSON.stringify(newGroup.items),
            newGroup.position,
            newGroup.createdAt,
            newGroup.updatedAt
          )
          .run();
      } catch (e) {
        console.warn("D1 createAddonGroup error:", e);
      }
    }

    if (!globalStore.addonGroups) {
      globalStore.addonGroups = [];
    }
    globalStore.addonGroups.push(newGroup);

    return newGroup;
  }

  async updateAddonGroup(
    groupId: string,
    partial: Partial<AddonGroup>
  ): Promise<AddonGroup | null> {
    const existing = await this.getAddonGroupById(groupId);
    if (!existing) return null;

    const minSel = partial.minSelection !== undefined ? Number(partial.minSelection) : existing.minSelection;
    const maxSel = partial.maxSelection !== undefined ? Number(partial.maxSelection) : existing.maxSelection;

    const updated: AddonGroup = {
      ...existing,
      ...partial,
      name: partial.name !== undefined ? partial.name.trim() : existing.name,
      description: partial.description !== undefined ? (partial.description || "").trim() : existing.description,
      minSelection: minSel,
      maxSelection: maxSel,
      required: minSel > 0,
      items: Array.isArray(partial.items)
        ? partial.items.map((it, idx) => ({
            id: it.id || `ai-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
            name: it.name.trim(),
            price: Number(it.price) || 0,
            available: it.available !== false,
          }))
        : existing.items,
      updatedAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.ensureTables();
        await this.env.DB.prepare(
          `UPDATE addon_groups SET
            name = ?, description = ?, min_selection = ?, max_selection = ?, required = ?, items_json = ?, position = ?, updated_at = ?
           WHERE id = ?`
        )
          .bind(
            updated.name,
            updated.description || "",
            updated.minSelection,
            updated.maxSelection,
            updated.required ? 1 : 0,
            JSON.stringify(updated.items),
            updated.position ?? 0,
            updated.updatedAt,
            groupId
          )
          .run();
      } catch (e) {
        console.warn("D1 updateAddonGroup error:", e);
      }
    }

    const idx = (globalStore.addonGroups || []).findIndex((g) => g.id === groupId);
    if (idx >= 0) {
      globalStore.addonGroups[idx] = updated;
    } else {
      globalStore.addonGroups.push(updated);
    }

    return updated;
  }

  async deleteAddonGroup(groupId: string): Promise<boolean> {
    await this.ensureTables();

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare("DELETE FROM addon_groups WHERE id = ?")
          .bind(groupId)
          .run();
      } catch (e) {
        console.warn("D1 deleteAddonGroup error:", e);
      }
    }

    globalStore.addonGroups = (globalStore.addonGroups || []).filter((g) => g.id !== groupId);

    // Também desvincula dos produtos que tinham este grupo
    for (const p of globalStore.products) {
      if (p.addonGroupIds && p.addonGroupIds.includes(groupId)) {
        p.addonGroupIds = p.addonGroupIds.filter((id) => id !== groupId);
        await this.updateProduct(p.id, { addonGroupIds: p.addonGroupIds });
      }
    }

    return true;
  }

  // ===================== CATEGORIES =====================

  async getCategoriesByTenant(tenantId: string): Promise<Category[]> {
    await this.ensureTables();
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedId = tenant ? tenant.id : tenantId;
    const resolvedSlug = tenant ? tenant.slug : tenantId;

    let d1Categories: Category[] = [];
    if (this.env?.DB) {
      try {
        const res = await this.env.DB.prepare(
          "SELECT * FROM categories WHERE tenant_id = ? OR tenant_id = ? OR tenant_id IS NULL OR tenant_id = '' ORDER BY order_index ASC, created_at ASC"
        )
          .bind(resolvedId, resolvedSlug)
          .all<any>();
        if (res.results && res.results.length > 0) {
          d1Categories = res.results.map((r: any) => ({
            id: r.id,
            tenantId: r.tenant_id,
            name: r.name,
            icon: r.icon || "🍽️",
            order: Number(r.order_index) || 0,
            order_index: Number(r.order_index) || 0,
            createdAt: Number(r.created_at) || Date.now(),
          }));
        }
      } catch (e) {
        console.warn("D1 getCategories error:", e);
      }
    }

    // Combinar categorias em memória e categorias padrões
    const memCategories = globalStore.categories || [];
    const tenantMemCats = memCategories.filter(
      (c: Category) => !c.tenantId || c.tenantId === resolvedId || c.tenantId === resolvedSlug
    );

    const combinedMap = new Map<string, Category>();

    // 1. Categorias padrões
    defaultCategories.forEach((dc) => {
      combinedMap.set(dc.id.toLowerCase(), { ...dc });
    });

    // 2. Categorias do memory store
    tenantMemCats.forEach((mc: Category) => {
      combinedMap.set(mc.id.toLowerCase(), { ...mc });
    });

    // 3. Categorias vindas do banco de dados D1
    d1Categories.forEach((dc: Category) => {
      combinedMap.set(dc.id.toLowerCase(), { ...dc });
    });

    // 4. Categorias referenciadas em produtos existentes
    const products = await this.getProductsByTenant(tenantId);
    products.forEach((p) => {
      if (p.category && !combinedMap.has(p.category.toLowerCase())) {
        combinedMap.set(p.category.toLowerCase(), {
          id: p.category.toLowerCase(),
          name: p.category.charAt(0).toUpperCase() + p.category.slice(1),
          icon: "🍽️",
          tenantId: resolvedId,
          order: 99,
          createdAt: Date.now(),
        });
      }
    });

    return Array.from(combinedMap.values()).sort(
      (a, b) => (a.order ?? a.order_index ?? 0) - (b.order ?? b.order_index ?? 0)
    );
  }

  async createCategory(
    tenantId: string,
    data: { name: string; icon?: string }
  ): Promise<Category> {
    await this.ensureTables();
    const tenant = await this.getTenantByIdOrSlug(tenantId);
    const resolvedId = tenant ? tenant.id : tenantId;
    const cleanName = data.name.trim();

    if (!cleanName) {
      throw new Error("O nome da categoria não pode ser vazio.");
    }

    // Verificar se já existe categoria com o mesmo nome (evitando duplicatas se já existir)
    const existingList = await this.getCategoriesByTenant(tenantId);
    const existing = existingList.find(
      (c) => c.name.toLowerCase() === cleanName.toLowerCase()
    );
    if (existing) {
      return existing;
    }

    // Gerar ID seguro
    const slugBase = globalStore.slugify(cleanName) || `cat-${Date.now()}`;
    const id = existingList.some((c) => c.id === slugBase)
      ? `${slugBase}-${Date.now().toString(36).slice(-4)}`
      : slugBase;

    const newCategory: Category = {
      id,
      tenantId: resolvedId,
      name: cleanName,
      icon: data.icon || "🍽️",
      order: existingList.length + 1,
      order_index: existingList.length + 1,
      createdAt: Date.now(),
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO categories (id, tenant_id, name, icon, order_index, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newCategory.id,
            newCategory.tenantId,
            newCategory.name,
            newCategory.icon,
            newCategory.order_index,
            newCategory.createdAt
          )
          .run();
      } catch (e) {
        console.warn("D1 createCategory error:", e);
      }
    }

    if (!globalStore.categories) {
      globalStore.categories = [...defaultCategories];
    }
    globalStore.categories.push(newCategory);

    return newCategory;
  }

  async deleteProduct(productId: string): Promise<boolean> {
    const existing = globalStore.products.find((p) => p.id === productId);
    globalStore.products = globalStore.products.filter((p) => p.id !== productId);
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare("DELETE FROM products WHERE id = ?").bind(productId).run();
      } catch (e) {
        console.warn("D1 deleteProduct error:", e);
      }
    }
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.delete(`product:${productId}`);
        if (existing?.tenantId) {
          await kv.delete(`products:${existing.tenantId}`);
        }
      } catch (e) {
        console.warn("KV delete product error:", e);
      }
    }
    return true;
  }

  // ===================== ORDERS =====================

  async getOrdersByTenant(tenantId: string): Promise<Order[]> {
    if (!tenantId || !tenantId.trim()) {
      return [];
    }
    const cleanTenantId = tenantId.trim();

    let resolvedTenantId = cleanTenantId;
    let resolvedTenantSlug = cleanTenantId;
    try {
      const tenant = await this.getTenantByIdOrSlug(cleanTenantId);
      if (tenant) {
        resolvedTenantId = tenant.id;
        resolvedTenantSlug = tenant.slug || cleanTenantId;
      }
    } catch {
      // ignore
    }

    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const res = await this.env.DB.prepare(
          "SELECT * FROM orders WHERE tenant_id = ? OR tenant_id = ? ORDER BY created_at DESC, id DESC"
        )
          .bind(resolvedTenantId, resolvedTenantSlug)
          .all<any>();
        if (res.results) {
          return res.results.map((r: any) => this.mapOrderRow(r));
        }
      } catch (e) {
        console.warn("D1 getOrders error:", e);
      }
    }

    return (globalStore.orders || [])
      .filter(
        (o) =>
          o &&
          (o.tenantId === cleanTenantId ||
            o.tenantId === resolvedTenantId ||
            o.tenantId === resolvedTenantSlug)
      )
      .sort((a, b) => {
        const timeA = typeof a.createdAt === "number" ? a.createdAt : new Date(a.createdAt).getTime() || 0;
        const timeB = typeof b.createdAt === "number" ? b.createdAt : new Date(b.createdAt).getTime() || 0;
        return timeB - timeA;
      });
  }

  async getAllOrders(): Promise<Order[]> {
    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const res = await this.env.DB.prepare(
          "SELECT * FROM orders ORDER BY created_at DESC"
        ).all<any>();
        if (res.results) {
          return res.results.map((r: any) => this.mapOrderRow(r));
        }
      } catch (e) {
        console.warn("D1 getAllOrders error:", e);
      }
    }

    return [...globalStore.orders].sort(
      (a, b) => (Number(b.createdAt) || 0) - (Number(a.createdAt) || 0)
    );
  }

  async getOrderById(orderId: string): Promise<Order | null> {
    if (!orderId) return null;
    let decoded = String(orderId).trim();
    try {
      decoded = decodeURIComponent(decoded);
    } catch {
      // ignore
    }
    const cleanId = decoded.startsWith("#") ? decoded : `#${decoded}`;
    const rawId = decoded.replace(/^#/, "");

    // 1. D1 Database query estrita por ID
    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const row = await this.env.DB.prepare(
          "SELECT * FROM orders WHERE id = ? OR id = ? OR id = ? OR id = ? LIMIT 1"
        )
          .bind(orderId, decoded, cleanId, rawId)
          .first<any>();
        if (row) {
          return this.mapOrderRow(row);
        }
      } catch (e) {
        console.warn("D1 getOrderById error:", e);
      }
    }

    // 2. Cloudflare KV cache query
    const kv = this.getKv();
    if (kv) {
      try {
        const cached =
          (await kv.get(`order:${cleanId}`)) ||
          (await kv.get(`order:${rawId}`)) ||
          (await kv.get(`order:${decoded}`)) ||
          (await kv.get(`order:${orderId}`));
        if (cached) return JSON.parse(cached) as Order;
      } catch (e) {
        console.warn("KV get order error:", e);
      }
    }

    // 3. Fallback memory query estrita por ID
    const found = globalStore.orders.find(
      (o) =>
        o.id === orderId ||
        o.id === decoded ||
        o.id === cleanId ||
        o.id === rawId ||
        (o.id && o.id.replace(/^#/, "") === rawId)
    );
    return found || null;
  }

  async getOrderByIdempotencyKey(key: string, maxAgeMs = 5 * 60 * 1000): Promise<Order | null> {
    if (!key || typeof key !== "string" || !key.trim()) return null;
    const cleanKey = key.trim();
    const minTimestamp = Date.now() - maxAgeMs;

    // 1. Checagem em memória (instantânea, 0ms)
    const memFound = globalStore.orders.find(
      (o) =>
        (o.idempotencyKey === cleanKey ||
          (o as any).idempotency_key === cleanKey ||
          (o as any).cart_id === cleanKey) &&
        Date.now() - (o.createdAt || 0) <= maxAgeMs
    );
    if (memFound) return memFound;

    // 2. Checagem em KV (rápida, ~10ms)
    const kv = this.getKv();
    if (kv) {
      try {
        const cached = await kv.get(`idempotency:${cleanKey}`);
        if (cached) {
          const order = JSON.parse(cached) as Order;
          if (order && Date.now() - (order.createdAt || 0) <= maxAgeMs) {
            return order;
          }
        }
      } catch {
        // Silencioso
      }
    }

    // 3. Consulta rápida no Cloudflare D1 com timeout rígido de 1.5s (NUNCA chama ensureTables)
    if (this.env?.DB) {
      try {
        const d1QueryPromise = this.env.DB.prepare(
          "SELECT * FROM orders WHERE idempotency_key = ? AND created_at >= ? ORDER BY created_at DESC LIMIT 1"
        )
          .bind(cleanKey, minTimestamp)
          .first<any>();

        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 1500));
        const row = await Promise.race([d1QueryPromise, timeoutPromise]);
        if (row) {
          return this.mapOrderRow(row);
        }
      } catch (e) {
        console.warn("D1 getOrderByIdempotencyKey timeout/erro (ignorado):", e);
      }
    }

    return null;
  }

  async createOrder(tenantId: string, orderData: Omit<Order, "id" | "tenantId" | "createdAt">): Promise<Order> {
    const rawCardType = (orderData as any).cardType || (orderData as any).card_type || undefined;
    const rawPaymentDetails = (orderData as any).paymentDetails || (orderData as any).payment_details || undefined;
    const rawReceipt = (orderData as any).pixReceiptUrl || (orderData as any).pix_receipt_url || (orderData as any).receipt || undefined;
    const rawLocationUrl = (orderData as any).location_url || (orderData as any).locationUrl || undefined;
    const rawTableNumber = (orderData as any).tableNumber || (orderData as any).table_number || (orderData as any).numeroMesa || (orderData as any).table || (orderData as any).mesa || undefined;
    const cleanTableNumber = rawTableNumber && typeof rawTableNumber === "string" && rawTableNumber.trim() ? rawTableNumber.trim() : undefined;
    const rawIdempotency = (orderData as any).idempotencyKey || (orderData as any).idempotency_key || (orderData as any).cart_id || (orderData as any).cartId || undefined;
    const cleanIdempotencyKey = rawIdempotency && typeof rawIdempotency === "string" && rawIdempotency.trim() ? rawIdempotency.trim() : undefined;

    const newOrder: Order = {
      ...orderData,
      id: `#${Math.floor(1000 + Math.random() * 9000)}`,
      tenantId,
      cardType: rawCardType,
      paymentDetails: rawPaymentDetails,
      pixReceiptUrl: rawReceipt,
      pix_receipt_url: rawReceipt,
      location_url: rawLocationUrl,
      locationUrl: rawLocationUrl,
      tipo_pedido: resolveTipoPedido((orderData as any).orderType, cleanTableNumber),
      tableNumber: cleanTableNumber,
      table_number: cleanTableNumber,
      mesa: cleanTableNumber,
      table: cleanTableNumber,
      idempotencyKey: cleanIdempotencyKey,
      idempotency_key: cleanIdempotencyKey,
      cart_id: cleanIdempotencyKey,
      createdAt: Date.now(),
      statusHistory: [{ status: orderData.status, timestamp: Date.now() }],
    };

    // 1. Persiste imediatamente na memória global para resposta sub-milissegundo
    globalStore.orders.unshift(newOrder);

    // 2. Gravação direta e atômica no Cloudflare D1 com timeout interno rígido (máx 3.5s)
    let _d1Saved = false;
    if (this.env?.DB) {
      try {
        const d1InsertPromise = this.env.DB.prepare(
          `INSERT INTO orders (
            id, tenant_id, customer_name, customer_phone, order_type, table_number, payment_method,
            card_type, payment_details, pix_receipt_url, location_url,
            address_json, change_for, subtotal, delivery_fee, total, status,
            items_json, status_history_json, idempotency_key, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newOrder.id,
            newOrder.tenantId,
            newOrder.customerName,
            newOrder.customerPhone,
            newOrder.orderType,
            cleanTableNumber || "",
            newOrder.paymentMethod,
            newOrder.cardType || null,
            newOrder.paymentDetails || null,
            newOrder.pixReceiptUrl || newOrder.pix_receipt_url || null,
            newOrder.location_url || newOrder.locationUrl || null,
            JSON.stringify(newOrder.address || {}),
            newOrder.changeFor || "",
            newOrder.subtotal,
            newOrder.deliveryFee,
            newOrder.total,
            newOrder.status,
            JSON.stringify(newOrder.items || []),
            JSON.stringify(newOrder.statusHistory || []),
            cleanIdempotencyKey || "",
            newOrder.createdAt
          )
          .run();

        const insertTimeoutPromise = new Promise<{ timeout: true }>((resolve) =>
          setTimeout(() => resolve({ timeout: true }), 3500)
        );

        const result: any = await Promise.race([d1InsertPromise, insertTimeoutPromise]);
        if (result && !result.timeout) {
          _d1Saved = true;
        } else if (result?.timeout) {
          console.warn("[D1] Timeout de 3.5s no INSERT primário de orders, prosseguindo com fallback de memória");
        }
      } catch (insertErr) {
        console.warn("[D1] Falha no insert primário, tentando fallback de compatibilidade de schema:", insertErr);
        try {
          const fallbackPromise = this.env.DB.prepare(
            `INSERT INTO orders (
              id, tenant_id, customer_name, customer_phone, order_type, table_number, payment_method,
              card_type, payment_details, pix_receipt_url, location_url,
              address_json, change_for, subtotal, delivery_fee, total, status,
              items_json, status_history_json, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
            .bind(
              newOrder.id,
              newOrder.tenantId,
              newOrder.customerName,
              newOrder.customerPhone,
              newOrder.orderType,
              cleanTableNumber || "",
              newOrder.paymentMethod,
              newOrder.cardType || null,
              newOrder.paymentDetails || null,
              newOrder.pixReceiptUrl || newOrder.pix_receipt_url || null,
              newOrder.location_url || newOrder.locationUrl || null,
              JSON.stringify(newOrder.address || {}),
              newOrder.changeFor || "",
              newOrder.subtotal,
              newOrder.deliveryFee,
              newOrder.total,
              newOrder.status,
              JSON.stringify(newOrder.items || []),
              JSON.stringify(newOrder.statusHistory || []),
              newOrder.createdAt
            )
            .run();

          const fbTimeout = new Promise<{ timeout: true }>((resolve) =>
            setTimeout(() => resolve({ timeout: true }), 2000)
          );
          const fbRes: any = await Promise.race([fallbackPromise, fbTimeout]);
          if (fbRes && !fbRes.timeout) {
            _d1Saved = true;
          }
        } catch (fbErr) {
          console.warn("[D1] Erro no fallback de insert:", fbErr);
        }
      }
    }

    // 3. Execução em SEGUNDO PLANO (Background Tasks) para não bloquear a resposta rápida ao cliente
    const runBackgroundTasks = async () => {
      // A. Cache de alta disponibilidade no Cloudflare KV
      const kv = this.getKv();
      if (kv) {
        try {
          await kv.put(`order:${newOrder.id}`, JSON.stringify(newOrder));
          const cleanId = newOrder.id.replace(/^#/, "");
          await kv.put(`order:${cleanId}`, JSON.stringify(newOrder));
          if (cleanIdempotencyKey) {
            await kv.put(`idempotency:${cleanIdempotencyKey}`, JSON.stringify(newOrder), { expirationTtl: 300 });
          }
          await kv.put(`tenant_orders_version:${newOrder.tenantId}`, Date.now().toString());
        } catch (kvErr) {
          console.warn("[Background] Erro ao gravar KV:", kvErr);
        }
      }

      // B. Gravação assíncrona dos itens do pedido no D1
      if (this.env?.DB && newOrder.items && newOrder.items.length > 0) {
        for (const item of newOrder.items) {
          try {
            const oiId = item.id || `oi-${newOrder.id}-${Math.random().toString(36).substring(2, 7)}`;
            const pId = item.product?.id || `p-${Math.random().toString(36).substring(2, 7)}`;
            const pName = item.product?.name || (item as any)?.name || "Lanche";
            const pPrice = Number(item.product?.price ?? (item as any)?.price) || 0;
            const pImg = item.product?.image || (item as any)?.image || "";
            const pQty = Number(item.quantity) || 1;
            const optJson = JSON.stringify(item.selectedOptions || []);
            await this.env.DB.prepare(
              `INSERT INTO order_items (
                id, order_id, tenant_id, product_id, name, price, quantity, image, options_json, created_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
            )
              .bind(
                oiId,
                newOrder.id,
                newOrder.tenantId,
                pId,
                pName,
                pPrice,
                pQty,
                pImg,
                optJson,
                newOrder.createdAt
              )
              .run();
          } catch (itemErr) {
            console.warn("[Background] Erro ao gravar order_item:", itemErr);
          }
        }
      }

      // C. Auto-cadastro e atualização do cliente vinculado à loja
      try {
        await this.saveOrUpdateCustomerFromOrder(tenantId, newOrder);
      } catch (custErr) {
        console.warn("[Background] Auto-register customer error:", custErr);
      }

    };

    // Notifica o painel do lojista NA HORA (Durable Object -> SSE), sem esperar KV/itens/cliente
    try {
      await publishOrderEvent(this.env, newOrder, true);
    } catch (eventErr) {
      console.warn("Error emitting new order event:", eventErr);
    }

    // Tarefas secundárias em segundo plano; waitUntil impede que o Workers as cancele após a resposta
    const backgroundPromise = runBackgroundTasks().catch((bgErr) => {
      console.warn("[Background] Falha geral nas tarefas secundárias:", bgErr);
    });
    this.ctx?.waitUntil(backgroundPromise);

    return newOrder;
  }

  async updateOrderStatus(orderId: string, status: OrderStatus | string): Promise<Order | null> {
    if (!orderId) return null;
    let decoded = String(orderId).trim();
    try {
      decoded = decodeURIComponent(decoded);
    } catch {
      // ignore
    }
    const cleanId = decoded.startsWith("#") ? decoded : `#${decoded}`;
    const rawId = decoded.replace(/^#/, "");

    // 1. Obtém o pedido atual do D1, KV ou memória
    const order = await this.getOrderById(orderId);
    if (!order) return null;

    order.status = status as OrderStatus;
    if (!order.statusHistory) {
      order.statusHistory = [];
    }
    order.statusHistory.push({ status: status as OrderStatus, timestamp: Date.now() });

    // 2. Persiste imediatamente de forma síncrona no Cloudflare D1
    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          "UPDATE orders SET status = ?, status_history_json = ? WHERE id = ? OR id = ? OR id = ? OR id = ?"
        )
          .bind(status, JSON.stringify(order.statusHistory), order.id, decoded, cleanId, rawId)
          .run();
      } catch (e) {
        console.warn("D1 updateOrderStatus error:", e);
      }
    }

    // 3. Publica o evento em tempo real IMEDIATAMENTE após gravar no D1
    //    (Durable Object -> SSE do cliente e do painel, em qualquer isolate)
    try {
      await publishOrderEvent(this.env, order);
    } catch (e) {
      console.warn("Error emitting order event:", e);
    }

    // 4. Atualiza memória local do isolate
    const memIndex = globalStore.orders.findIndex(
      (o) => o.id === order.id || o.id === decoded || o.id === cleanId || o.id === rawId || (o.id && o.id.replace(/^#/, "") === rawId)
    );
    if (memIndex >= 0) {
      globalStore.orders[memIndex] = order;
    } else {
      globalStore.orders.unshift(order);
    }

    // 5. Cache KV em paralelo e fora do caminho crítico (não atrasa mais a resposta nem o evento)
    const kv = this.getKv();
    if (kv) {
      const serialized = JSON.stringify(order);
      const kvTask = Promise.all([
        kv.put(`order:${order.id}`, serialized),
        kv.put(`order:${cleanId}`, serialized),
        kv.put(`order:${rawId}`, serialized),
        kv.put(
          `order_status:${rawId}`,
          JSON.stringify({ orderId: order.id, status: order.status, updatedAt: Date.now() })
        ),
        order.tenantId
          ? kv.put(`tenant_orders_version:${order.tenantId}`, Date.now().toString())
          : Promise.resolve(),
      ]).catch((e) => console.warn("KV update order error:", e));
      if (this.ctx) {
        this.ctx.waitUntil(kvTask);
      } else {
        await kvTask;
      }
    }

    return order;
  }

  // ===================== STATS =====================

  async getPlatformStats(): Promise<{
    totalTenants: number;
    activeTenants: number;
    inactiveTenants: number;
    totalOrders: number;
    totalRevenue: number;
  }> {
    const tenants = await this.getTenants();
    const allOrders = globalStore.orders;
    const active = tenants.filter((t) => t.status === "active").length;
    const totalRev = allOrders.reduce((sum, o) => sum + (o.total || 0), 0);

    return {
      totalTenants: tenants.length,
      activeTenants: active,
      inactiveTenants: tenants.length - active,
      totalOrders: allOrders.length,
      totalRevenue: totalRev,
    };
  }

  // ===================== RELATÓRIO FINANCEIRO (D1 / MEMÓRIA) =====================

  async getFinancialReport(
    tenantId: string,
    options?: {
      month?: number;
      year?: number;
      startDate?: string;
      endDate?: string;
    }
  ): Promise<FinancialReportData> {
    const now = new Date();
    const targetYear = options?.year ? Number(options.year) : now.getFullYear();
    const targetMonth = options?.month ? Number(options.month) : now.getMonth() + 1;

    const monthNamesPt = [
      "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
      "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];
    const daysOfWeekPt = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

    let periodStartMs: number;
    let periodEndMs: number;
    let formattedStartDate: string;
    let formattedEndDate: string;
    let isCustomRange = false;

    if (options?.startDate && options?.endDate) {
      isCustomRange = true;
      formattedStartDate = options.startDate;
      formattedEndDate = options.endDate;
      periodStartMs = new Date(`${options.startDate}T00:00:00.000`).getTime();
      periodEndMs = new Date(`${options.endDate}T23:59:59.999`).getTime();
    } else {
      const daysInMonth = new Date(targetYear, targetMonth, 0).getDate();
      const startD = new Date(targetYear, targetMonth - 1, 1, 0, 0, 0, 0);
      const endD = new Date(targetYear, targetMonth - 1, daysInMonth, 23, 59, 59, 999);
      periodStartMs = startD.getTime();
      periodEndMs = endD.getTime();
      const mStr = String(targetMonth).padStart(2, "0");
      formattedStartDate = `${targetYear}-${mStr}-01`;
      formattedEndDate = `${targetYear}-${mStr}-${String(daysInMonth).padStart(2, "0")}`;
    }

    // Limites do dia de hoje (00:00 às 23:59:59.999)
    const todayStartMs = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0).getTime();
    const todayEndMs = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999).getTime();

    const isCompletedStatus = (status: string) => {
      if (!status) return false;
      const s = status.trim().toLowerCase();
      return (
        s === "done" ||
        s === "concluido" ||
        s === "concluído" ||
        s === "entregue" ||
        s === "finalizado" ||
        // Etapa final única do lojista: "Pronto / Concluir" (pronto, saiu p/ entrega)
        s === "pronto" ||
        s === "ready" ||
        s === "saiu_para_entrega" ||
        s === "delivering"
      );
    };

    let periodCompletedOrders: Order[] = [];
    let todayCompletedOrdersList: Order[] = [];

    // 1. Tenta recuperar do Cloudflare D1
    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const periodRes = await this.env.DB.prepare(`
          SELECT * FROM orders
          WHERE tenant_id = ?
            AND UPPER(status) IN ('DONE', 'CONCLUÍDO', 'CONCLUIDO', 'ENTREGUE', 'FINALIZADO', 'PRONTO', 'READY', 'SAIU_PARA_ENTREGA', 'DELIVERING')
            AND created_at >= ? AND created_at <= ?
          ORDER BY created_at DESC
        `)
          .bind(tenantId, periodStartMs, periodEndMs)
          .all<any>();

        if (periodRes.results && periodRes.results.length > 0) {
          periodCompletedOrders = periodRes.results.map((r: any) => this.mapOrderRow(r));
        }

        const todayRes = await this.env.DB.prepare(`
          SELECT * FROM orders
          WHERE tenant_id = ?
            AND UPPER(status) IN ('DONE', 'CONCLUÍDO', 'CONCLUIDO', 'ENTREGUE', 'FINALIZADO', 'PRONTO', 'READY', 'SAIU_PARA_ENTREGA', 'DELIVERING')
            AND created_at >= ? AND created_at <= ?
          ORDER BY created_at DESC
        `)
          .bind(tenantId, todayStartMs, todayEndMs)
          .all<any>();

        if (todayRes.results && todayRes.results.length > 0) {
          todayCompletedOrdersList = todayRes.results.map((r: any) => this.mapOrderRow(r));
        }
      } catch (e) {
        console.warn("D1 getFinancialReport error:", e);
      }
    }

    // 2. Fallback em memória (Store global)
    if (periodCompletedOrders.length === 0) {
      const tenantOrders = globalStore.orders.filter(
        (o) =>
          o.tenantId === tenantId ||
          (tenantId === "marcelino" && o.tenantId === "tenant-ms-preparacoes") ||
          (tenantId === "tenant-ms-preparacoes" && o.tenantId === "marcelino")
      );
      periodCompletedOrders = tenantOrders.filter(
        (o) => isCompletedStatus(o.status) && o.createdAt >= periodStartMs && o.createdAt <= periodEndMs
      );
      todayCompletedOrdersList = tenantOrders.filter(
        (o) => isCompletedStatus(o.status) && o.createdAt >= todayStartMs && o.createdAt <= todayEndMs
      );
    } else if (todayCompletedOrdersList.length === 0) {
      const tenantOrders = globalStore.orders.filter(
        (o) =>
          o.tenantId === tenantId ||
          (tenantId === "marcelino" && o.tenantId === "tenant-ms-preparacoes") ||
          (tenantId === "tenant-ms-preparacoes" && o.tenantId === "marcelino")
      );
      todayCompletedOrdersList = tenantOrders.filter(
        (o) => isCompletedStatus(o.status) && o.createdAt >= todayStartMs && o.createdAt <= todayEndMs
      );
    }

    // Ordenar pedidos do período por data decrescente (mais recentes primeiro)
    periodCompletedOrders.sort((a, b) => b.createdAt - a.createdAt);

    // Cálculos de métricas principais solicitadas
    const monthRevenue = periodCompletedOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
    const monthCompletedOrders = periodCompletedOrders.length;
    const averageTicket = monthCompletedOrders > 0 ? monthRevenue / monthCompletedOrders : 0;

    const todayRevenue = todayCompletedOrdersList.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
    const todayCompletedOrders = todayCompletedOrdersList.length;

    let deliveredCount = 0;
    let pickupCount = 0;
    let deliveryFeeTotal = 0;

    periodCompletedOrders.forEach((o) => {
      if (o.orderType === "delivery" || (o as any).delivery_type === "delivery") {
        deliveredCount++;
        deliveryFeeTotal += Number(o.deliveryFee) || 0;
      } else {
        pickupCount++;
      }
    });

    // Mapeamento diário para gráfico de rendimento
    const dailyMap = new Map<string, { revenue: number; count: number; dateObj: Date }>();

    if (isCustomRange) {
      const cur = new Date(periodStartMs);
      const end = new Date(periodEndMs);
      while (cur <= end) {
        const y = cur.getFullYear();
        const m = String(cur.getMonth() + 1).padStart(2, "0");
        const d = String(cur.getDate()).padStart(2, "0");
        const key = `${y}-${m}-${d}`;
        dailyMap.set(key, { revenue: 0, count: 0, dateObj: new Date(cur) });
        cur.setDate(cur.getDate() + 1);
      }
    } else {
      const daysInMonth = new Date(targetYear, targetMonth, 0).getDate();
      for (let day = 1; day <= daysInMonth; day++) {
        const dStr = String(day).padStart(2, "0");
        const mStr = String(targetMonth).padStart(2, "0");
        const key = `${targetYear}-${mStr}-${dStr}`;
        const dateObj = new Date(targetYear, targetMonth - 1, day, 12, 0, 0);
        dailyMap.set(key, { revenue: 0, count: 0, dateObj });
      }
    }

    // Acumula os pedidos nos seus respectivos dias
    periodCompletedOrders.forEach((o) => {
      const oDate = new Date(o.createdAt);
      const y = oDate.getFullYear();
      const m = String(oDate.getMonth() + 1).padStart(2, "0");
      const d = String(oDate.getDate()).padStart(2, "0");
      const key = `${y}-${m}-${d}`;

      const existing = dailyMap.get(key);
      if (existing) {
        existing.revenue += Number(o.total) || 0;
        existing.count += 1;
      } else {
        dailyMap.set(key, { revenue: Number(o.total) || 0, count: 1, dateObj: oDate });
      }
    });

    const dailyRevenue: DailyRevenueItem[] = Array.from(dailyMap.entries()).map(([dateStr, item]) => {
      const dayNum = item.dateObj.getDate();
      const dayOfWeekStr = daysOfWeekPt[item.dateObj.getDay()] || "";
      return {
        day: dayNum,
        date: dateStr,
        dayOfWeek: dayOfWeekStr,
        revenue: Math.round(item.revenue * 100) / 100,
        ordersCount: item.count,
      };
    });

    // Detalhamento por método de pagamento
    const paymentMap: Record<string, { total: number; count: number }> = {
      pix: { total: 0, count: 0 },
      card: { total: 0, count: 0 },
      cash: { total: 0, count: 0 },
    };

    periodCompletedOrders.forEach((o) => {
      const method = (o.paymentMethod || "pix").toLowerCase();
      if (!paymentMap[method]) {
        paymentMap[method] = { total: 0, count: 0 };
      }
      paymentMap[method].total += Number(o.total) || 0;
      paymentMap[method].count += 1;
    });

    const paymentLabels: Record<string, string> = {
      pix: "PIX",
      card: "Cartão (Crédito/Débito)",
      cash: "Dinheiro em Espécie",
    };

    const paymentBreakdown: PaymentBreakdownItem[] = Object.entries(paymentMap)
      .filter(([_, val]) => val.count > 0)
      .map(([method, val]) => ({
        method,
        label: paymentLabels[method] || method.toUpperCase(),
        total: Math.round(val.total * 100) / 100,
        count: val.count,
        percent: monthRevenue > 0 ? Math.round((val.total / monthRevenue) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.total - a.total);

    return {
      period: {
        month: targetMonth,
        year: targetYear,
        monthName: monthNamesPt[targetMonth - 1] || `Mês ${targetMonth}`,
        startDate: formattedStartDate,
        endDate: formattedEndDate,
      },
      metrics: {
        todayRevenue: Math.round(todayRevenue * 100) / 100,
        monthRevenue: Math.round(monthRevenue * 100) / 100,
        monthCompletedOrders,
        averageTicket: Math.round(averageTicket * 100) / 100,
        todayCompletedOrders,
        deliveredCount,
        pickupCount,
        deliveryFeeTotal: Math.round(deliveryFeeTotal * 100) / 100,
      },
      dailyRevenue,
      paymentBreakdown,
      orders: periodCompletedOrders,
    };
  }

  // Row mappers for D1 SQL
  private mapTenantRow(row: any): Tenant {
    const seedTenant = initialTenants.find((it) => it.id === row.id || it.slug === row.slug);
    const overrides = getPersistedTenantOverrides();
    const ov = overrides[row.id] || overrides[row.slug];
    const resolvedBusinessType =
      (row.category && String(row.category).trim() !== "")
        ? String(row.category).trim()
        : (row.category_id && String(row.category_id).trim() !== "")
        ? String(row.category_id).trim()
        : (row.business_type && String(row.business_type).trim() !== "")
        ? String(row.business_type).trim()
        : ov?.businessType || ov?.category || seedTenant?.businessType || "Hambúrgueres";

    return {
      id: row.id,
      name: row.name || "Estabelecimento",
      slug: row.slug || row.id,
      email: row.email || "",
      phone: row.phone || "",
      whatsapp: row.whatsapp || "5511999999999",
      pixKey: row.pix_key || row.email || "",
      pixKeyType: row.pix_key_type || "email",
      deliveryFee: Number(row.delivery_fee) || 0,
      address: row.address || "Centro",
      hours: row.hours || "18:00 - 23:30",
      tagline: row.tagline || "",
      announcement: row.announcement || "",
      logo: row.logo || "🍔",
      bannerImage: row.banner_image || row.cover_image || row.banner || "",
      primaryColor: row.primary_color || "#E63946",
      secondaryColor: row.secondary_color || row.primary_dark || "#1E293B",
      primaryDark: row.primary_dark || "#C1121F",
      primaryLight: row.primary_light || "#F77F00",
      accentColor: row.accent_color || "#FCBF49",
      themeMode: row.theme_mode === "dark" ? "dark" : "light",
      menuLayout: row.menu_layout === "grid" ? "grid" : "list",
      showFeaturedCarousel: row.show_featured_carousel !== undefined ? Boolean(row.show_featured_carousel) : true,
      isFeatured: row.is_featured !== undefined ? Boolean(row.is_featured) : Boolean(row.isFeatured || false),
      priorityOrder: Number(row.priority_order !== undefined ? row.priority_order : (row.priorityOrder || 0)),
      businessType: resolvedBusinessType,
      category: resolvedBusinessType,
      categoryId: resolvedBusinessType,
      category_id: resolvedBusinessType,
      localidade: (row.localidade && row.localidade !== "undefined") ? row.localidade : "Gargaú",
      location: (row.localidade && row.localidade !== "undefined") ? row.localidade : "Gargaú",
      motoboyPhone: row.motoboy_phone || row.motoboyPhone || "",
      motoboy_phone: row.motoboy_phone || row.motoboyPhone || "",
      motoboyName: row.motoboy_name || row.motoboyName || "",
      motoboy_name: row.motoboy_name || row.motoboyName || "",
      rating: Number(row.rating) || 4.9,
      ratingCount: Number(row.rating_count) || 120,
      status: (row.status === "inactive" ? "inactive" : "active") as TenantStatus,
      subscriptionStatus: (row.subscription_status || "demo") as any,
      billingDay:
        row.billing_day !== undefined && row.billing_day !== null && row.billing_day !== ""
          ? Number(row.billing_day)
          : undefined,
      lastPaymentAt:
        row.last_payment_at !== undefined && row.last_payment_at !== null && row.last_payment_at !== ""
          ? Number(row.last_payment_at)
          : undefined,
      paidUntil:
        row.paid_until !== undefined && row.paid_until !== null && row.paid_until !== ""
          ? Number(row.paid_until)
          : undefined,
      nextDueDate:
        row.next_due_date !== undefined && row.next_due_date !== null && row.next_due_date !== ""
          ? Number(row.next_due_date)
          : undefined,
      monthlyFee:
        row.monthly_fee !== undefined && row.monthly_fee !== null && row.monthly_fee !== ""
          ? Number(row.monthly_fee)
          : 49.9,
      isOpen: Boolean(row.is_open !== undefined ? row.is_open : 1),
      createdAt: Number(row.created_at) || Date.now(),
      updatedAt: Number(row.updated_at) || Date.now(),
    };
  }

  private mapUserRow(row: any): User {
    return {
      id: row.id,
      email: row.email,
      name: row.name,
      role: row.role,
      tenantId: row.tenant_id,
      status: row.status,
      createdAt: Number(row.created_at),
      updatedAt: row.updated_at ? Number(row.updated_at) : undefined,
    };
  }

  private safeJsonParse<T>(val: any, fallback: T): T {
    if (val === null || val === undefined) return fallback;
    if (typeof val === "object") return val as T;
    if (typeof val === "string") {
      try {
        return JSON.parse(val) as T;
      } catch {
        return fallback;
      }
    }
    return fallback;
  }

  private mapProductRow(row: any): Product {
    const isAvail =
      row.available !== undefined && row.available !== null
        ? row.available === 1 ||
          row.available === true ||
          row.available === "1" ||
          row.available === "true" ||
          row.available === "active"
        : true;

    const position = Number(row.position ?? row.ordem ?? row.order_index ?? 0);

    return {
      id: row.id,
      tenantId: row.tenant_id,
      name: row.name,
      description: row.description || "",
      price: Number(row.price) || 0,
      category: row.category || "geral",
      image: row.image || "",
      available: isAvail,
      options: this.safeJsonParse(row.options_json, []),
      addonGroupIds: this.safeJsonParse(row.addon_group_ids, []),
      position,
      ordem: position,
      order: position,
      createdAt: Number(row.created_at) || Date.now(),
    };
  }

  private mapAddonGroupRow(row: any): AddonGroup {
    return {
      id: row.id,
      tenantId: row.tenant_id,
      name: row.name,
      description: row.description || "",
      minSelection: Number(row.min_selection ?? row.minSelection ?? 0),
      maxSelection: Number(row.max_selection ?? row.maxSelection ?? 0),
      required: Boolean(row.required || (row.min_selection && row.min_selection > 0)),
      items: this.safeJsonParse(row.items_json || row.items, []),
      position: Number(row.position ?? 0),
      createdAt: Number(row.created_at) || Date.now(),
      updatedAt: Number(row.updated_at) || Date.now(),
    };
  }

  private parseOrderTimestamp(raw: any): number {
    if (raw === undefined || raw === null || raw === "") return Date.now();
    if (typeof raw === "number") {
      if (isNaN(raw) || raw <= 0) return Date.now();
      return raw < 10_000_000_000 ? raw * 1000 : raw;
    }
    if (typeof raw === "string") {
      const trimmed = raw.trim();
      if (/^\d+(\.\d+)?$/.test(trimmed)) {
        const num = Number(trimmed);
        if (!isNaN(num) && num > 0) {
          return num < 10_000_000_000 ? num * 1000 : num;
        }
      }
      let parsed = Date.parse(trimmed);
      if (isNaN(parsed)) {
        parsed = Date.parse(trimmed.replace(" ", "T"));
      }
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
    return Date.now();
  }

  private mapOrderRow(row: any): Order {
    const rawTable = row.table_number || row.tableNumber || row.mesa || row.table || undefined;
    const cleanTable = rawTable && typeof rawTable === "string" && rawTable.trim() ? rawTable.trim() : undefined;

    return {
      id: row.id,
      tenantId: row.tenant_id,
      customerName: row.customer_name,
      customerPhone: row.customer_phone,
      orderType: row.order_type,
      tipo_pedido: resolveTipoPedido(row.order_type, cleanTable),
      tableNumber: cleanTable,
      table_number: cleanTable,
      mesa: cleanTable,
      table: cleanTable,
      paymentMethod: row.payment_method,
      cardType: row.card_type || undefined,
      paymentDetails: row.payment_details || undefined,
      pixReceiptUrl: row.pix_receipt_url || undefined,
      pix_receipt_url: row.pix_receipt_url || undefined,
      location_url: row.location_url || undefined,
      locationUrl: row.location_url || undefined,
      address: this.safeJsonParse(row.address_json, undefined),
      changeFor: row.change_for,
      subtotal: Number(row.subtotal),
      deliveryFee: Number(row.delivery_fee),
      total: Number(row.total),
      status: row.status,
      items: this.safeJsonParse(row.items_json, []),
      statusHistory: this.safeJsonParse(row.status_history_json, []),
      idempotencyKey: row.idempotency_key || (row as any).idempotencyKey || undefined,
      idempotency_key: row.idempotency_key || (row as any).idempotencyKey || undefined,
      cart_id: row.idempotency_key || (row as any).idempotencyKey || undefined,
      createdAt: this.parseOrderTimestamp(row.created_at ?? row.createdAt),
    };
  }

  // ===================== CUSTOMERS =====================

  private mapCustomerRow(row: any): Customer {
    return {
      id: row.id,
      tenantId: row.tenant_id,
      name: row.name,
      phone: row.phone,
      street: row.address_street || undefined,
      number: row.address_number || undefined,
      district: row.address_district || undefined,
      complement: row.address_complement || undefined,
      reference: row.address_reference || undefined,
      totalOrders: Number(row.total_orders || 1),
      totalSpent: Number(row.total_spent || 0),
      lastOrderAt: Number(row.last_order_at || row.created_at || Date.now()),
      createdAt: Number(row.created_at || Date.now()),
      updatedAt: Number(row.updated_at || Date.now()),
    };
  }

  async getCustomersByTenant(tenantId: string): Promise<Customer[]> {
    if (!tenantId) return [];

    // 1. D1 Database
    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const res = await this.env.DB.prepare(
          "SELECT * FROM customers WHERE tenant_id = ? ORDER BY last_order_at DESC"
        )
          .bind(tenantId)
          .all<any>();

        if (res.results && res.results.length > 0) {
          return res.results.map((r) => this.mapCustomerRow(r));
        }
      } catch (e) {
        console.warn("D1 getCustomersByTenant error:", e);
      }
    }

    // 2. Fallback memory store
    return globalStore.customers
      .filter((c) => c.tenantId === tenantId)
      .sort((a, b) => b.lastOrderAt - a.lastOrderAt);
  }

  async getCustomerByPhone(tenantId: string, phone: string): Promise<Customer | null> {
    if (!tenantId || !phone) return null;
    const cleanDigits = phone.replace(/\D/g, "");

    // 1. D1 Database
    if (this.env?.DB) {
      try {
        await this.ensureTables();
        const res = await this.env.DB.prepare(
          `SELECT * FROM customers 
           WHERE tenant_id = ? 
             AND (phone = ? OR REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', '') = ?)
           LIMIT 1`
        )
          .bind(tenantId, phone, cleanDigits)
          .first<any>();

        if (res) {
          return this.mapCustomerRow(res);
        }
      } catch (e) {
        console.warn("D1 getCustomerByPhone error:", e);
      }
    }

    // 2. Fallback memory store
    const found = globalStore.customers.find((c) => {
      if (c.tenantId !== tenantId) return false;
      const cDigits = c.phone.replace(/\D/g, "");
      return c.phone === phone || (cleanDigits.length >= 8 && cDigits === cleanDigits);
    });

    return found || null;
  }

  async saveOrUpdateCustomerFromOrder(tenantId: string, order: Order): Promise<Customer> {
    const name = (order.customerName || "Cliente").trim();
    const phone = (order.customerPhone || "").trim();
    const cleanDigits = phone.replace(/\D/g, "");
    const street = order.address?.street?.trim() || "";
    const number = order.address?.number?.trim() || "";
    const district = order.address?.district?.trim() || "";
    const complement = order.address?.complement?.trim() || "";
    const reference = order.address?.reference?.trim() || "";
    const total = order.total || 0;
    const now = Date.now();

    // 1. Verifica se já existe cliente cadastrado para este telefone na loja
    const existing = await this.getCustomerByPhone(tenantId, phone);

    if (existing) {
      // Atualiza os dados do cliente recorrente
      const updatedTotalOrders = (existing.totalOrders || 1) + 1;
      const updatedTotalSpent = (existing.totalSpent || 0) + total;
      const updatedName = name || existing.name;
      const updatedStreet = street || existing.street;
      const updatedNumber = number || existing.number;
      const updatedDistrict = district || existing.district;
      const updatedComplement = complement || existing.complement;
      const updatedReference = reference || existing.reference;

      if (this.env?.DB) {
        try {
          await this.ensureTables();
          await this.env.DB.prepare(
            `UPDATE customers SET
              name = ?,
              address_street = ?,
              address_number = ?,
              address_district = ?,
              address_complement = ?,
              address_reference = ?,
              total_orders = ?,
              total_spent = ?,
              last_order_at = ?,
              updated_at = ?
            WHERE id = ?`
          )
            .bind(
              updatedName,
              updatedStreet || null,
              updatedNumber || null,
              updatedDistrict || null,
              updatedComplement || null,
              updatedReference || null,
              updatedTotalOrders,
              updatedTotalSpent,
              now,
              now,
              existing.id
            )
            .run();
        } catch (e) {
          console.warn("D1 update customer error:", e);
        }
      }

      // Atualiza memória
      existing.name = updatedName;
      existing.street = updatedStreet;
      existing.number = updatedNumber;
      existing.district = updatedDistrict;
      existing.complement = updatedComplement;
      existing.reference = updatedReference;
      existing.totalOrders = updatedTotalOrders;
      existing.totalSpent = updatedTotalSpent;
      existing.lastOrderAt = now;
      existing.updatedAt = now;

      // Atualiza KV se disponível
      const kv = this.getKv();
      if (kv && cleanDigits) {
        try {
          await kv.put(`customer:${tenantId}:${cleanDigits}`, JSON.stringify(existing));
        } catch (e) {
          console.warn("KV put customer error:", e);
        }
      }

      return existing;
    }

    // 2. Se não existir, cadastra novo cliente na loja
    const newCustomer: Customer = {
      id: `cust-${now}-${Math.floor(1000 + Math.random() * 9000)}`,
      tenantId,
      name,
      phone,
      street: street || undefined,
      number: number || undefined,
      district: district || undefined,
      complement: complement || undefined,
      reference: reference || undefined,
      totalOrders: 1,
      totalSpent: total,
      lastOrderAt: now,
      createdAt: now,
      updatedAt: now,
    };

    if (this.env?.DB) {
      try {
        await this.ensureTables();
        await this.env.DB.prepare(
          `INSERT INTO customers (
            id, tenant_id, name, phone, address_street, address_number,
            address_district, address_complement, address_reference,
            total_orders, total_spent, last_order_at, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newCustomer.id,
            newCustomer.tenantId,
            newCustomer.name,
            newCustomer.phone,
            newCustomer.street || null,
            newCustomer.number || null,
            newCustomer.district || null,
            newCustomer.complement || null,
            newCustomer.reference || null,
            newCustomer.totalOrders,
            newCustomer.totalSpent,
            newCustomer.lastOrderAt,
            newCustomer.createdAt,
            newCustomer.updatedAt
          )
          .run();
      } catch (e) {
        console.warn("D1 insert customer error:", e);
      }
    }

    globalStore.customers.unshift(newCustomer);

    const kv = this.getKv();
    if (kv && cleanDigits) {
      try {
        await kv.put(`customer:${tenantId}:${cleanDigits}`, JSON.stringify(newCustomer));
      } catch (e) {
        console.warn("KV put customer error:", e);
      }
    }

    return newCustomer;
  }

  // ===================== CARROSSÉIS DA HOME (HISTÓRICO DE VENDAS D1) =====================

  /**
   * Carrossel 1: Lojas em Destaque
   * Regra: Apenas lojas com is_featured = true.
   * Consulta no D1 contando os pedidos concluídos de cada loja (COUNT(orders.id)).
   * A loja patrocinada com MAIOR número de vendas ocupa AUTOMATICAMENTE a 1ª posição (#1).
   */
  async getFeaturedStoresRanked(location?: string): Promise<FeaturedStoreRanked[]> {
    await this.ensureTables();
    const filterByLoc = !this.isAllLocationsFilter(location);
    const cleanLoc = (location || "").trim();

    if (this.env?.DB) {
      try {
        const whereLocClause = filterByLoc ? " AND LOWER(TRIM(t.localidade)) = LOWER(TRIM(?))" : "";
        const query = `
          SELECT 
            t.*,
            COALESCE(ord_stat.completed_count, 0) as completed_orders_count,
            COALESCE(ord_stat.total_count, 0) as sales_count
          FROM tenants t
          LEFT JOIN (
            SELECT 
              tenant_id,
              COUNT(CASE WHEN UPPER(status) IN ('DONE', 'CONCLUÍDO', 'CONCLUIDO', 'ENTREGUE', 'FINALIZADO', 'PRONTO', 'READY', 'SAIU_PARA_ENTREGA', 'DELIVERING') THEN 1 END) as completed_count,
              COUNT(id) as total_count
            FROM orders
            WHERE status != 'cancelled'
            GROUP BY tenant_id
          ) ord_stat ON ord_stat.tenant_id = t.id
          WHERE (t.is_featured = 1 OR t.is_featured = true) AND t.status != 'inactive'${whereLocClause}
          ORDER BY 
            completed_orders_count DESC, 
            sales_count DESC, 
            t.priority_order DESC, 
            t.created_at DESC
        `;
        const stmt = this.env.DB.prepare(query);
        const res = filterByLoc ? await stmt.bind(cleanLoc).all<any>() : await stmt.all<any>();
        if (res.results && res.results.length > 0) {
          return res.results.map((r: any, idx: number) => {
            const tenant = this.mapTenantRow(r);
            const completedOrdersCount = Number(r.completed_orders_count) || 0;
            const salesCount = Number(r.sales_count) || 0;
            return {
              ...tenant,
              completedOrdersCount,
              salesCount,
              rank: idx + 1,
            };
          });
        }
        if (filterByLoc && res.results && res.results.length === 0) {
          // Continua para verificar em memória caso lojas novas/seed estejam na memória
        }
      } catch (e) {
        console.warn("D1 getFeaturedStoresRanked query warning, falling back to memory:", e);
      }
    }

    // Fallback em memória a partir de globalStore
    const featuredTenants = globalStore.tenants.filter(
      (t) =>
        Boolean(t.isFeatured) &&
        t.status !== "inactive" &&
        !isTenantPermanentlyDeleted(t.id) &&
        !isTenantPermanentlyDeleted(t.slug) &&
        this.matchesLocationFilter(t.localidade, location)
    );

    const ranked = featuredTenants.map((t) => {
      const storeOrders = globalStore.orders.filter((o) => o.tenantId === t.id);
      const completedOrders = storeOrders.filter(
        (o) => {
          const st = String(o.status || "").toLowerCase();
          return (
            st === "done" ||
            st === "concluído" ||
            st === "concluido" ||
            st === "entregue" ||
            st === "finalizado" ||
            st === "pronto" ||
            st === "ready" ||
            st === "saiu_para_entrega" ||
            st === "delivering"
          );
        }
      );
      const nonCancelledOrders = storeOrders.filter((o) => o.status !== "cancelled");
      const loc = (t.localidade || t.location || "Gargaú").trim() || "Gargaú";
      return {
        ...t,
        localidade: loc,
        location: loc,
        completedOrdersCount: completedOrders.length,
        salesCount: nonCancelledOrders.length,
        rank: 0,
      };
    });

    // Ordenação: MAIOR número de pedidos concluídos ocupa AUTOMATICAMENTE o 1º lugar
    ranked.sort((a, b) => {
      if (b.completedOrdersCount !== a.completedOrdersCount) {
        return b.completedOrdersCount - a.completedOrdersCount;
      }
      if (b.salesCount !== a.salesCount) {
        return b.salesCount - a.salesCount;
      }
      const aPri = a.priorityOrder || 0;
      const bPri = b.priorityOrder || 0;
      if (aPri !== bPri) return bPri - aPri;
      return (b.createdAt || 0) - (a.createdAt || 0);
    });

    return ranked.map((store, index) => ({
      ...store,
      rank: index + 1,
    }));
  }

  /**
   * Carrossel 2: Mais Pedidos
   * Regra: Cards dos lanches/produtos individuais mais vendidos de TODAS as lojas do app.
   * Consulta no D1 contando os itens nos pedidos (order_items com SUM(quantity)).
   * O lanche com maior volume de pedidos da semana/mês ocupa AUTOMATICAMENTE a 1ª posição.
   */
  async getTopSellingProducts(limit = 10, daysWindow = 30, location?: string): Promise<TopSellingProduct[]> {
    await this.ensureTables();
    const filterByLoc = !this.isAllLocationsFilter(location);
    const cleanLoc = (location || "").trim();

    if (this.env?.DB) {
      try {
        const cutoffTimestamp = Date.now() - daysWindow * 86400000;
        const whereLocClause = filterByLoc ? " AND LOWER(TRIM(t.localidade)) = LOWER(TRIM(?))" : "";

        // 1. Tenta buscar filtrando pela janela de tempo (semana/mês)
        let query = `
          SELECT 
            oi.tenant_id as tenantId,
            oi.product_id as productId,
            MAX(oi.name) as name,
            MAX(oi.price) as price,
            COALESCE(NULLIF(MAX(p.image), ''), NULLIF(MAX(oi.image), ''), '') as image,
            COALESCE(MAX(p.description), '') as description,
            MAX(t.name) as tenantName,
            MAX(t.slug) as tenantSlug,
            MAX(t.logo) as tenantLogo,
            MAX(t.primary_color) as tenantPrimaryColor,
            COALESCE(NULLIF(MAX(t.localidade), ''), 'Gargaú') as location,
            SUM(oi.quantity) as totalSold
          FROM order_items oi
          JOIN tenants t ON t.id = oi.tenant_id
          LEFT JOIN products p ON (p.id = oi.product_id AND p.tenant_id = oi.tenant_id)
          JOIN orders o ON o.id = oi.order_id
          WHERE t.status != 'inactive'
            AND o.status != 'cancelled'
            AND oi.created_at >= ?${whereLocClause}
          GROUP BY oi.tenant_id, oi.product_id
          ORDER BY totalSold DESC, name ASC
          LIMIT ?
        `;
        let res = filterByLoc
          ? await this.env.DB.prepare(query).bind(cutoffTimestamp, cleanLoc, limit).all<any>()
          : await this.env.DB.prepare(query).bind(cutoffTimestamp, limit).all<any>();

        // Se retornar menos de 2 produtos na janela recente, consulta todo o histórico de order_items
        if (!res.results || res.results.length < 2) {
          query = `
            SELECT 
              oi.tenant_id as tenantId,
              oi.product_id as productId,
              MAX(oi.name) as name,
              MAX(oi.price) as price,
              COALESCE(NULLIF(MAX(p.image), ''), NULLIF(MAX(oi.image), ''), '') as image,
              COALESCE(MAX(p.description), '') as description,
              MAX(t.name) as tenantName,
              MAX(t.slug) as tenantSlug,
              MAX(t.logo) as tenantLogo,
              MAX(t.primary_color) as tenantPrimaryColor,
              COALESCE(NULLIF(MAX(t.localidade), ''), 'Gargaú') as location,
              SUM(oi.quantity) as totalSold
            FROM order_items oi
            JOIN tenants t ON t.id = oi.tenant_id
            LEFT JOIN products p ON (p.id = oi.product_id AND p.tenant_id = oi.tenant_id)
            JOIN orders o ON o.id = oi.order_id
            WHERE t.status != 'inactive'
              AND o.status != 'cancelled'${whereLocClause}
            GROUP BY oi.tenant_id, oi.product_id
            ORDER BY totalSold DESC, name ASC
            LIMIT ?
          `;
          res = filterByLoc
            ? await this.env.DB.prepare(query).bind(cleanLoc, limit).all<any>()
            : await this.env.DB.prepare(query).bind(limit).all<any>();
        }

        if (res.results && res.results.length > 0) {
          return res.results.map((r: any, idx: number) => {
            const safeSlug = String(r.name || "item")
              .toLowerCase()
              .replace(/[^a-z0-9]+/g, "-")
              .replace(/(^-|-$)/g, "");
            const loc = (r.location || r.localidade || "Gargaú").trim() || "Gargaú";
            return {
              id: `top-${idx + 1}-${r.tenantId}-${r.productId}-${safeSlug}`,
              productId: r.productId,
              name: r.name,
              price: Number(r.price) || 0,
              image: r.image || "",
              description: r.description || "",
              tenantId: r.tenantId,
              tenantName: r.tenantName,
              tenantSlug: r.tenantSlug,
              tenantLogo: r.tenantLogo || "🍔",
              tenantPrimaryColor: r.tenantPrimaryColor || "#E63946",
              location: loc,
              localidade: loc,
              totalSold: Number(r.totalSold) || 0,
              rank: idx + 1,
            };
          });
        }
      } catch (e) {
        console.warn("D1 getTopSellingProducts warning, falling back to memory:", e);
      }
    }

    // Fallback em memória agregando order.items
    const salesMap = new Map<
      string,
      {
        productId: string;
        name: string;
        price: number;
        image: string;
        description: string;
        tenantId: string;
        tenantName: string;
        tenantSlug: string;
        tenantLogo: string;
        tenantPrimaryColor: string;
        location: string;
        localidade: string;
        totalSold: number;
      }
    >();

    const validOrders = globalStore.orders.filter((o) => o.status !== "cancelled");
    for (const order of validOrders) {
      const tenant = globalStore.tenants.find(
        (t) =>
          t.id === order.tenantId &&
          t.status !== "inactive" &&
          !isTenantPermanentlyDeleted(t.id) &&
          !isTenantPermanentlyDeleted(t.slug) &&
          this.matchesLocationFilter(t.localidade, location)
      );
      if (!tenant) continue;

      for (const item of order.items || []) {
        const pId = item.product?.id || `p-${Math.random().toString(36).substring(2, 6)}`;
        // Agrupa por loja e produto para consolidar o total vendido de forma única
        const key = `${tenant.id}__${pId}`;
        const existing = salesMap.get(key);
        const qty = Number(item.quantity) || 1;

        const matchingProduct =
          globalStore.products.find((p) => p.id === pId && p.tenantId === tenant.id) ||
          globalStore.products.find((p) => p.id === pId);
        const img = item.product?.image || matchingProduct?.image || "";
        const desc = matchingProduct?.description || item.notes || "";

        if (existing) {
          existing.totalSold += qty;
          if (!existing.image && img) existing.image = img;
        } else {
          const loc = (tenant.localidade || tenant.location || "Gargaú").trim() || "Gargaú";
          salesMap.set(key, {
            productId: pId,
            name: matchingProduct?.name || item.product?.name || "Lanche Especial",
            price: Number(matchingProduct?.price ?? item.product?.price) || 0,
            image: img,
            description: desc,
            tenantId: tenant.id,
            tenantName: tenant.name,
            tenantSlug: tenant.slug,
            tenantLogo: tenant.logo || "🍔",
            tenantPrimaryColor: tenant.primaryColor || "#E63946",
            location: loc,
            localidade: loc,
            totalSold: qty,
          });
        }
      }
    }

    const sorted = Array.from(salesMap.values()).sort((a, b) => b.totalSold - a.totalSold);
    return sorted.slice(0, limit).map((prod, idx) => {
      const safeSlug = String(prod.name || "item")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");
      return {
        id: `top-${idx + 1}-${prod.tenantId}-${prod.productId}-${safeSlug}`,
        ...prod,
        rank: idx + 1,
      };
    });
  }

  /**
   * Busca global de produtos de todas as lojas ativas com contagem de vendas (totalSold)
   * Ordenados decrescentemente pelos mais vendidos ("Mais Pedidos" no topo).
   */
  async getAllMarketplaceProductsWithSales(location?: string): Promise<TopSellingProduct[]> {
    await this.ensureTables();
    const filterByLoc = !this.isAllLocationsFilter(location);
    const cleanLoc = (location || "").trim();

    // 1. Consulta D1 quando disponível
    if (this.env?.DB) {
      try {
        const whereLocClause = filterByLoc ? " AND LOWER(TRIM(t.localidade)) = LOWER(TRIM(?))" : "";
        const query = `
          SELECT 
            p.id as productId,
            p.tenant_id as tenantId,
            p.name as name,
            p.price as price,
            p.image as image,
            p.description as description,
            p.category as category,
            p.available as available,
            p.options_json as optionsJson,
            t.name as tenantName,
            t.slug as tenantSlug,
            t.logo as tenantLogo,
            t.primary_color as tenantPrimaryColor,
            t.is_open as tenantIsOpen,
            t.delivery_fee as tenantDeliveryFee,
            t.estimated_time as tenantDeliveryTime,
            COALESCE(NULLIF(t.localidade, ''), 'Gargaú') as location,
            COALESCE(sales.total_sold, 0) as totalSold
          FROM products p
          JOIN tenants t ON (t.id = p.tenant_id OR t.slug = p.tenant_id)
          LEFT JOIN (
            SELECT 
              oi.tenant_id,
              oi.product_id,
              SUM(oi.quantity) as total_sold
            FROM order_items oi
            JOIN orders o ON o.id = oi.order_id
            WHERE o.status != 'cancelled'
            GROUP BY oi.tenant_id, oi.product_id
          ) sales ON (sales.product_id = p.id AND (sales.tenant_id = t.id OR sales.tenant_id = t.slug))
          WHERE t.status != 'inactive'${whereLocClause}
          ORDER BY totalSold DESC, t.is_featured DESC, t.priority_order DESC, p.position ASC, p.name ASC
        `;
        const stmt = this.env.DB.prepare(query);
        const res = filterByLoc ? await stmt.bind(cleanLoc).all<any>() : await stmt.all<any>();
        if (res.results && res.results.length > 0) {
          return res.results.map((r: any, idx: number) => {
            const loc = (r.location || "Gargaú").trim() || "Gargaú";
            const isAvail =
              r.available !== undefined && r.available !== null
                ? r.available === 1 || r.available === true || r.available === "1" || r.available === "true"
                : true;
            return {
              id: `mp-${r.tenantId}-${r.productId}`,
              productId: String(r.productId),
              name: String(r.name || ""),
              price: Number(r.price) || 0,
              image: String(r.image || ""),
              description: String(r.description || ""),
              category: String(r.category || "lanches"),
              available: isAvail,
              options: this.safeJsonParse(r.optionsJson, []),
              tenantId: String(r.tenantId),
              tenantName: String(r.tenantName || "Lanchonete"),
              tenantSlug: String(r.tenantSlug || r.tenantId),
              tenantLogo: String(r.tenantLogo || "🍔"),
              tenantPrimaryColor: String(r.tenantPrimaryColor || "#E63946"),
              tenantIsOpen: Boolean(r.tenantIsOpen !== undefined ? r.tenantIsOpen : 1),
              tenantDeliveryFee: Number(r.tenantDeliveryFee) || 0,
              tenantDeliveryTime: String(r.tenantDeliveryTime || "30-45 min"),
              location: loc,
              localidade: loc,
              totalSold: Number(r.totalSold) || 0,
              rank: idx + 1,
            };
          });
        }
      } catch (e) {
        console.warn("D1 getAllMarketplaceProductsWithSales warning, falling back to memory:", e);
      }
    }

    // 2. Fallback em memória consolidando globalStore.products e globalStore.orders
    const activeTenants = globalStore.tenants.filter(
      (t) =>
        t.status !== "inactive" &&
        !isTenantPermanentlyDeleted(t.id) &&
        !isTenantPermanentlyDeleted(t.slug) &&
        this.matchesLocationFilter(t.localidade, location)
    );
    const tenantByIdOrSlug = new Map<string, Tenant>();
    for (const t of activeTenants) {
      tenantByIdOrSlug.set(t.id, t);
      tenantByIdOrSlug.set(t.slug, t);
    }

    // Calcula vendas reais por produto em pedidos não cancelados
    const salesByProductKey = new Map<string, number>();
    const validOrders = globalStore.orders.filter((o) => o.status !== "cancelled");
    for (const order of validOrders) {
      const t = tenantByIdOrSlug.get(order.tenantId);
      if (!t) continue;
      for (const item of order.items || []) {
        const pId = item.product?.id;
        const pNameNorm = (item.product?.name || "").trim().toLowerCase();
        const qty = Number(item.quantity) || 1;
        if (pId) {
          const key = `${t.id}__${pId}`;
          salesByProductKey.set(key, (salesByProductKey.get(key) || 0) + qty);
        }
        if (pNameNorm) {
          const nameKey = `${t.id}__name__${pNameNorm}`;
          salesByProductKey.set(nameKey, (salesByProductKey.get(nameKey) || 0) + qty);
        }
      }
    }

    const catalogResults: TopSellingProduct[] = [];
    const seenProductKeys = new Set<string>();

    for (const prod of globalStore.products) {
      const tenant = prod.tenantId ? tenantByIdOrSlug.get(prod.tenantId) : undefined;
      if (!tenant) continue;
      const dedupKey = `${tenant.id}__${prod.id}`;
      if (seenProductKeys.has(dedupKey)) continue;
      seenProductKeys.add(dedupKey);

      const directSold = salesByProductKey.get(dedupKey) || 0;
      const byNameSold = salesByProductKey.get(`${tenant.id}__name__${(prod.name || "").trim().toLowerCase()}`) || 0;
      const totalSold = Math.max(directSold, byNameSold);
      const loc = (tenant.localidade || tenant.location || "Gargaú").trim() || "Gargaú";

      catalogResults.push({
        id: `mp-${tenant.id}-${prod.id}`,
        productId: prod.id,
        name: prod.name,
        price: Number(prod.price) || 0,
        image: prod.image || "",
        description: prod.description || "",
        category: prod.category || "lanches",
        available: prod.available !== false,
        options: prod.options || [],
        addonGroupIds: prod.addonGroupIds || [],
        tenantId: tenant.id,
        tenantName: tenant.name,
        tenantSlug: tenant.slug,
        tenantLogo: tenant.logo || "🍔",
        tenantPrimaryColor: tenant.primaryColor || "#E63946",
        tenantIsOpen: tenant.isOpen !== false,
        tenantDeliveryFee: Number(tenant.deliveryFee) || 0,
        tenantDeliveryTime: tenant.deliveryTime || "30-45 min",
        location: loc,
        localidade: loc,
        totalSold,
      });
    }

    catalogResults.sort((a, b) => {
      if (b.totalSold !== a.totalSold) {
        return b.totalSold - a.totalSold;
      }
      const tA = tenantByIdOrSlug.get(a.tenantId);
      const tB = tenantByIdOrSlug.get(b.tenantId);
      const featA = tA?.isFeatured ? 1 : 0;
      const featB = tB?.isFeatured ? 1 : 0;
      if (featB !== featA) return featB - featA;
      const priA = tA?.priorityOrder || 0;
      const priB = tB?.priorityOrder || 0;
      if (priB !== priA) return priB - priA;
      return a.name.localeCompare(b.name, "pt-BR");
    });

    return catalogResults.map((item, idx) => ({
      ...item,
      rank: idx + 1,
    }));
  }

  // ==========================================
  // STORIES DA LOJA (APENAS FOTOS - EXPIRAÇÃO 24H - MÁX 3)
  // ==========================================

  async getStoreStories(tenantIdOrSlug: string, onlyActive = true): Promise<StoreStory[]> {
    await this.ensureTables();
    const now = Date.now();

    let targetTenantId = tenantIdOrSlug;
    const tenant = await this.getTenantByIdOrSlug(tenantIdOrSlug);
    if (tenant) {
      targetTenantId = tenant.id;
    }

    if (this.env?.DB) {
      try {
        let query = "SELECT * FROM store_stories WHERE tenant_id = ?";
        const params: any[] = [targetTenantId];
        if (onlyActive) {
          query += " AND expires_at > ?";
          params.push(now);
        }
        query += " ORDER BY created_at ASC";

        const { results } = await this.env.DB.prepare(query).bind(...params).all<any>();
        if (results && Array.isArray(results)) {
          return results.map((r) => ({
            id: String(r.id),
            tenantId: String(r.tenant_id),
            mediaUrl: String(r.media_url),
            mediaType: "image",
            caption: r.caption ? String(r.caption) : undefined,
            createdAt: Number(r.created_at),
            expiresAt: Number(r.expires_at),
          }));
        }
      } catch (err) {
        console.warn("D1 getStoreStories error, using memory fallback:", err);
      }
    }

    return globalStore.stories
      .filter((s) => s.tenantId === targetTenantId && (!onlyActive || s.expiresAt > now))
      .sort((a, b) => a.createdAt - b.createdAt);
  }

  async getAllActiveStoriesGrouped(): Promise<Record<string, StoreStory[]>> {
    await this.ensureTables();
    const now = Date.now();
    const map: Record<string, StoreStory[]> = {};

    if (this.env?.DB) {
      try {
        const query = "SELECT * FROM store_stories WHERE expires_at > ? ORDER BY created_at ASC";
        const { results } = await this.env.DB.prepare(query).bind(now).all<any>();
        if (results && Array.isArray(results)) {
          for (const r of results) {
            const tId = String(r.tenant_id);
            if (!map[tId]) map[tId] = [];
            if (map[tId].length < 3) {
              map[tId].push({
                id: String(r.id),
                tenantId: tId,
                mediaUrl: String(r.media_url),
                mediaType: "image",
                caption: r.caption ? String(r.caption) : undefined,
                createdAt: Number(r.created_at),
                expiresAt: Number(r.expires_at),
              });
            }
          }
        }
      } catch (err) {
        console.warn("D1 getAllActiveStoriesGrouped warning:", err);
      }
    }

    for (const story of globalStore.stories) {
      if (story.expiresAt > now) {
        if (!map[story.tenantId]) map[story.tenantId] = [];
        if (!map[story.tenantId].some((s) => s.id === story.id) && map[story.tenantId].length < 3) {
          map[story.tenantId].push(story);
        }
      }
    }

    // Garante que todas as lojas do catálogo promocional tenham stories ativos
    for (const story of initialStories) {
      if (story.expiresAt > now) {
        if (!map[story.tenantId]) map[story.tenantId] = [];
        if (!map[story.tenantId].some((s) => s.id === story.id) && map[story.tenantId].length < 3) {
          map[story.tenantId].push(story);
          this.insertStoryRow(story).catch(() => {});
        }
      }
    }
    return map;
  }

  async createStoreStory(data: {
    tenantId: string;
    mediaUrl: string;
    mediaType?: string;
    caption?: string;
  }): Promise<StoreStory> {
    await this.ensureTables();

    // 1. Regra: APENAS FOTOS (JPG, PNG, WEBP). Bloqueie envio de vídeos.
    const mediaType = data.mediaType || "image";
    if (mediaType !== "image") {
      throw new Error("Apenas fotos (JPG, PNG, WEBP) são permitidas nos stories. Envio de vídeos está bloqueado.");
    }
    const url = String(data.mediaUrl || "").trim();
    if (!url) {
      throw new Error("A imagem do story é obrigatória.");
    }
    const isVideo = url.startsWith("data:video") || /\.(mp4|mov|avi|webm|mkv)(\?.*)?$/i.test(url);
    if (isVideo) {
      throw new Error("Formato não suportado. A funcionalidade aceita apenas fotos (JPG, PNG, WEBP). Vídeos estão bloqueados.");
    }

    // 2. Regra: Limite de no máximo 3 fotos ativas por loja simultaneamente.
    let targetTenantId = data.tenantId;
    const tenant = await this.getTenantByIdOrSlug(data.tenantId);
    if (tenant) {
      targetTenantId = tenant.id;
    }

    const activeStories = await this.getStoreStories(targetTenantId, true);
    if (activeStories.length >= 3) {
      throw new Error("Limite atingido: a loja já possui 3 stories ativos. Apague um story antigo para publicar um novo.");
    }

    const now = Date.now();
    const expiresAt = now + 24 * 60 * 60 * 1000; // 24 horas

    const newStory: StoreStory = {
      id: `story-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
      tenantId: targetTenantId,
      mediaUrl: url,
      mediaType: "image",
      caption: data.caption ? String(data.caption).trim() : undefined,
      createdAt: now,
      expiresAt: expiresAt,
    };

    if (this.env?.DB) {
      try {
        await this.env.DB.prepare(
          `INSERT INTO store_stories (id, tenant_id, media_url, media_type, caption, created_at, expires_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        )
          .bind(
            newStory.id,
            newStory.tenantId,
            newStory.mediaUrl,
            newStory.mediaType,
            newStory.caption || null,
            newStory.createdAt,
            newStory.expiresAt
          )
          .run();
      } catch (err) {
        console.warn("D1 insert store_stories error:", err);
      }
    }

    globalStore.stories.push(newStory);
    return newStory;
  }

  async deleteStoreStory(id: string, tenantId?: string): Promise<boolean> {
    await this.ensureTables();

    if (this.env?.DB) {
      try {
        let query = "DELETE FROM store_stories WHERE id = ?";
        const params: any[] = [id];
        if (tenantId) {
          query += " AND tenant_id = ?";
          params.push(tenantId);
        }
        await this.env.DB.prepare(query).bind(...params).run();
      } catch (err) {
        console.warn("D1 delete store_stories error:", err);
      }
    }

    const initialLen = globalStore.stories.length;
    globalStore.stories = globalStore.stories.filter((s) => {
      if (s.id !== id) return true;
      if (tenantId && s.tenantId !== tenantId) return true;
      return false;
    });

    return globalStore.stories.length < initialLen;
  }

  // ===================== PUSH NOTIFICATIONS (FCM / APNs) =====================

  /**
   * Salva o token de notificação de um lojista autenticado.
   * Marca o status como ativo (isLoggedIn: true) para permitir envio de novos pedidos.
   */
  async saveMerchantPushToken(
    tenantId: string,
    tokenData: { token: string; platform: string; userId?: string }
  ): Promise<void> {
    const cleanTenant = tenantId.toLowerCase().trim();
    const now = Date.now();

    // 1. Atualiza memória global
    let currentTokens = globalStore.merchantPushTokens.get(cleanTenant) || [];
    currentTokens = currentTokens.filter((t) => t.token !== tokenData.token);
    currentTokens.push({
      token: tokenData.token,
      platform: tokenData.platform || "android",
      userId: tokenData.userId,
      isLoggedIn: true,
      updatedAt: now,
    });
    globalStore.merchantPushTokens.set(cleanTenant, currentTokens);

    // 2. Persiste no Cloudflare KV se disponível
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`push_tokens:${cleanTenant}`, JSON.stringify(currentTokens));
      } catch (err) {
        console.warn("KV put push_tokens error:", err);
      }
    }
  }

  /**
   * Remove ou desativa o token quando o lojista desloga do painel.
   * Garante a CONDIÇÃO 2: nenhuma notificação é enviada com o lojista deslogado.
   */
  async removeMerchantPushToken(tenantId: string, token: string): Promise<void> {
    const cleanTenant = tenantId.toLowerCase().trim();

    // 1. Atualiza memória global (remove ou marca isLoggedIn = false)
    let currentTokens = globalStore.merchantPushTokens.get(cleanTenant) || [];
    currentTokens = currentTokens.filter((t) => t.token !== token);
    globalStore.merchantPushTokens.set(cleanTenant, currentTokens);

    // 2. Persiste no Cloudflare KV
    const kv = this.getKv();
    if (kv) {
      try {
        await kv.put(`push_tokens:${cleanTenant}`, JSON.stringify(currentTokens));
      } catch (err) {
        console.warn("KV put push_tokens error:", err);
      }
    }
  }

  /**
   * Retorna os tokens de notificação ativos da sessão do lojista.
   * Retorna APENAS se o lojista estiver autenticado (isLoggedIn === true).
   */
  async getActiveMerchantPushTokens(
    tenantId: string
  ): Promise<Array<{ token: string; platform: string; userId?: string; isLoggedIn: boolean }>> {
    const cleanTenant = tenantId.toLowerCase().trim();

    // 1. Tenta buscar no Cloudflare KV
    const kv = this.getKv();
    if (kv) {
      try {
        const raw = await kv.get(`push_tokens:${cleanTenant}`);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) {
            return parsed.filter((t) => t.isLoggedIn === true && t.token);
          }
        }
      } catch {
        // fallback para memória
      }
    }

    // 2. Fallback para memória global
    const memTokens = globalStore.merchantPushTokens.get(cleanTenant) || [];
    return memTokens.filter((t) => t.isLoggedIn === true && t.token);
  }
}
